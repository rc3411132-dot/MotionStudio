void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 c = tex(uv);
  if (m(1.0)) {
    c = discBlur(uv, uAmt * 0.06);
  } else if (m(2.0)) {
    vec2 d = vec2(cos(uAngle), sin(uAngle)) * uAmt * 0.10; d.x /= asp();
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 16; i++) { float f = float(i) / 15.0 - 0.5; acc += tex(uv + d * f); }
    c = acc / 16.0;
  } else if (m(3.0)) {
    vec2 dir = uv - vec2(0.5);
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 16; i++) { float f = float(i) / 15.0; acc += tex(uv - dir * uAmt * 0.4 * f); }
    c = acc / 16.0;
  } else if (m(4.0)) {
    vec2 p = uv - vec2(0.5); p.x *= asp();
    vec4 acc = vec4(0.0);
    for (int i = 0; i < 16; i++) {
      float a = (float(i) / 15.0 - 0.5) * uAmt * 0.7;
      vec2 q = rot(p, a); q.x /= asp();
      acc += tex(q + vec2(0.5));
    }
    c = acc / 16.0;
  } else if (m(5.0)) {
    vec2 p = uv - vec2(0.5);
    float d = abs(dot(p, vec2(-sin(uAngle), cos(uAngle))));
    float k = smoothstep(0.08, 0.4, d);
    c = discBlur(uv, uAmt * 0.07 * k);
  } else if (m(6.0)) {
    float d = length((uv - vec2(0.5)) * vec2(asp(), 1.0));
    float k = smoothstep(0.15, 0.75, d);
    c = discBlur(uv, uAmt * 0.08 * k);
  } else if (m(7.0)) {
    vec2 o = vec2(cos(uAngle), sin(uAngle)) * uAmt * 0.03; o.x /= asp();
    c = vec4(tex(uv + o).r, tex(uv).g, tex(uv - o).b, 1.0);
  } else if (m(8.0)) {
    vec2 o = (uv - vec2(0.5)) * uAmt * 0.08;
    c = vec4(tex(uv + o).r, tex(uv).g, tex(uv - o).b, 1.0);
  } else if (m(9.0)) {
    vec2 cell = uRes / (2.0 + uAmt * 70.0);
    c = tex((floor(uv * cell) + vec2(0.5)) / cell);
  } else if (m(10.0)) {
    vec3 b = discBlur(uv, uAmt * 0.012).rgb;
    c = vec4(vec3(tex(uv + vec2(0.003, 0.0) * uAmt).r, b.g, tex(uv - vec2(0.003, 0.0) * uAmt).b), 1.0);
  }
  gl_FragColor = vec4(c.rgb, 1.0);
}
