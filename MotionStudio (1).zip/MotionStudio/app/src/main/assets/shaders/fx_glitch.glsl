void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 c = tex(uv);
  float t = floor(uTime * 10.0);
  if (m(20.0)) {
    // block glitch: horizontal (or vertical when angle > 0.8) slices
    bool vert = uAngle > 0.8;
    float coord = vert ? uv.x : uv.y;
    float band = floor(coord * 22.0);
    float r = hash(vec2(band, t + uSeed));
    if (r > 1.0 - uAmt * 0.5) {
      float off = (hash(vec2(band + 3.0, t)) - 0.5) * uAmt * 0.35;
      vec2 u2 = vert ? vec2(uv.x, uv.y + off) : vec2(uv.x + off, uv.y);
      vec2 sp = vert ? vec2(0.0, 0.008) : vec2(0.008, 0.0);
      c = vec4(tex(u2 + sp * uAmt).r, tex(u2).g, tex(u2 - sp * uAmt).b, 1.0);
    }
  } else if (m(21.0)) {
    // digital tear
    float y0 = fract(uTime * 0.31);
    float d = abs(uv.y - y0);
    if (d < 0.05 * uAmt + 0.004) {
      float o = sin(uv.y * 300.0) * 0.06 * uAmt;
      c = vec4(tex(uv + vec2(o + 0.01 * uAmt, 0.0)).r, tex(uv + vec2(o, 0.0)).g, tex(uv + vec2(o - 0.01 * uAmt, 0.0)).b, 1.0);
    }
  } else if (m(22.0)) {
    // screen flicker (soft, limited depth)
    float f = hash(vec2(floor(uTime * 12.0), uSeed));
    c.rgb *= 1.0 - uAmt * 0.25 * f;
  } else if (m(23.0)) {
    // signal distortion / pixel displacement
    float row = floor(uv.y * uRes.y / 3.0);
    float j = (hash(vec2(row, t)) - 0.5);
    float on = step(0.7, hash(vec2(floor(uv.y * 14.0), t)));
    vec2 u2 = uv + vec2(j * 0.06 * uAmt * on + sin(uv.y * 60.0 + uTime * 8.0) * 0.004 * uAmt, 0.0);
    c = vec4(tex(u2 + vec2(0.004 * uAmt, 0.0)).r, tex(u2).g, tex(u2 - vec2(0.004 * uAmt, 0.0)).b, 1.0);
  } else if (m(24.0)) {
    // data corruption blocks
    vec2 cell = floor(uv * vec2(16.0, 9.0));
    float h = hash(cell + vec2(t, uSeed));
    if (h > 1.0 - 0.12 * uAmt) {
      vec2 u2 = uv + (vec2(hash(cell + 1.7), hash(cell + 9.1)) - 0.5) * 0.3 * uAmt;
      c = tex(u2);
      if (h > 1.0 - 0.04 * uAmt) c.rgb = c.gbr;
    }
  } else if (m(25.0)) {
    // VHS
    float band = fract(-uTime * 0.18);
    float tr = smoothstep(0.06, 0.0, abs(uv.y - band));
    float wob = sin(uv.y * uRes.y * 0.25 + uTime * 3.0) * 0.0015 * uAmt + tr * 0.03 * uAmt * hash(vec2(t, 1.0));
    vec2 u2 = uv + vec2(wob, 0.0);
    vec3 col = vec3(tex(u2 + vec2(0.004 * uAmt, 0.0)).r, tex(u2).g, tex(u2 - vec2(0.004 * uAmt, 0.0)).b);
    float n = hash(uv * uRes + uTime);
    col += (n - 0.5) * 0.12 * uAmt + tr * 0.15 * uAmt;
    float l = luma(col);
    col = mix(vec3(l), col, 1.0 - 0.25 * uAmt);
    c = vec4(col, 1.0);
  } else if (m(26.0)) {
    // CRT / retro TV
    vec2 p = uv - vec2(0.5);
    p *= 1.0 + 0.18 * uAmt * dot(p, p);
    vec2 u2 = p + vec2(0.5);
    vec3 col = tex(u2).rgb;
    float s = 0.5 + 0.5 * sin(u2.y * uRes.y * 3.14159);
    col *= 1.0 - uAmt * 0.45 * (1.0 - s);
    float mk = mod(gl_FragCoord.x, 3.0);
    col *= vec3(mk < 1.0 ? 1.0 : 0.82, (mk >= 1.0 && mk < 2.0) ? 1.0 : 0.82, mk >= 2.0 ? 1.0 : 0.82);
    col *= 1.0 - 0.9 * smoothstep(0.35, 0.75, length(p) * (0.8 + 0.4 * uAmt));
    if (u2.x < 0.0 || u2.x > 1.0 || u2.y < 0.0 || u2.y > 1.0) col = vec3(0.0);
    c = vec4(col, 1.0);
  } else if (m(27.0)) {
    // static noise (TV static / digital noise)
    float n = hash(uv * uRes + vec2(uTime * 60.0, uSeed));
    c.rgb = mix(c.rgb, vec3(n), uAmt * 0.6);
  } else if (m(28.0)) {
    // scanlines only
    float s = 0.5 + 0.5 * sin(uv.y * uRes.y * 3.14159);
    c.rgb *= 1.0 - uAmt * 0.5 * (1.0 - s);
  } else if (m(29.0)) {
    // hologram
    float sl = 0.5 + 0.5 * sin(uv.y * uRes.y * 1.2 - uTime * 6.0);
    float jit = step(0.96, hash(vec2(floor(uv.y * 40.0), t))) * 0.02 * uAmt;
    vec3 col = vec3(tex(uv + vec2(jit + 0.003 * uAmt, 0.0)).r, tex(uv + vec2(jit, 0.0)).g, tex(uv + vec2(jit - 0.003 * uAmt, 0.0)).b);
    float l = luma(col);
    col = mix(col, vec3(0.2, 0.9, 1.0) * (0.3 + l), 0.55 * uAmt) * (0.75 + 0.25 * sl);
    col += uAmt * 0.08 * hash(vec2(t, uSeed));
    c = vec4(col, 1.0);
  }
  gl_FragColor = vec4(c.rgb, 1.0);
}
