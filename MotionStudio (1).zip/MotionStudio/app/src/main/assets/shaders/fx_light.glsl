vec3 glowAt(vec2 uv, float radius) {
  vec3 acc = vec3(0.0);
  for (int i = 0; i < 24; i++) {
    float fi = float(i);
    float rr = sqrt((fi + 0.5) / 24.0);
    float th = fi * 2.39996;
    vec2 o = vec2(cos(th), sin(th)) * rr * radius; o.x /= asp();
    vec3 s = tex(uv + o).rgb;
    acc += s * max(luma(s) - 0.5, 0.0);
  }
  return acc / 24.0 * 3.0;
}
void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 c = tex(uv);
  vec3 col = c.rgb;
  vec2 p = uv - vec2(0.5);
  vec2 pa = vec2(p.x * asp(), p.y);
  vec2 L = vec2(0.5) + 0.38 * vec2(cos(uAngle), sin(uAngle));
  if (m(80.0)) {
    vec3 g = glowAt(uv, 0.03 + 0.05 * uAmt);
    col += g * mix(vec3(1.0), uTint * 1.4, 0.75) * uAmt * 2.2;
  } else if (m(81.0)) {
    vec3 g = glowAt(uv, 0.02 + 0.03 * uAmt);
    float e = fract(sin(uTime * 40.0) * 100.0);
    col += g * uTint * 1.6 * uAmt * (1.6 + 0.8 * e);
  } else if (m(82.0)) {
    vec3 sum = vec3(0.0);
    vec2 axis = vec2(1.0, 0.0);
    for (int i = 0; i < 16; i++) {
      float f = float(i) / 15.0 - 0.5;
      vec3 s = tex(uv + axis * f * 0.5).rgb;
      sum += s * max(luma(s) - 0.55, 0.0) * exp(-abs(f) * 5.0);
    }
    vec3 gl = vec3(uTint) * luma(sum / 16.0 * 6.0) * 2.0 + sum / 16.0 * 3.0;
    col += gl * uAmt * 1.4;
  } else if (m(83.0)) {
    vec2 d = L - uv; d.x *= asp();
    float dist = length(d);
    float core = exp(-dist * 9.0);
    vec3 fl = vec3(1.0, 0.85, 0.6) * core;
    for (int i = 1; i < 5; i++) {
      float f = float(i);
      vec2 g = L + (vec2(0.5) - L) * (0.5 * f + 0.2);
      vec2 dd = uv - g; dd.x *= asp();
      float r = 0.025 * f;
      float ring = smoothstep(r, r * 0.3, length(dd));
      fl += vec3(0.3 + 0.15 * f, 0.5, 1.0 - 0.15 * f) * ring * 0.35;
    }
    col = 1.0 - (1.0 - col) * (1.0 - fl * uAmt);
  } else if (m(84.0)) {
    float sx = exp(-abs(uv.y - L.y) * 40.0) * exp(-abs(uv.x - L.x) * 1.8);
    col = 1.0 - (1.0 - col) * (1.0 - vec3(0.35, 0.6, 1.0) * sx * uAmt * 1.2);
    col += vec3(1.0, 0.9, 0.7) * exp(-length((uv - L) * vec2(asp(), 1.0)) * 14.0) * uAmt * 0.6;
  } else if (m(85.0)) {
    vec2 corner = vec2(fract(sin(uSeed) * 7.0) > 0.5 ? 1.0 : 0.0, 0.0);
    float g = smoothstep(1.3, 0.0, length((uv - corner) * vec2(asp(), 1.0)) + 0.2 * sin(uTime * 0.8));
    vec3 lc = mix(vec3(1.0, 0.45, 0.1), vec3(1.0, 0.2, 0.5), 0.5 + 0.5 * sin(uTime * 0.7));
    col = 1.0 - (1.0 - col) * (1.0 - lc * g * uAmt * 0.9);
  } else if (m(86.0)) {
    vec2 dir = vec2(cos(uAngle), sin(uAngle));
    float x = dot(p, dir);
    float pos = fract(uTime * 0.3) * 1.8 - 0.9;
    float band = exp(-pow((x - pos) * 7.0, 2.0));
    col += vec3(1.0, 0.95, 0.85) * band * uAmt * 0.55;
  } else if (m(87.0)) {
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 16; i++) {
      float f = float(i) / 15.0;
      vec3 s = tex(uv + (L - uv) * f * 0.8).rgb;
      acc += s * max(luma(s) - 0.55, 0.0) * (1.0 - f);
    }
    col += acc / 16.0 * 4.0 * mix(vec3(1.0), uTint, 0.5) * uAmt;
  } else if (m(88.0)) {
    float pulse = exp(-fract(uTime * 1.5) * 6.0);
    col += uAmt * 0.55 * pulse;
  } else if (m(89.0)) {
    float on = step(0.5, fract(uTime * 2.0));
    col += uAmt * 0.22 * on;
  } else if (m(90.0)) {
    vec2 cell = floor(uv * uRes / 26.0);
    vec2 f = fract(uv * uRes / 26.0) - vec2(0.5);
    float h = hash(cell + uSeed);
    float tw = pow(max(sin(uTime * 2.5 + h * 6.28), 0.0), 6.0);
    float star = max(0.0, 1.0 - 14.0 * min(abs(f.x), abs(f.y))) * (1.0 - length(f) * 1.4);
    star = max(star, exp(-length(f) * 14.0));
    float gate = step(0.55, h) * smoothstep(0.35, 0.7, luma(col));
    col += vec3(1.0, 0.95, 0.8) * star * tw * gate * uAmt * 2.5;
  } else if (m(91.0)) {
    vec3 rb = 0.5 + 0.5 * cos(6.28318 * (vec3(uv.x + uv.y * 0.5 + uTime * 0.08) + vec3(0.0, 0.33, 0.67)));
    float band = 0.5 + 0.5 * sin(dot(uv, vec2(cos(uAngle), sin(uAngle))) * 6.0 + uTime);
    col = 1.0 - (1.0 - col) * (1.0 - rb * band * uAmt * 0.55);
  } else if (m(92.0)) {
    float a = atan(pa.y, pa.x);
    float rays = pow(abs(sin(a * 12.0 + uTime * 0.6)), 10.0);
    float fall = smoothstep(1.1, 0.0, length(pa));
    col += vec3(1.0, 0.9, 0.7) * rays * fall * uAmt * 0.6;
  } else if (m(93.0)) {
    vec2 d = vec2(cos(uAngle), sin(uAngle)) * 0.2; d.x /= asp();
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 12; i++) {
      float f = float(i) / 11.0;
      vec3 s = tex(uv - d * f).rgb;
      acc += s * max(luma(s) - 0.6, 0.0) * (1.0 - f);
    }
    col += acc / 12.0 * 5.0 * mix(vec3(1.0), uTint, 0.6) * uAmt;
  } else if (m(94.0)) {
    vec3 rb = 0.5 + 0.5 * cos(6.28318 * (vec3(uv.x * 0.8 + uTime * 0.05) + vec3(0.0, 0.33, 0.67)));
    vec3 g = glowAt(uv, 0.03);
    col += g * rb * 2.4 * uAmt + rb * 0.12 * uAmt * smoothstep(0.2, 0.8, luma(col));
  }
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
