vec3 ramp(float l) {
  vec3 a = vec3(0.0, 0.0, 0.25);
  vec3 b = vec3(0.6, 0.0, 0.7);
  vec3 c = vec3(1.0, 0.1, 0.1);
  vec3 d = vec3(1.0, 0.9, 0.1);
  vec3 e = vec3(1.0);
  if (l < 0.25) return mix(a, b, l / 0.25);
  if (l < 0.5) return mix(b, c, (l - 0.25) / 0.25);
  if (l < 0.75) return mix(c, d, (l - 0.5) / 0.25);
  return mix(d, e, (l - 0.75) / 0.25);
}
void main() {
  vec2 uv = vTexSamplingCoord;
  vec2 px = 1.0 / uRes;
  vec4 c = tex(uv);
  vec3 col = c.rgb;
  float l = luma(col);
  if (m(60.0)) {
    vec3 bl = (tex(uv + vec2(px.x, 0.0)).rgb + tex(uv - vec2(px.x, 0.0)).rgb + tex(uv + vec2(0.0, px.y)).rgb + tex(uv - vec2(0.0, px.y)).rgb) * 0.25;
    col = col + (col - bl) * uAmt * 3.0;
  } else if (m(61.0)) {
    float lv = 2.0 + floor((1.0 - uAmt) * 10.0);
    col = floor(col * lv + 0.5) / lv;
  } else if (m(62.0)) {
    float e = edgeAt(uv);
    col = floor(col * 5.0 + 0.5) / 5.0;
    col = mix(col, vec3(0.0), smoothstep(0.15, 0.4, e) * (0.4 + 0.6 * uAmt));
  } else if (m(63.0)) {
    float e = edgeAt(uv);
    vec3 paper = vec3(0.96, 0.95, 0.9);
    vec3 line = paper * (1.0 - clamp(e * 3.0, 0.0, 1.0));
    col = mix(col, mix(line, line * (0.6 + 0.6 * l), 0.35), uAmt);
  } else if (m(64.0)) {
    float e = edgeAt(uv);
    col = mix(col, vec3(e * 1.6), uAmt);
  } else if (m(65.0)) {
    float e = clamp(edgeAt(uv) * 2.0, 0.0, 1.0);
    vec3 glow = uTint * e * 1.8;
    col = mix(col, vec3(0.02) + glow, uAmt);
  } else if (m(66.0)) {
    float cell = 6.0 + (1.0 - uAmt) * 14.0;
    vec2 g = fract(uv * uRes / cell) - vec2(0.5);
    vec2 cc = (floor(uv * uRes / cell) + vec2(0.5)) * cell / uRes;
    vec3 sc = tex(cc).rgb;
    float r = length(g);
    float rad = 0.15 + 0.5 * luma(sc);
    float dotv = smoothstep(rad, rad - 0.15, r);
    col = mix(vec3(1.0), sc * 1.1, dotv);
  } else if (m(67.0)) {
    float cell = 6.0 + (1.0 - uAmt) * 14.0;
    vec2 g = fract(uv * uRes / cell) - vec2(0.5);
    vec2 cc = (floor(uv * uRes / cell) + vec2(0.5)) * cell / uRes;
    float sl = luma(tex(cc).rgb);
    float r = length(g);
    float dotv = smoothstep(0.15 + 0.5 * (1.0 - sl), 0.0 + 0.5 * (1.0 - sl), r);
    col = vec3(1.0 - dotv);
  } else if (m(68.0)) {
    col = mix(col, mix(uTint2, uTint, l), uAmt);
  } else if (m(69.0)) {
    vec3 mid = vec3(0.55, 0.3, 0.5);
    vec3 tri = l < 0.5 ? mix(uTint2, mid, l * 2.0) : mix(mid, uTint, (l - 0.5) * 2.0);
    col = mix(col, tri, uAmt);
  } else if (m(70.0)) {
    col = mix(col, ramp(l), uAmt);
  } else if (m(71.0)) {
    vec3 ir = vec3(col.g, col.r, col.b);
    float il = luma(ir);
    col = mix(col, mix(vec3(il), ir, 0.5) * vec3(1.15, 0.55, 0.75) + vec3(il * 0.35, 0.0, 0.0), uAmt);
  } else if (m(72.0)) {
    float th = 0.35 + 0.3 * (1.0 - uAmt);
    col = mix(col, l < th ? vec3(0.0) : uTint, 0.5 + 0.5 * uAmt);
  } else if (m(73.0)) {
    float r = 2.0 + uAmt * 6.0;
    vec3 m0 = vec3(0.0); vec3 m1 = vec3(0.0); vec3 m2 = vec3(0.0); vec3 m3 = vec3(0.0);
    float v0 = 0.0; float v1 = 0.0; float v2 = 0.0; float v3 = 0.0;
    for (int i = 0; i < 4; i++) {
      float f = float(i) + 1.0;
      vec2 o = px * r * f * 0.5;
      vec3 a = tex(uv + vec2(-o.x, -o.y)).rgb; vec3 b = tex(uv + vec2(o.x, -o.y)).rgb;
      vec3 cc = tex(uv + vec2(-o.x, o.y)).rgb; vec3 dd = tex(uv + vec2(o.x, o.y)).rgb;
      m0 += a; m1 += b; m2 += cc; m3 += dd;
      v0 += luma(a) * luma(a); v1 += luma(b) * luma(b); v2 += luma(cc) * luma(cc); v3 += luma(dd) * luma(dd);
    }
    m0 /= 4.0; m1 /= 4.0; m2 /= 4.0; m3 /= 4.0;
    float s0 = v0 / 4.0 - luma(m0) * luma(m0);
    float s1 = v1 / 4.0 - luma(m1) * luma(m1);
    float s2 = v2 / 4.0 - luma(m2) * luma(m2);
    float s3 = v3 / 4.0 - luma(m3) * luma(m3);
    vec3 best = m0; float bs = s0;
    if (s1 < bs) { bs = s1; best = m1; }
    if (s2 < bs) { bs = s2; best = m2; }
    if (s3 < bs) { bs = s3; best = m3; }
    col = best;
  } else if (m(74.0)) {
    float cell = 3.0 + uAmt * 14.0;
    vec2 q = (floor(uv * uRes / cell) + vec2(0.5)) * cell / uRes;
    col = floor(tex(q).rgb * 5.0 + 0.5) / 5.0;
  } else if (m(75.0)) {
    float xl = 1.0 - l;
    float e = edgeAt(uv);
    col = mix(col, vec3(xl * 0.55, xl * 0.9, xl) + vec3(e * 0.5), uAmt);
  } else if (m(76.0)) {
    col = mix(col, vec3(1.0) - col, uAmt);
  } else if (m(77.0)) {
    vec3 bl = discBlur(uv, 0.012).rgb;
    col = col + (col - bl) * uAmt * 1.6;
  } else if (m(78.0)) {
    vec3 bl = discBlur(uv, 0.004 + 0.006 * uAmt).rgb;
    col = mix(col, bl, 0.6 + 0.4 * uAmt);
  } else if (m(79.0)) {
    vec3 bl = discBlur(uv, 0.02).rgb;
    float lv = 4.0 + floor((1.0 - uAmt) * 6.0);
    col = floor(mix(col, bl, 0.6) * lv + 0.5) / lv;
    col = mix(col, bl, 0.35);
  }
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
