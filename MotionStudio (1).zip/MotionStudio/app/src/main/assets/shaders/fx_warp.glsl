void main() {
  vec2 uv = vTexSamplingCoord;
  vec2 p = uv - vec2(0.5);
  p.x *= asp();
  float d = length(p);
  float tint = 0.0;
  if (m(40.0)) {
    uv.x += sin(uv.y * 18.0 + uTime * 3.0) * 0.025 * uAmt;
    uv.y += sin(uv.x * 14.0 + uTime * 2.5) * 0.012 * uAmt;
  } else if (m(41.0)) {
    float w = sin(d * 42.0 - uTime * 6.0) * 0.014 * uAmt;
    p += normalize(p + vec2(1e-5)) * w;
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(42.0)) {
    float a = (1.0 - smoothstep(0.0, 0.7, d)) * uAmt * 6.0;
    p = rot(p, a);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(43.0)) {
    p *= 1.0 - uAmt * 0.7 * smoothstep(0.7, 0.0, d);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(44.0)) {
    p *= 1.0 + uAmt * 0.7 * smoothstep(0.7, 0.0, d);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(45.0)) {
    p *= 1.0 - uAmt * 0.5 * cos(min(d, 0.7) / 0.7 * 1.5708);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(46.0)) {
    p *= 1.0 + uAmt * 0.3 * dot(p, p);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(47.0)) {
    p *= 1.0 - uAmt * 0.3 * dot(p, p);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(48.0)) {
    float r = max(d, 1e-4);
    p *= pow(clamp(r * 1.4, 0.0, 1.5), uAmt * 0.9) ;
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(49.0)) {
    float n1 = vnoise(uv * 6.0 + vec2(uTime * 0.5, uSeed));
    float n2 = vnoise(uv * 6.0 + vec2(7.7, uTime * 0.5));
    uv += (vec2(n1, n2) - vec2(0.5)) * 0.08 * uAmt;
  } else if (m(50.0)) {
    float t = fract(uTime * 0.4);
    float ring = exp(-pow((d - t * 0.9) * 12.0, 2.0));
    vec2 dir = normalize(p + vec2(1e-5));
    p += dir * ring * 0.09 * uAmt * (1.0 - t);
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(51.0)) {
    uv.y += (vnoise(vec2(uv.x * 30.0, uTime * 5.0)) - 0.5) * 0.012 * uAmt * (0.4 + uv.y);
    uv.x += (vnoise(vec2(uv.y * 30.0 + 5.0, uTime * 4.0)) - 0.5) * 0.008 * uAmt;
  } else if (m(52.0)) {
    vec2 cell = floor(uv * 14.0);
    uv += (vec2(hash(cell + uSeed), hash(cell + 7.7)) - vec2(0.5)) * 0.03 * uAmt;
  } else if (m(53.0)) {
    uv.x += sin(uv.y * 25.0 + uTime * 2.0) * 0.012 * uAmt;
    uv.y += sin(uv.x * 22.0 + uTime * 2.6) * 0.012 * uAmt;
    tint = 0.12 * uAmt;
  } else if (m(54.0)) {
    uv.x = 0.5 - abs(uv.x - 0.5);
  } else if (m(55.0)) {
    uv.y = 0.5 - abs(uv.y - 0.5);
  } else if (m(56.0)) {
    float n = 3.0 + floor(uAmt * 9.0);
    float a = atan(p.y, p.x) + uTime * 0.2;
    float seg = 6.28318 / n;
    a = abs(mod(a, seg) - seg * 0.5);
    p = vec2(cos(a), sin(a)) * d;
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(57.0)) {
    float k = 1.0 + 0.35 * uAmt * sin(uTime * 3.0 + p.y * 4.0);
    p.x *= k; p.y *= 2.0 - k;
    p.x /= asp(); uv = p + vec2(0.5);
  } else if (m(58.0)) {
    float n1 = vnoise(uv * 3.0 + vec2(uTime * 0.3, 0.0));
    float n2 = vnoise(uv * 3.0 + vec2(5.0, uTime * 0.3));
    uv += (vec2(n1, n2) - vec2(0.5)) * 0.18 * uAmt;
  }
  vec3 col = tex(uv).rgb;
  col = mix(col, col * vec3(0.8, 0.95, 1.15), tint * 4.0);
  gl_FragColor = vec4(col, 1.0);
}
