void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 c = tex(uv);
  vec3 col = c.rgb;
  if (m(100.0)) {
    col *= pow(2.0, uG1.x);
    col.r *= 1.0 + uG1.y * 0.2; col.b *= 1.0 - uG1.y * 0.2;
    col.g *= 1.0 + uG1.z * 0.15; col.r *= 1.0 - uG1.z * 0.05; col.b *= 1.0 - uG1.z * 0.05;
    float l = luma(col);
    col += uG1.w * 0.25 * smoothstep(0.5, 1.0, l);
    col += uG2.x * 0.25 * (1.0 - smoothstep(0.0, 0.5, l));
    float mx = max(max(col.r, col.g), col.b);
    float mn = min(min(col.r, col.g), col.b);
    col = mix(vec3(luma(col)), col, 1.0 + uG2.y * (1.0 - (mx - mn)));
    col = hueRot(clamp(col, 0.0, 1.0), uG2.z * 3.14159);
    col = col * (1.0 - uG2.w * 0.3) + uG2.w * 0.15;
  } else if (m(101.0)) {
    vec2 p = (uv - vec2(0.5)) * vec2(asp(), 1.0);
    col *= 1.0 - uAmt * 1.1 * smoothstep(0.25, 0.95, length(p));
  } else if (m(102.0)) {
    float n = hash(uv * uRes + vec2(floor(uTime * 24.0) * 7.0, uSeed));
    float l = luma(col);
    col += (n - 0.5) * uAmt * 0.45 * (1.0 - 0.5 * abs(l - 0.5));
  } else if (m(103.0)) {
    // film gate weave + flicker (brightness) - soft
    float fl = 1.0 + (hash(vec2(floor(uTime * 12.0), uSeed)) - 0.5) * 0.18 * uAmt;
    col *= fl;
  } else if (m(104.0)) {
    // circle mask
    vec2 p = (uv - vec2(0.5)) * vec2(asp(), 1.0);
    float r = mix(0.12, 0.8, uAmt);
    col *= 1.0 - smoothstep(r - 0.02, r + 0.02, length(p));
  } else if (m(105.0)) {
    // box mask
    vec2 p = abs(uv - vec2(0.5)) * 2.0;
    float k = mix(0.2, 1.0, uAmt);
    float e = max(p.x - k, p.y - k);
    col *= 1.0 - smoothstep(-0.02, 0.02, e);
  } else if (m(106.0)) {
    // heart mask
    vec2 p = (uv - vec2(0.5, 0.45)) * vec2(asp(), 1.0);
    vec2 q = p / mix(0.12, 0.5, uAmt);
    float a = q.x * q.x + q.y * q.y - 1.0;
    float f = a * a * a - q.x * q.x * q.y * q.y * q.y;
    col *= 1.0 - smoothstep(-0.1, 0.1, f);
  } else if (m(107.0)) {
    // cinema strip mask
    float e = abs(uv.y - 0.5) * 2.0 - mix(0.15, 0.9, uAmt);
    col *= 1.0 - smoothstep(-0.01, 0.01, e);
  }
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
