precision highp float;
uniform sampler2D uTexSampler;
varying vec2 vTexSamplingCoord;
uniform float uMode;
uniform float uAmt;
uniform float uTime;
uniform float uAngle;
uniform float uSeed;
uniform vec2 uRes;
uniform vec3 uTint;
uniform vec3 uTint2;
uniform vec4 uG1;
uniform vec4 uG2;

bool m(float k) { return abs(uMode - k) < 0.5; }
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
vec2 rot(vec2 v, float a) { float c = cos(a); float s = sin(a); return vec2(c * v.x - s * v.y, s * v.x + c * v.y); }
float asp() { return uRes.x / uRes.y; }
vec4 tex(vec2 uv) { return texture2D(uTexSampler, clamp(uv, 0.001, 0.999)); }
float vnoise(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  float a = hash(i); float b = hash(i + vec2(1.0, 0.0)); float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
vec4 discBlur(vec2 uv, float r) {
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 16; i++) {
    float fi = float(i);
    float rr = sqrt((fi + 0.5) / 16.0);
    float th = fi * 2.39996;
    vec2 o = vec2(cos(th), sin(th)) * rr * r;
    o.x /= asp();
    acc += tex(uv + o);
  }
  return acc / 16.0;
}
float edgeAt(vec2 uv) {
  vec2 px = 1.0 / uRes;
  float l = luma(tex(uv + vec2(px.x, 0.0)).rgb) - luma(tex(uv - vec2(px.x, 0.0)).rgb);
  float u = luma(tex(uv + vec2(0.0, px.y)).rgb) - luma(tex(uv - vec2(0.0, px.y)).rgb);
  return clamp(length(vec2(l, u)) * 2.0, 0.0, 1.0);
}
vec3 hueRot(vec3 c, float a) {
  float cs = cos(a); float sn = sin(a);
  mat3 mm = mat3(
    0.213 + cs * 0.787 - sn * 0.213, 0.213 - cs * 0.213 + sn * 0.143, 0.213 - cs * 0.213 - sn * 0.787,
    0.715 - cs * 0.715 - sn * 0.715, 0.715 + cs * 0.285 + sn * 0.140, 0.715 - cs * 0.715 + sn * 0.715,
    0.072 - cs * 0.072 + sn * 0.928, 0.072 - cs * 0.072 - sn * 0.283, 0.072 + cs * 0.928 + sn * 0.072);
  return clamp(mm * c, 0.0, 1.0);
}
