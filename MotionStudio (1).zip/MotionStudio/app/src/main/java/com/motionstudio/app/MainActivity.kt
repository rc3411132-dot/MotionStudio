package com.motionstudio.app

import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private val vm: EditorVM by viewModels()
    private val mouse = MouseController()
    private lateinit var input: MouseInput

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        input = MouseInput(
            mouse, vm.prefs,
            decor = { window.decorView },
            dispatchTouch = { ev -> super@MainActivity.dispatchTouchEvent(ev) },
        )
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        setContent { EditorApp(vm, mouse, input) }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean =
        if (input.intercept(ev)) true else super.dispatchTouchEvent(ev)

    override fun onStop() {
        vm.playing = false
        vm.sync()
        vm.prefs.save()
        super.onStop()
    }
}
