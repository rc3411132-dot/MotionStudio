package com.motionstudio.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Procedural overlay effects (particles, film dust, bars, lightning...). Pure function of time, so the preview
 * (Compose canvas) and the exporter (bitmap overlay) draw exactly the same frame.
 */
private class PSpec(
    val shape: Int, val count: Int, val size: Float, val vy: Float, val vx: Float, val wob: Float,
    val colors: IntArray, val twinkle: Boolean = false, val glow: Boolean = false, val alpha: Float = 0.9f,
)
// shapes: 0 circle, 1 confetti rect, 2 petal, 3 streak, 4 sparkle, 5 soft blob, 6 ring

private fun c(v: Long) = v.toInt()
private val WHITE = intArrayOf(c(0xFFFFFFFF))

private val PARTICLES: Map<String, PSpec> = mapOf(
    "dustp" to PSpec(0, 60, 0.004f, 0.01f, 0.006f, 0.02f, WHITE, twinkle = true, alpha = 0.5f),
    "snow" to PSpec(0, 120, 0.008f, 0.12f, 0f, 0.03f, WHITE, alpha = 0.9f),
    "rain" to PSpec(3, 140, 0.07f, 1.4f, 0.15f, 0f, intArrayOf(c(0xFFBFD8FF)), alpha = 0.6f),
    "fireflies" to PSpec(0, 30, 0.008f, -0.02f, 0f, 0.08f, intArrayOf(c(0xFFD6FF5A), c(0xFFFFF176)), twinkle = true, glow = true),
    "sparks" to PSpec(0, 60, 0.005f, -0.25f, 0.03f, 0.05f, intArrayOf(c(0xFFFFB02E), c(0xFFFFE066)), glow = true, alpha = 1f),
    "magic" to PSpec(4, 40, 0.014f, -0.05f, 0f, 0.06f, intArrayOf(c(0xFFB388FF), c(0xFFFF80C8), c(0xFFFFFFFF)), twinkle = true, glow = true),
    "energy" to PSpec(0, 70, 0.006f, -0.4f, 0f, 0.04f, intArrayOf(c(0xFF00E5FF), c(0xFFFFFFFF)), glow = true),
    "stars" to PSpec(4, 50, 0.011f, 0f, 0f, 0f, intArrayOf(c(0xFFFFFFFF), c(0xFFFFE9A8)), twinkle = true),
    "bubbles" to PSpec(6, 35, 0.022f, -0.12f, 0f, 0.04f, intArrayOf(c(0xFFBFF3FF)), alpha = 0.7f),
    "smoke" to PSpec(5, 10, 0.2f, -0.04f, 0.01f, 0.05f, intArrayOf(c(0xFFB0B0B0)), alpha = 0.22f),
    "fog" to PSpec(5, 8, 0.32f, 0f, 0.015f, 0.02f, intArrayOf(c(0xFFFFFFFF)), alpha = 0.16f),
    "mist" to PSpec(5, 14, 0.24f, 0f, 0.02f, 0.03f, intArrayOf(c(0xFFDDE8FF)), alpha = 0.12f),
    "ash" to PSpec(0, 80, 0.004f, 0.05f, 0.02f, 0.05f, intArrayOf(c(0xFFB8B8B8), c(0xFF8A8A8A)), alpha = 0.7f),
    "embers" to PSpec(0, 50, 0.006f, -0.2f, 0.02f, 0.05f, intArrayOf(c(0xFFFF7A1A), c(0xFFFF3D00), c(0xFFFFC107)), twinkle = true, glow = true, alpha = 1f),
    "leaves" to PSpec(2, 30, 0.02f, 0.1f, 0.03f, 0.08f, intArrayOf(c(0xFFE8892B), c(0xFFB5651D), c(0xFFC9B037))),
    "petals" to PSpec(2, 35, 0.016f, 0.08f, 0.02f, 0.08f, intArrayOf(c(0xFFFFB7D5), c(0xFFFFFFFF), c(0xFFFF8FB8))),
    "confetti" to PSpec(1, 90, 0.014f, 0.18f, 0f, 0.05f, intArrayOf(c(0xFFFF3B30), c(0xFFFFD60A), c(0xFF34C759), c(0xFF2F6BFF), c(0xFFFF2BD6), c(0xFF00E5FF))),
    "glitter" to PSpec(4, 70, 0.009f, 0.03f, 0f, 0.02f, intArrayOf(c(0xFFFFD700), c(0xFFFFFFFF)), twinkle = true),
    "gold" to PSpec(0, 90, 0.004f, -0.03f, 0.01f, 0.04f, intArrayOf(c(0xFFFFD54F), c(0xFFFFB300)), twinkle = true, glow = true),
    "orbs" to PSpec(0, 14, 0.045f, -0.03f, 0f, 0.05f, intArrayOf(c(0xFF80DEEA), c(0xFFFFFFFF)), glow = true, alpha = 0.45f),
    "droplets" to PSpec(6, 30, 0.014f, 0.05f, 0f, 0.01f, intArrayOf(c(0xFFD6F0FF)), alpha = 0.6f),
    "lightp" to PSpec(0, 70, 0.005f, -0.04f, 0f, 0.05f, WHITE, twinkle = true, glow = true),
    "electricp" to PSpec(0, 50, 0.004f, -0.05f, 0f, 0.1f, intArrayOf(c(0xFF00E5FF), c(0xFFFFFFFF)), twinkle = true, glow = true),
    "sand" to PSpec(0, 150, 0.003f, 0.02f, 0.25f, 0.02f, intArrayOf(c(0xFFD2B48C), c(0xFFC19A6B)), alpha = 0.7f),
    "plasma" to PSpec(0, 25, 0.022f, -0.06f, 0f, 0.08f, intArrayOf(c(0xFFFF2BD6), c(0xFF8A4DFF), c(0xFF00E5FF)), glow = true, alpha = 0.55f),
)

object OverlayFx {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private fun hf(i: Int, seed: Int, k: Int): Float {
        val v = sin(i * 127.1f + seed * 311.7f + k * 74.7f) * 43758.547f
        return v - floor(v)
    }

    private fun tintInt(i: Int): Int = (0xFF000000L or TINTS[i.coerceIn(0, TINTS.lastIndex)].toLong()).toInt()

    /** tMs = time since the clip started (timeline time minus clip start). */
    fun draw(cv: Canvas, w: Int, h: Int, tMs: Long, item: FxItem, def: FxDef) {
        val spec = PARTICLES[def.group]
        if (spec != null) { particles(cv, w, h, tMs, item, def, spec); return }
        val tint = tintInt(if (item.color >= 0) item.color else def.tint)
        val t = tMs / 1000f * item.speed
        val a = item.amount
        when (def.group) {
            "bars" -> {
                p.style = Paint.Style.FILL; p.color = 0xFF000000.toInt()
                val bh = h * 0.18f * min(1f, a * 1.6f)
                cv.drawRect(0f, 0f, w.toFloat(), bh, p); cv.drawRect(0f, h - bh, w.toFloat(), h.toFloat(), p)
            }
            "letterbox" -> {
                p.style = Paint.Style.FILL; p.color = 0xFF000000.toInt()
                val bh = max(0f, (h - w / 2.39f) / 2f)
                cv.drawRect(0f, 0f, w.toFloat(), bh, p); cv.drawRect(0f, h - bh, w.toFloat(), h.toFloat(), p)
            }
            "dust" -> {
                val f = (t * 12f).toInt()
                p.style = Paint.Style.FILL
                for (i in 0 until (10 + 40 * a).toInt()) {
                    val x = hf(i, f, 1) * w; val y = hf(i, f, 2) * h; val r = (0.0015f + 0.003f * hf(i, f, 3)) * h
                    p.color = 0xFFFFFFFF.toInt(); p.alpha = (120 + 100 * hf(i, f, 4)).toInt()
                    cv.drawCircle(x, y, r, p)
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = max(1f, h * 0.0012f)
                for (i in 0 until 3) {
                    if (hf(i, f, 9) > 0.5f) {
                        val x = hf(i, f, 5) * w; val y = hf(i, f, 6) * h
                        path.reset(); path.moveTo(x, y)
                        path.quadTo(x + (hf(i, f, 7) - 0.5f) * h * 0.1f, y + h * 0.04f, x + (hf(i, f, 8) - 0.5f) * h * 0.08f, y + h * 0.09f)
                        p.color = 0xFFFFFFFF.toInt(); p.alpha = 110; cv.drawPath(path, p)
                    }
                }
            }
            "scratches" -> {
                val f = (t * 12f).toInt()
                p.style = Paint.Style.STROKE; p.strokeWidth = max(1f, h * 0.0012f)
                for (i in 0 until 2) {
                    if (hf(i, f, 1) < 0.35f + 0.4f * a) {
                        val x = hf(i, f, 2) * w; val y0 = hf(i, f, 3) * h * 0.5f
                        p.color = 0xFFFFFFFF.toInt(); p.alpha = (60 + 120 * hf(i, f, 5)).toInt()
                        cv.drawLine(x, y0, x + (hf(i, f, 6) - 0.5f) * 6f, y0 + h * (0.3f + 0.6f * hf(i, f, 4)), p)
                    }
                }
            }
            "lightning" -> {
                val period = 1.6f
                val cyc = floor(t / period).toInt()
                val ph = t - cyc * period
                if (ph < 0.28f) {
                    val k = 1f - ph / 0.28f
                    p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.alpha = (50 * k * a).toInt()
                    cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
                    bolt(cv, w * (0.2f + 0.6f * hf(cyc, item.seed, 1)), 0f, w * (0.2f + 0.6f * hf(cyc, item.seed, 2)), h.toFloat(), cyc, h, tint, k * (0.6f + 0.4f * a))
                }
            }
            "arc" -> {
                val f = (t * 14f).toInt()
                bolt(cv, w * 0.15f, h * 0.5f, w * 0.85f, h * 0.5f, f, h, tint, 0.6f + 0.4f * a)
            }
            "circle" -> magicCircle(cv, w, h, t, a, tint)
            "beam" -> {
                val th = h * (0.012f + 0.02f * a) * (1f + 0.25f * sin(t * 12f))
                p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
                p.color = tint; p.alpha = 70; p.strokeWidth = th * 4f; cv.drawLine(0f, h * 0.5f, w.toFloat(), h * 0.5f, p)
                p.alpha = 150; p.strokeWidth = th * 2f; cv.drawLine(0f, h * 0.5f, w.toFloat(), h * 0.5f, p)
                p.color = 0xFFFFFFFF.toInt(); p.alpha = 255; p.strokeWidth = th; cv.drawLine(0f, h * 0.5f, w.toFloat(), h * 0.5f, p)
            }
        }
    }

    private fun bolt(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, cyc: Int, h: Int, tint: Int, k: Float) {
        path.reset(); path.moveTo(x0, y0)
        val n = 14
        for (i in 1 until n) {
            val f = i / n.toFloat()
            val jx = (hf(i, cyc, 11) - 0.5f) * h * 0.14f
            val jy = (hf(i, cyc, 12) - 0.5f) * h * 0.03f
            path.lineTo(x0 + (x1 - x0) * f + jx, y0 + (y1 - y0) * f + jy)
        }
        path.lineTo(x1, y1)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = tint; p.alpha = (80 * k).toInt(); p.strokeWidth = h * 0.03f; cv.drawPath(path, p)
        p.alpha = (160 * k).toInt(); p.strokeWidth = h * 0.012f; cv.drawPath(path, p)
        p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * k).toInt(); p.strokeWidth = h * 0.004f; cv.drawPath(path, p)
    }

    private fun magicCircle(cv: Canvas, w: Int, h: Int, t: Float, a: Float, tint: Int) {
        val cx = w / 2f; val cy = h / 2f; val r = h * (0.18f + 0.18f * a)
        p.style = Paint.Style.STROKE; p.color = tint
        for (pass in 0 until 2) {
            p.alpha = if (pass == 0) 70 else 230
            p.strokeWidth = h * (if (pass == 0) 0.014f else 0.004f)
            cv.drawCircle(cx, cy, r, p); cv.drawCircle(cx, cy, r * 0.82f, p)
            for (tri in 0 until 2) {
                path.reset()
                for (i in 0 until 3) {
                    val ang = (t * (if (tri == 0) 0.6f else -0.6f)) + i * 2.0944f + tri * 1.0472f
                    val x = cx + cos(ang) * r * 0.82f; val y = cy + sin(ang) * r * 0.82f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); cv.drawPath(path, p)
            }
            for (i in 0 until 36) {
                val ang = i * (2f * PI.toFloat() / 36f) - t * 0.4f
                val r0 = if (i % 3 == 0) r * 0.9f else r * 0.95f
                cv.drawLine(cx + cos(ang) * r, cy + sin(ang) * r, cx + cos(ang) * r0, cy + sin(ang) * r0, p)
            }
        }
    }

    private fun particles(cv: Canvas, w: Int, h: Int, tMs: Long, item: FxItem, def: FxDef, s: PSpec) {
        val t = tMs / 1000f * item.speed
        val n = (s.count * (0.25f + item.amount)).toInt().coerceAtLeast(1)
        val override = if (item.color >= 0) tintInt(item.color) else 0
        for (i in 0 until n) {
            val r1 = hf(i, item.seed, 1); val r2 = hf(i, item.seed, 2); val r3 = hf(i, item.seed, 3); val r4 = hf(i, item.seed, 4)
            var x = r1 + s.vx * t * (0.5f + r3) + s.wob * sin(t * (0.5f + r3 * 2f) + r2 * 6.28f)
            var y = r2 + s.vy * t * (0.6f + r3 * 0.8f)
            x -= floor(x); y -= floor(y)
            val px = x * w; val py = y * h
            val sz = s.size * h * (0.6f + r4 * 0.9f)
            var al = s.alpha
            if (s.twinkle) al *= 0.35f + 0.65f * (0.5f + 0.5f * sin(t * 2.5f + r1 * 20f))
            val col = if (override != 0) override else s.colors[(r4 * s.colors.size).toInt().coerceIn(0, s.colors.size - 1)]
            p.style = Paint.Style.FILL; p.color = col
            when (s.shape) {
                0 -> {
                    if (s.glow) { p.alpha = (al * 70).toInt(); cv.drawCircle(px, py, sz * 3f, p) }
                    p.alpha = (al * 255).toInt(); cv.drawCircle(px, py, sz, p)
                }
                1 -> {
                    cv.save(); cv.rotate((t * 180f * (r3 - 0.5f) * 2f) + r1 * 360f, px, py)
                    p.alpha = (al * 255).toInt(); rect.set(px - sz, py - sz * 0.5f, px + sz, py + sz * 0.5f); cv.drawRect(rect, p); cv.restore()
                }
                2 -> {
                    cv.save(); cv.rotate(t * 90f * (r3 - 0.5f) * 2f + r1 * 360f, px, py)
                    p.alpha = (al * 255).toInt(); rect.set(px - sz, py - sz * 0.55f, px + sz, py + sz * 0.55f); cv.drawOval(rect, p); cv.restore()
                }
                3 -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = max(1f, h * 0.0025f); p.alpha = (al * 255).toInt()
                    cv.drawLine(px, py, px - sz * s.vx * 1.2f, py - sz, p)
                }
                4 -> {
                    p.alpha = (al * 255).toInt()
                    path.reset(); path.moveTo(px, py - sz * 1.6f); path.lineTo(px + sz * 0.3f, py - sz * 0.3f); path.lineTo(px + sz * 1.6f, py)
                    path.lineTo(px + sz * 0.3f, py + sz * 0.3f); path.lineTo(px, py + sz * 1.6f); path.lineTo(px - sz * 0.3f, py + sz * 0.3f)
                    path.lineTo(px - sz * 1.6f, py); path.lineTo(px - sz * 0.3f, py - sz * 0.3f); path.close()
                    cv.drawPath(path, p)
                    if (s.glow) { p.alpha = (al * 60).toInt(); cv.drawCircle(px, py, sz * 2.5f, p) }
                }
                5 -> {
                    for (k in 0 until 4) { p.alpha = (al * 255 * 0.3f).toInt(); cv.drawCircle(px, py, sz * (1f - k * 0.2f), p) }
                }
                6 -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = max(1f, sz * 0.12f); p.alpha = (al * 255).toInt()
                    cv.drawCircle(px, py, sz, p)
                    p.style = Paint.Style.FILL; p.alpha = (al * 40).toInt(); cv.drawCircle(px, py, sz, p)
                }
            }
        }
    }
}

/** Overlay entries of a clip's stack, paired with their definition. */
fun overlayItems(c: Clip): List<Pair<FxItem, FxDef>> =
    c.fx.mapNotNull { i -> FX_BY_NAME[i.name]?.takeIf { it.kind == FxKind.OVERLAY }?.let { i to it } }


// ------------------------------------------------------------------ ready-made stickers (drawn in code, no PNG files needed)

data class StickerDef(val name: String, val cat: String)

val STICKER_CATS = listOf("Shapes", "Arrows", "Bubbles", "Buttons", "Badges", "Frames", "Emoji")

private val EMOJI = linkedMapOf(
    "Fire" to "\uD83D\uDD25", "Red Heart" to "\u2764\uFE0F", "Gold Star" to "\u2B50", "Laugh" to "\uD83D\uDE02",
    "Love Eyes" to "\uD83D\uDE0D", "Thumbs Up" to "\uD83D\uDC4D", "Sparkles" to "\u2728", "Hundred" to "\uD83D\uDCAF",
    "Party" to "\uD83C\uDF89", "Boom" to "\uD83D\uDCA5", "Bolt" to "\u26A1", "Music" to "\uD83C\uDFB5",
    "Crown" to "\uD83D\uDC51", "Rocket" to "\uD83D\uDE80", "Skull" to "\uD83D\uDC80", "Bell" to "\uD83D\uDD14",
)

val STICKERS: List<StickerDef> = buildList {
    for (n in listOf("Heart", "Star", "Check", "Cross", "Circle Highlight", "Underline Scribble")) add(StickerDef(n, "Shapes"))
    for (n in listOf("Arrow Right", "Arrow Left", "Arrow Up", "Arrow Down")) add(StickerDef(n, "Arrows"))
    for (n in listOf("Speech Bubble", "Thought Bubble")) add(StickerDef(n, "Bubbles"))
    for (n in listOf("Subscribe Button", "Like Button", "Follow Button", "Share Button", "Play Button", "Live Badge", "REC Badge")) add(StickerDef(n, "Buttons"))
    for (n in listOf("SALE Badge", "NEW Badge", "HOT Badge", "50% OFF Badge", "100% Badge", "BEST Badge")) add(StickerDef(n, "Badges"))
    for (n in listOf("Corner Brackets", "Frame Border")) add(StickerDef(n, "Frames"))
    for (n in EMOJI.keys) add(StickerDef(n, "Emoji"))
}

object Stickers {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rc = RectF()

    fun bitmap(key: String, size: Int): android.graphics.Bitmap {
        val b = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        draw(Canvas(b), size, size, key)
        return b
    }

    /** Draws the sticker centred in a w x h area (square, as large as fits). */
    fun draw(cv: Canvas, w: Int, h: Int, key: String) {
        val s = min(w, h).toFloat()
        cv.save(); cv.translate((w - s) / 2f, (h - s) / 2f)
        render(cv, s, key)
        cv.restore()
    }

    private fun fill(col: Int) { p.style = Paint.Style.FILL; p.color = col }
    private fun line(col: Int, wd: Float) { p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = wd; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND }
    private fun label(cv: Canvas, txt: String, cx: Float, cy: Float, size: Float, col: Int) {
        fill(col); p.textAlign = Paint.Align.CENTER; p.textSize = size; p.isFakeBoldText = true
        cv.drawText(txt, cx, cy - (p.ascent() + p.descent()) / 2f, p)
        p.isFakeBoldText = false
    }
    private fun burst(cv: Canvas, s: Float, n: Int, col: Int) {
        path.reset()
        for (i in 0 until n * 2) {
            val a = i * PI.toFloat() / n
            val r = if (i % 2 == 0) s * 0.46f else s * 0.36f
            val x = s / 2 + cos(a) * r; val y = s / 2 + sin(a) * r
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close(); fill(col); cv.drawPath(path, p); line(0xFFFFFFFF.toInt(), s * 0.015f); cv.drawPath(path, p)
    }
    private fun button(cv: Canvas, s: Float, col: Int, txt: String, txtSize: Float) {
        rc.set(s * 0.04f, s * 0.3f, s * 0.96f, s * 0.7f)
        fill(col); cv.drawRoundRect(rc, s * 0.1f, s * 0.1f, p)
        label(cv, txt, s / 2, s / 2, s * txtSize, 0xFFFFFFFF.toInt())
    }
    private fun arrow(cv: Canvas, s: Float, deg: Float) {
        cv.save(); cv.rotate(deg, s / 2, s / 2)
        path.reset()
        path.moveTo(s * 0.1f, s * 0.4f); path.lineTo(s * 0.55f, s * 0.4f); path.lineTo(s * 0.55f, s * 0.2f); path.lineTo(s * 0.9f, s * 0.5f)
        path.lineTo(s * 0.55f, s * 0.8f); path.lineTo(s * 0.55f, s * 0.6f); path.lineTo(s * 0.1f, s * 0.6f); path.close()
        fill(0xFFFFFFFF.toInt()); cv.drawPath(path, p); line(0xFF111111.toInt(), s * 0.025f); cv.drawPath(path, p)
        cv.restore()
    }

    private fun render(cv: Canvas, s: Float, key: String) {
        val c = s / 2
        EMOJI[key]?.let { label(cv, it, c, c, s * 0.7f, 0xFFFFFFFF.toInt()); return }
        when (key) {
            "Heart" -> {
                path.reset(); path.moveTo(c, s * 0.86f)
                path.cubicTo(s * 0.02f, s * 0.55f, s * 0.1f, s * 0.12f, c, s * 0.32f)
                path.cubicTo(s * 0.9f, s * 0.12f, s * 0.98f, s * 0.55f, c, s * 0.86f); path.close()
                fill(0xFFFF2D55.toInt()); cv.drawPath(path, p)
            }
            "Star" -> {
                path.reset()
                for (i in 0 until 10) {
                    val a = -PI.toFloat() / 2 + i * PI.toFloat() / 5
                    val r = if (i % 2 == 0) s * 0.46f else s * 0.2f
                    val x = c + cos(a) * r; val y = c + sin(a) * r
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); fill(0xFFFFD60A.toInt()); cv.drawPath(path, p); line(0xFFFF9F0A.toInt(), s * 0.025f); cv.drawPath(path, p)
            }
            "Check" -> {
                fill(0xFF34C759.toInt()); cv.drawCircle(c, c, s * 0.44f, p)
                line(0xFFFFFFFF.toInt(), s * 0.08f); path.reset(); path.moveTo(s * 0.28f, s * 0.52f); path.lineTo(s * 0.44f, s * 0.67f); path.lineTo(s * 0.73f, s * 0.35f); cv.drawPath(path, p)
            }
            "Cross" -> {
                fill(0xFFFF3B30.toInt()); cv.drawCircle(c, c, s * 0.44f, p)
                line(0xFFFFFFFF.toInt(), s * 0.08f); cv.drawLine(s * 0.32f, s * 0.32f, s * 0.68f, s * 0.68f, p); cv.drawLine(s * 0.68f, s * 0.32f, s * 0.32f, s * 0.68f, p)
            }
            "Circle Highlight" -> { line(0xFFFFD60A.toInt(), s * 0.05f); rc.set(s * 0.08f, s * 0.2f, s * 0.92f, s * 0.8f); cv.drawOval(rc, p) }
            "Underline Scribble" -> {
                line(0xFFFFD60A.toInt(), s * 0.04f); path.reset(); path.moveTo(s * 0.06f, s * 0.55f)
                for (i in 0 until 6) { val x = s * (0.06f + 0.15f * (i + 1)); path.quadTo(x - s * 0.075f, if (i % 2 == 0) s * 0.4f else s * 0.7f, x, s * 0.55f) }
                cv.drawPath(path, p)
            }
            "Arrow Right" -> arrow(cv, s, 0f)
            "Arrow Down" -> arrow(cv, s, 90f)
            "Arrow Left" -> arrow(cv, s, 180f)
            "Arrow Up" -> arrow(cv, s, 270f)
            "Speech Bubble" -> {
                rc.set(s * 0.06f, s * 0.12f, s * 0.94f, s * 0.66f)
                fill(0xFFFFFFFF.toInt()); cv.drawRoundRect(rc, s * 0.12f, s * 0.12f, p)
                path.reset(); path.moveTo(s * 0.22f, s * 0.64f); path.lineTo(s * 0.16f, s * 0.9f); path.lineTo(s * 0.42f, s * 0.64f); path.close(); cv.drawPath(path, p)
                fill(0xFF222222.toInt()); for (i in 0 until 3) cv.drawCircle(s * (0.35f + 0.15f * i), s * 0.39f, s * 0.035f, p)
            }
            "Thought Bubble" -> {
                fill(0xFFFFFFFF.toInt())
                cv.drawCircle(s * 0.35f, s * 0.35f, s * 0.2f, p); cv.drawCircle(s * 0.55f, s * 0.28f, s * 0.2f, p); cv.drawCircle(s * 0.72f, s * 0.4f, s * 0.18f, p)
                rc.set(s * 0.2f, s * 0.35f, s * 0.85f, s * 0.58f); cv.drawRoundRect(rc, s * 0.1f, s * 0.1f, p)
                cv.drawCircle(s * 0.28f, s * 0.72f, s * 0.06f, p); cv.drawCircle(s * 0.2f, s * 0.86f, s * 0.035f, p)
            }
            "Subscribe Button" -> button(cv, s, 0xFFFF0033.toInt(), "SUBSCRIBE", 0.13f)
            "Like Button" -> button(cv, s, 0xFF2F6BFF.toInt(), "LIKE", 0.17f)
            "Follow Button" -> button(cv, s, 0xFFFF2BA6.toInt(), "FOLLOW", 0.16f)
            "Share Button" -> button(cv, s, 0xFF1DB954.toInt(), "SHARE", 0.16f)
            "Live Badge" -> button(cv, s, 0xFFE50914.toInt(), "\u25CF LIVE", 0.17f)
            "REC Badge" -> { rc.set(s * 0.15f, s * 0.33f, s * 0.85f, s * 0.67f); fill(0xCC000000.toInt()); cv.drawRoundRect(rc, s * 0.17f, s * 0.17f, p); fill(0xFFFF3B30.toInt()); cv.drawCircle(s * 0.3f, c, s * 0.07f, p); label(cv, "REC", s * 0.58f, c, s * 0.16f, 0xFFFFFFFF.toInt()) }
            "Play Button" -> {
                rc.set(s * 0.06f, s * 0.22f, s * 0.94f, s * 0.78f); fill(0xFFFF0000.toInt()); cv.drawRoundRect(rc, s * 0.16f, s * 0.16f, p)
                path.reset(); path.moveTo(s * 0.42f, s * 0.36f); path.lineTo(s * 0.42f, s * 0.64f); path.lineTo(s * 0.67f, c); path.close(); fill(0xFFFFFFFF.toInt()); cv.drawPath(path, p)
            }
            "SALE Badge" -> { burst(cv, s, 14, 0xFFFF3B30.toInt()); label(cv, "SALE", c, c, s * 0.2f, 0xFFFFFFFF.toInt()) }
            "NEW Badge" -> { burst(cv, s, 12, 0xFFFFD60A.toInt()); label(cv, "NEW", c, c, s * 0.22f, 0xFF111111.toInt()) }
            "HOT Badge" -> { burst(cv, s, 12, 0xFFFF6A00.toInt()); label(cv, "HOT", c, c, s * 0.22f, 0xFFFFFFFF.toInt()) }
            "50% OFF Badge" -> { burst(cv, s, 16, 0xFF1DB954.toInt()); label(cv, "50%", c, s * 0.44f, s * 0.2f, 0xFFFFFFFF.toInt()); label(cv, "OFF", c, s * 0.62f, s * 0.15f, 0xFFFFFFFF.toInt()) }
            "100% Badge" -> { burst(cv, s, 14, 0xFF8A4DFF.toInt()); label(cv, "100%", c, c, s * 0.18f, 0xFFFFFFFF.toInt()) }
            "BEST Badge" -> { burst(cv, s, 18, 0xFFFFB300.toInt()); label(cv, "BEST", c, c, s * 0.17f, 0xFF111111.toInt()) }
            "Corner Brackets" -> {
                line(0xFFFFFFFF.toInt(), s * 0.03f); val a = s * 0.08f; val b = s * 0.92f; val l = s * 0.22f
                cv.drawLine(a, a, a + l, a, p); cv.drawLine(a, a, a, a + l, p); cv.drawLine(b, a, b - l, a, p); cv.drawLine(b, a, b, a + l, p)
                cv.drawLine(a, b, a + l, b, p); cv.drawLine(a, b, a, b - l, p); cv.drawLine(b, b, b - l, b, p); cv.drawLine(b, b, b, b - l, p)
            }
            "Frame Border" -> { line(0xFFFFFFFF.toInt(), s * 0.035f); rc.set(s * 0.06f, s * 0.06f, s * 0.94f, s * 0.94f); cv.drawRoundRect(rc, s * 0.06f, s * 0.06f, p) }
        }
    }
}
