@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList

/** Overlay settings for a text / V2 clip: opacity, scale, rotation from the intro/outro animation, plus keyframed position / zoom / rotation / opacity. */
private fun clipSettings(clip: Clip, presentationTimeUs: Long, visible: Boolean = true): OverlaySettings {
    val t = presentationTimeUs / 1000L
    val rel = (t - clip.startMs).coerceAtLeast(0)
    val (alpha, sc, rot) = overlayAnim(clip, rel)
    val b = OverlaySettings.Builder()
    if (clip.keys.isEmpty()) {
        return b.setAlphaScale(if (visible) alpha * clip.opacity else 0f).setScale(sc, sc).setRotationDegrees(rot).build()
    }
    // keyframed clips are rendered neutral (centre, scale 1, no rotation); motion is applied here
    val lc = liveClip(clip, rel)
    return b.setAlphaScale(if (visible) alpha * lc.opacity else 0f)
        .setScale(sc * lc.scale, sc * lc.scale)
        .setRotationDegrees(rot - lc.rotation)
        .setBackgroundFrameAnchor(lc.posX, -lc.posY)
        .build()
}

/** Clip with position / scale / rotation reset, used for the bitmap when the motion comes from keyframes. */
private fun neutral(c: Clip): Clip = if (c.keys.isEmpty()) c else c.copy(posX = 0f, posY = 0f, scale = 1f, rotation = 0f)

/** A full-frame transparent bitmap that carries one text / image-overlay clip. Timing and animation come from getOverlaySettings. */
private class TimedOverlay(
    private val clip: Clip,
    private val bmp: Bitmap,
    private val blank: Bitmap,
) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = presentationTimeUs / 1000L
        return clipSettings(clip, presentationTimeUs, t >= clip.startMs && t < clip.endMs)
    }
}

/** Procedural effect layer (particles, dust, bars...) shown only while its clip plays. Full-frame bitmaps, ping-pong so Media3 re-uploads. */
private class FxTimedOverlay(
    private val clip: Clip, private val item: FxItem, private val def: FxDef, private val bw: Int, private val bh: Int,
) : BitmapOverlay() {
    private val bmps = arrayOf(Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888))
    private val cvs = arrayOf(Canvas(bmps[0]), Canvas(bmps[1]))
    private val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private var flip = 0

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val t = presentationTimeUs / 1000L
        if (t < clip.startMs || t >= clip.endMs) return blank
        flip = flip xor 1
        bmps[flip].eraseColor(Color.TRANSPARENT)
        OverlayFx.draw(cvs[flip], bw, bh, t - clip.startMs, item, def)
        return bmps[flip]
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = OverlaySettings.Builder().build()
}

/** Text clip whose letters / words appear over time: re-rendered each frame. */
private class RevealTextOverlay(private val clip: Clip, private val w: Int, private val h: Int) : BitmapOverlay() {
    private var flip = 0
    private val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private var cache: Array<Bitmap?> = arrayOfNulls(2)
    private var lastText = "\u0000"

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val t = presentationTimeUs / 1000L
        if (t < clip.startMs || t >= clip.endMs) return blank
        val s = revealText(clip, t - clip.startMs)
        if (s == lastText && cache[flip] != null) return cache[flip]!!
        flip = flip xor 1
        cache[flip] = Exporter.textFrame(neutral(clip), w, h, s)
        lastText = s
        return cache[flip]!!
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = clipSettings(clip, presentationTimeUs)
}

object Exporter {

    private fun decode(ctx: Context, clip: Clip, maxSide: Int): Bitmap? {
        val uri = clip.uri ?: return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > maxSide * 2 || o.outHeight / sample > maxSide * 2) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    fun textFrame(c: Clip, w: Int, h: Int, text: String = c.text): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = c.textColor.toInt()
            textSize = c.textSize * h / 1080f
            textAlign = Paint.Align.CENTER
            setShadowLayer(6f, 0f, 3f, Color.argb(160, 0, 0, 0))
        }
        val cx = w / 2f + c.posX * w / 2f
        val cy = h / 2f + c.posY * h / 2f
        cv.save()
        cv.translate(cx, cy)
        cv.rotate(c.rotation)
        cv.scale(c.scale, c.scale)
        val lines = text.split("\n")
        val lh = p.fontSpacing
        var y = -(lines.size - 1) * lh / 2f - (p.ascent() + p.descent()) / 2f
        for (l in lines) {
            when (c.textStyle) {
                "Outline" -> {
                    val o = Paint(p).apply { style = Paint.Style.STROKE; strokeWidth = p.textSize * 0.14f; color = Color.BLACK; clearShadowLayer(); strokeJoin = Paint.Join.ROUND }
                    cv.drawText(l, 0f, y, o); cv.drawText(l, 0f, y, p)
                }
                "Neon" -> {
                    val g = Paint(p).apply { setShadowLayer(p.textSize * 0.5f, 0f, 0f, c.textColor.toInt()); color = Color.WHITE }
                    cv.drawText(l, 0f, y, g); cv.drawText(l, 0f, y, g)
                }
                "Gold" -> {
                    val g = Paint(p).apply {
                        shader = android.graphics.LinearGradient(0f, y - p.textSize * 0.8f, 0f, y + p.textSize * 0.2f,
                            intArrayOf(0xFFFFE27A.toInt(), 0xFFC9931A.toInt(), 0xFFFFF1B0.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
                    }
                    cv.drawText(l, 0f, y, g)
                }
                else -> cv.drawText(l, 0f, y, p)
            }
            y += lh
        }
        cv.restore()
        return bmp
    }

    private fun imageFrame(ctx: Context, c: Clip, w: Int, h: Int): Bitmap? {
        val src = (if (c.sticker.isNotEmpty()) Stickers.bitmap(c.sticker, 512) else decode(ctx, c, maxOf(w, h))) ?: return null
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val target = w * 0.45f * c.scale
        val k = target / src.width
        val cx = w / 2f + c.posX * w / 2f
        val cy = h / 2f + c.posY * h / 2f
        cv.save()
        cv.translate(cx, cy)
        cv.rotate(c.rotation)
        cv.scale(k, k)
        cv.drawBitmap(src, -src.width / 2f, -src.height / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        cv.restore()
        return bmp
    }

    /** Clip volume (0..1) applied to the exported audio; matrices for mono and stereo sources. */
    private fun volumeProcessors(v: Float): List<AudioProcessor> {
        if (v >= 0.999f) return emptyList()
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return listOf(p)
    }

    /** Audio chain for one clip: speed (pitch kept) then volume. */
    private fun audioChain(c: Clip): List<AudioProcessor> {
        val list = ArrayList<AudioProcessor>()
        if (c.speed != 1f) list.add(SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) })
        list.addAll(volumeProcessors(c.volume))
        return list
    }

    /** Returns null when V1 is empty. */
    fun build(ctx: Context, clips: List<Clip>, outW: Int, outH: Int): Composition? {
        val v1 = clips.filter { it.track == TRACK_V1 }.sortedBy { it.startMs }
        if (v1.isEmpty()) return null
        val hasImage = v1.any { it.type == ClipType.IMAGE }

        val videoItems = v1.map { c ->
            val vfx = if (c.type == ClipType.VIDEO && c.speed != 1f) listOf<Effect>(SpeedChangeEffect(c.speed)) + buildEffects(c) else buildEffects(c)
            val fx = Effects(if (c.type == ClipType.VIDEO) audioChain(c) else emptyList(), vfx)
            if (c.type == ClipType.IMAGE) {
                val mi = MediaItem.Builder().setUri(c.uri).setImageDurationMs(c.durationMs).build()
                EditedMediaItem.Builder(mi)
                    .setDurationUs(c.durationMs * 1000L)
                    .setFrameRate(30)
                    .setEffects(fx)
                    .build()
            } else {
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.inMs)
                    .setEndPositionMs(c.inMs + c.srcSpanMs)
                    .build()
                val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(clipping).build()
                EditedMediaItem.Builder(mi)
                    .setRemoveAudio(hasImage) // photos have no audio; keeps the sequence consistent
                    .setEffects(fx)
                    .build()
            }
        }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence.Builder(*videoItems.toTypedArray()).build())

        val audio = clips.filter { it.track == TRACK_A1 && it.uri != null }.sortedBy { it.startMs }
        if (audio.isNotEmpty()) {
            val items = audio.map { c ->
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.inMs)
                    .setEndPositionMs(c.inMs + c.srcSpanMs)
                    .build()
                EditedMediaItem.Builder(
                    MediaItem.Builder().setUri(c.uri).setClippingConfiguration(clipping).build()
                ).setEffects(Effects(audioChain(c), emptyList())).build()
            }
            sequences.add(EditedMediaItemSequence.Builder(*items.toTypedArray()).build())
        }

        val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val overlays = ArrayList<TextureOverlay>()
        for (c in v1) for ((item, def) in overlayItems(c)) overlays.add(FxTimedOverlay(c, item, def, outW, outH))
        for (c in clips.sortedBy { it.track }.reversed()) {
            if (c.track == TRACK_TEXT && c.type == ClipType.TEXT && c.textAnim in REVEAL_ANIMS) {
                overlays.add(RevealTextOverlay(c, outW, outH)); continue
            }
            val bmp = when {
                c.track == TRACK_TEXT && c.type == ClipType.TEXT -> textFrame(neutral(c), outW, outH)
                c.track == TRACK_V2 && c.type == ClipType.IMAGE -> imageFrame(ctx, neutral(c), outW, outH)
                else -> null
            } ?: continue
            overlays.add(TimedOverlay(c, bmp, blank))
        }

        val videoFx = ArrayList<Effect>()
        videoFx.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT))
        if (overlays.isNotEmpty()) videoFx.add(OverlayEffect(ImmutableList.copyOf(overlays)))

        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), videoFx))
            .build()
    }
}
