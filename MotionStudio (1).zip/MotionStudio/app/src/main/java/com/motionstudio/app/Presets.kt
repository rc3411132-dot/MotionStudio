package com.motionstudio.app

/** One-tap look for a video / photo clip: filter + colour + live effect + intro/outro. */
data class LookPreset(
    val name: String,
    val filter: String,
    val strength: Float = 1f,
    val adjust: Adjust = Adjust(),
    val live: String = "None",
    val animIn: String = "None",
    val animOut: String = "None",
    val fx: List<FxItem> = emptyList(),
)

private fun f(name: String, amt: Float? = null, speed: Float? = null, color: Int = -1): FxItem {
    val d = FX_BY_NAME[name]
    return FxItem(name, amt ?: d?.amt ?: 0.6f, speed ?: d?.speed ?: 1f, d?.angle ?: 0f, 1, color)
}

val LOOK_PRESETS = listOf(
    LookPreset("Cinematic Teal", "Teal & Orange", 1f, Adjust(contrast = 0.08f), "None", "Zoom In", "None"),
    LookPreset("Vlog Bright", "Soft Skin", 1f, Adjust(brightness = 0.04f, saturation = 0.1f), "None", "Pop", "None"),
    LookPreset("Reels Pop", "HDR Pop", 0.9f, Adjust(saturation = 0.1f), "Zoom Pulse", "Elastic", "Slide Left"),
    LookPreset("Travel Warm", "Golden Hour", 1f, Adjust(contrast = 0.05f), "None", "Slide Right", "Zoom Out"),
    LookPreset("Retro VHS", "Retro VHS", 1f, Adjust(), "RGB Glitch", "Shake", "None"),
    LookPreset("Dreamy Glow", "Dreamy", 1f, Adjust(), "Zoom Pulse", "Zoom In", "Zoom Out"),
    LookPreset("Dark Moody", "Moody", 1f, Adjust(), "None", "None", "Zoom Out"),
    LookPreset("Anime Vivid", "Anime", 1f, Adjust(), "None", "Pop", "None"),
    LookPreset("Wedding Soft", "Pastel", 0.9f, Adjust(brightness = 0.03f), "None", "Zoom In", "None"),
    LookPreset("Gaming Neon", "Cyberpunk", 1f, Adjust(), "RGB Glitch", "Spiral", "None"),
    LookPreset("Beat Drop", "Punch", 0.8f, Adjust(), "Heartbeat", "Drop", "None"),
    LookPreset("Dream Wobble", "Rose", 1f, Adjust(), "Wobble", "Swing", "None"),
    LookPreset("Party Hue", "Vivid", 0.8f, Adjust(), "Hue Cycle", "Bounce", "None"),
    LookPreset("Old Film", "Sepia", 1f, Adjust(contrast = 0.05f), "Shake Cam", "None", "None"),
    LookPreset("Hype Flash", "HDR Pop", 1f, Adjust(), "Flash", "Pop", "Spiral"),
    LookPreset("Clean Noir", "Noir", 1f, Adjust(), "None", "Zoom In", "None"),
    // ---- trending styles (filter + effect stack)
    LookPreset("Velocity Edit", "Punch", 0.8f, Adjust(), "None", "Zoom In", "None", listOf(f("Hyperzoom", 0.6f), f("Zoom Blur", 0.35f), f("Chromatic Aberration", 0.4f))),
    LookPreset("Dark Gaming Edit", "Moody Dark", 1f, Adjust(), "None", "Pop", "None", listOf(f("RGB Split", 0.4f), f("Vignette", 0.6f), f("Film Grain", 0.3f), f("Digital Glitch", 0.3f))),
    LookPreset("Cinematic Pro", "Teal & Orange", 1f, Adjust(), "None", "Zoom In", "None", listOf(f("Cinematic Vignette", 0.6f), f("Film Grain", 0.35f), f("Cinematic Black Bars", 0.6f), f("Cinematic Zoom", 0.3f))),
    LookPreset("Cyberpunk Edit", "Cyberpunk Color", 1f, Adjust(), "None", "Drop", "None", listOf(f("Chromatic Aberration", 0.5f), f("Neon Glow", 0.5f), f("Scanline Effect", 0.3f), f("RGB Split", 0.3f))),
    LookPreset("Dreamy Edit", "Dreamy", 1f, Adjust(), "None", "Zoom In", "Zoom Out", listOf(f("Soft Glow", 0.6f), f("Soft Focus", 0.3f), f("Light Leak", 0.4f), f("Breathing Zoom", 0.4f))),
    LookPreset("3D Motion Edit", "Vivid", 0.8f, Adjust(), "None", "Elastic", "None", listOf(f("Camera Orbit", 0.6f), f("Chromatic Aberration", 0.3f), f("Dolly Zoom", 0.4f))),
    LookPreset("AMV Edit", "Anime", 1f, Adjust(), "None", "Pop", "None", listOf(f("Hyperzoom", 0.5f), f("Flash Effect", 0.4f), f("Radial Blur", 0.3f), f("Sparkle", 0.5f))),
    LookPreset("Anime Edit", "Anime", 1f, Adjust(), "None", "Zoom In", "None", listOf(f("Anime Style Edge", 0.4f), f("Soft Glow", 0.3f), f("Petals", 0.5f))),
    LookPreset("Phonk Edit", "Moody", 1f, Adjust(), "None", "Shake", "None", listOf(f("VHS Glitch", 0.7f), f("Impact Shake", 0.7f), f("Film Grain", 0.5f), f("Vignette", 0.6f))),
    LookPreset("Velocity Montage", "HDR Pop", 0.9f, Adjust(), "None", "Zoom In", "Zoom Out", listOf(f("Hyperzoom", 0.7f), f("Motion Blur", 0.4f))),
    LookPreset("Luxury Edit", "Golden Hour", 1f, Adjust(), "None", "Zoom In", "None", listOf(f("Golden Dust", 0.6f), f("Sparkle", 0.5f), f("Soft Glow", 0.4f), f("Cinematic Zoom", 0.3f))),
    LookPreset("Music Visualizer", "Neon", 0.8f, Adjust(), "None", "Pop", "None", listOf(f("Light Burst", 0.6f), f("Heartbeat Pulse", 0.7f), f("Prism Light", 0.4f))),
    LookPreset("Minimal Motion", "Matte Look", 1f, Adjust(), "None", "Slide Up", "None", listOf(f("Camera Dolly", 0.3f), f("Vignette", 0.3f))),
    LookPreset("Glitch Montage", "Vivid", 0.8f, Adjust(), "None", "Shake", "None", listOf(f("Digital Glitch", 0.7f), f("RGB Shift", 0.6f), f("Screen Flicker", 0.4f), f("Random Shake", 0.5f))),
    LookPreset("Neon Gaming", "Cyberpunk", 1f, Adjust(), "None", "Spiral", "None", listOf(f("Neon Glow", 0.8f), f("Chromatic Aberration", 0.4f), f("Electric Particles"))),
    LookPreset("Film Aesthetic", "Film Emulation", 1f, Adjust(), "None", "Zoom In", "None", listOf(f("Film Grain", 0.5f), f("Film Dust"), f("Film Gate Weave"), f("Vignette", 0.4f))),
    LookPreset("Moody Cinematic", "Moody Dark", 1f, Adjust(), "None", "Zoom In", "None", listOf(f("Cinematic Vignette", 0.7f), f("Film Grain", 0.3f), f("Fog", 0.4f), f("Cinematic Black Bars", 0.6f))),
    LookPreset("Hyperzoom Edit", "Punch", 0.8f, Adjust(), "None", "Pop", "None", listOf(f("Hyperzoom", 1f), f("Zoom Blur", 0.6f), f("Flash Effect", 0.3f))),
    LookPreset("Beat Sync Edit", "Vivid", 0.8f, Adjust(), "None", "Pop", "None", listOf(f("Heartbeat Pulse", 0.7f), f("Flash Effect", 0.3f), f("Chromatic Aberration", 0.3f))),
    LookPreset("VHS Tape Edit", "Retro VHS", 1f, Adjust(), "None", "Shake", "None", listOf(f("VHS Glitch", 0.8f), f("CRT Monitor", 0.4f), f("Film Grain", 0.4f))),
)

/** Ready-made text styles for the T1 track. posX / posY are -1..1 of the frame. */
data class TextPreset(
    val name: String,
    val text: String,
    val color: Long,
    val size: Float,
    val posX: Float = 0f,
    val posY: Float = 0f,
    val animIn: String = "Zoom In",
    val animOut: String = "Fade",
    val durationMs: Long = 3000,
)

val TEXT_PRESETS = listOf(
    TextPreset("Bold Title", "YOUR TITLE", 0xFFFFFFFF, 130f, 0f, 0f, "Pop", "Fade"),
    TextPreset("Lower Third", "Name Surname\nChannel / Role", 0xFFFFFFFF, 52f, -0.35f, 0.68f, "Slide Left", "Fade", 4000),
    TextPreset("Neon Caption", "NEON VIBES", 0xFF00C2FF, 90f, 0f, -0.2f, "Elastic", "Fade"),
    TextPreset("Subtitle", "Your subtitle here", 0xFFFFFFFF, 46f, 0f, 0.82f, "Fade", "Fade", 2500),
    TextPreset("Meme Top", "TOP TEXT", 0xFFFFFFFF, 96f, 0f, -0.78f, "Pop", "None", 2500),
    TextPreset("Meme Bottom", "BOTTOM TEXT", 0xFFFFFFFF, 96f, 0f, 0.78f, "Pop", "None", 2500),
    TextPreset("Hype Yellow", "LET'S GO!", 0xFFFFC400, 120f, 0f, 0f, "Bounce", "Zoom Out", 2500),
    TextPreset("Chapter", "Chapter 1", 0xFFFF4DA6, 76f, 0f, -0.55f, "Swing", "Fade"),
    TextPreset("Subscribe", "SUBSCRIBE", 0xFFFF3B30, 100f, 0f, 0.3f, "Elastic", "Zoom Out", 3500),
    TextPreset("Spin Logo", "BRAND", 0xFF7C5CFF, 140f, 0f, 0f, "Spiral", "Fade", 3000),
    TextPreset("Big Hook", "WAIT FOR IT...", 0xFFFFC400, 150f, 0f, -0.1f, "Pop", "Zoom Out", 2500),
    TextPreset("Plot Twist", "PLOT TWIST", 0xFFFF3B30, 130f, 0f, 0f, "Drop", "Fade", 2200),
    TextPreset("Breaking News", "BREAKING NEWS", 0xFFFF3B30, 84f, -0.1f, 0.72f, "Slide Left", "Slide Left", 4000),
    TextPreset("Trending", "TRENDING NOW", 0xFFFF4DA6, 90f, 0f, -0.6f, "Elastic", "Fade", 3000),
    TextPreset("Intro Title", "WELCOME", 0xFFFFFFFF, 160f, 0f, -0.1f, "Zoom In", "Zoom Out", 3000),
    TextPreset("Outro Thanks", "THANKS FOR WATCHING", 0xFFFFFFFF, 84f, 0f, 0f, "Slide Up", "Fade", 4000),
    TextPreset("Part Two", "PART 2", 0xFF00C2FF, 130f, 0f, 0f, "Pop", "Fade", 2000),
    TextPreset("Review Score", "9/10", 0xFF34C759, 180f, 0f, 0f, "Elastic", "Fade", 2500),
    TextPreset("Before", "BEFORE", 0xFFFFFFFF, 90f, -0.55f, -0.7f, "Slide Right", "Fade", 3000),
    TextPreset("After", "AFTER", 0xFF34C759, 90f, 0.55f, -0.7f, "Slide Left", "Fade", 3000),
    TextPreset("Step 1", "STEP 1", 0xFFFFC400, 100f, -0.45f, -0.7f, "Swing", "Fade", 3000),
    TextPreset("Pro Tip", "PRO TIP", 0xFF00C2FF, 90f, -0.5f, -0.65f, "Pop", "Fade", 3000),
    TextPreset("Warning", "WARNING!", 0xFFFF8A1F, 110f, 0f, -0.5f, "Shake", "Fade", 2500),
    TextPreset("Location Tag", "Mumbai, India", 0xFFFFFFFF, 44f, -0.5f, 0.82f, "Slide Left", "Fade", 4000),
    TextPreset("Date Stamp", "15 NOV 2026", 0xFFFFC400, 44f, 0.6f, -0.82f, "Fade", "Fade", 4000),
    TextPreset("Watermark", "@yourname", 0xFFFFFFFF, 40f, 0.65f, 0.85f, "Fade", "Fade", 8000),
    TextPreset("Quote", "\"Your quote here\"", 0xFFFFFFFF, 64f, 0f, 0f, "Fade", "Fade", 4500),
    TextPreset("Price Tag", "Rs 999", 0xFF34C759, 120f, 0f, 0.4f, "Bounce", "Zoom Out", 3000),
    TextPreset("Countdown", "3", 0xFFFFFFFF, 260f, 0f, 0f, "Zoom In", "Zoom Out", 1000),
    TextPreset("Gold Title", "GOLD", 0xFFFFD54F, 150f, 0f, 0f, "Zoom In", "Fade", 3000),
    TextPreset("Neon Pink", "NIGHT VIBES", 0xFFFF2BD6, 100f, 0f, -0.2f, "Elastic", "Fade", 3000),
    TextPreset("Neon Green", "GAME ON", 0xFF34C759, 110f, 0f, 0f, "Drop", "Fade", 3000),
    TextPreset("Comment Below", "COMMENT BELOW", 0xFFFFFFFF, 70f, 0f, 0.75f, "Slide Up", "Fade", 3500),
    TextPreset("Follow Me", "FOLLOW FOR MORE", 0xFFFF4DA6, 72f, 0f, 0.7f, "Pop", "Zoom Out", 3500),
    TextPreset("Link In Bio", "LINK IN BIO", 0xFF00C2FF, 70f, 0f, 0.75f, "Slide Up", "Fade", 3500),
)

/** Transition between a clip and the one after it: outro of the first + intro of the second. */
data class TransitionPreset(val name: String, val out: String, val into: String, val ms: Long = 500)

val TRANSITIONS = listOf(
    TransitionPreset("Zoom Through", "Zoom Out", "Zoom In"),
    TransitionPreset("Slide Left", "Slide Left", "Slide Right"),
    TransitionPreset("Slide Up", "Slide Up", "Slide Down"),
    TransitionPreset("Spin", "Spin", "Spin", 700),
    TransitionPreset("Spiral", "Spiral", "Spiral", 800),
    TransitionPreset("Pop", "Zoom Out", "Pop"),
    TransitionPreset("Drop", "Slide Up", "Drop", 600),
    TransitionPreset("Squash", "Squash", "Stretch", 450),
    TransitionPreset("Swing", "Swing", "Swing", 700),
    TransitionPreset("Elastic", "Zoom Out", "Elastic", 700),
    TransitionPreset("Whip Pan", "Slide Left", "Slide Right", 250),
    TransitionPreset("Push", "Slide Up", "Slide Down", 400),
    TransitionPreset("Pull", "Zoom Out", "Zoom In", 350),
    TransitionPreset("Velocity Zoom", "Zoom Out", "Zoom In", 250),
    TransitionPreset("Smooth Zoom", "Zoom Out", "Zoom In", 800),
    TransitionPreset("Rotation", "Spin", "Spin", 600),
    TransitionPreset("Swipe", "Slide Right", "Slide Left", 350),
    TransitionPreset("Fade Through Black", "Fade Black", "Fade Black", 500),
    TransitionPreset("Fade Through White", "Fade White", "Fade White", 500),
    TransitionPreset("Flash Transition", "Flash", "Flash", 350),
    TransitionPreset("Stretch Transition", "Stretch", "Squash", 450),
)

/** Magic Edit styles: how the auto-assembled timeline looks. */
data class MagicStyle(val name: String, val look: LookPreset, val transition: TransitionPreset, val photoMs: Long, val title: TextPreset)

val MAGIC_STYLES = listOf(
    MagicStyle("Cinematic", LOOK_PRESETS[0], TRANSITIONS[0], 3500, TEXT_PRESETS[0]),
    MagicStyle("Reels Fast", LOOK_PRESETS[2], TRANSITIONS[1], 1500, TEXT_PRESETS[6]),
    MagicStyle("Travel Vlog", LOOK_PRESETS[3], TRANSITIONS[5], 2500, TEXT_PRESETS[7]),
    MagicStyle("Party", LOOK_PRESETS[12], TRANSITIONS[4], 1800, TEXT_PRESETS[2]),
)
