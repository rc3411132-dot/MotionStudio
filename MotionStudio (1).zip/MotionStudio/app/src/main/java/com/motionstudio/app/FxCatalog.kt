package com.motionstudio.app

import android.graphics.Matrix
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

enum class FxKind { SHADER, MOTION, OVERLAY }

/**
 * group: SHADER -> shader file (blur/glitch/warp/style/light/grade); MOTION -> "motion"; OVERLAY -> overlay key.
 * mode: shader mode id (see assets/shaders). amt/speed/angle/tint are the defaults shown in the sliders.
 */
data class FxDef(
    val name: String, val cat: String, val kind: FxKind, val group: String, val mode: Float = 0f,
    val amt: Float = 0.6f, val speed: Float = 1f, val angle: Float = 0f, val tint: Int = 0,
)

val TINTS = listOf(0xFFFFFF, 0x00E5FF, 0xFF2BD6, 0xFF3B30, 0xFF8A1F, 0xFFD60A, 0x34C759, 0x2F6BFF, 0x8A4DFF, 0xFF7AB8)
fun tintRgb(i: Int): FloatArray {
    val c = TINTS[i.coerceIn(0, TINTS.lastIndex)]
    return floatArrayOf((c shr 16 and 0xFF) / 255f, (c shr 8 and 0xFF) / 255f, (c and 0xFF) / 255f)
}

val FX_CATEGORIES = listOf("Blur", "Glitch", "Glow", "Warp", "Art", "Cinema", "Camera", "Particles", "VFX")

val FX_LIST: List<FxDef> = buildList {
    fun s(cat: String, name: String, group: String, mode: Int, amt: Float = 0.6f, angle: Float = 0f, tint: Int = 0, speed: Float = 1f) =
        add(FxDef(name, cat, FxKind.SHADER, group, mode.toFloat(), amt, speed, angle, tint))
    fun mo(name: String, amt: Float = 0.5f, speed: Float = 1f, angle: Float = 0f) =
        add(FxDef(name, "Camera", FxKind.MOTION, "motion", 0f, amt, speed, angle))
    fun ov(cat: String, name: String, key: String, amt: Float = 0.6f, speed: Float = 1f, tint: Int = 0) =
        add(FxDef(name, cat, FxKind.OVERLAY, key, 0f, amt, speed, 0f, tint))

    // ---- Blur
    s("Blur", "Gaussian Blur", "blur", 1, 0.5f); s("Blur", "Box Blur", "blur", 1, 0.4f); s("Blur", "Fast Blur", "blur", 1, 0.3f)
    s("Blur", "Lens Blur", "blur", 1, 0.7f); s("Blur", "Camera Lens Blur", "blur", 1, 0.6f); s("Blur", "Bokeh Blur", "blur", 1, 0.95f)
    s("Blur", "Circular Blur", "blur", 1, 0.8f); s("Blur", "Soft Focus", "blur", 1, 0.2f)
    s("Blur", "Motion Blur", "blur", 2, 0.5f, 0f); s("Blur", "Directional Blur", "blur", 2, 0.6f, 0.785f)
    s("Blur", "Horizontal Blur", "blur", 2, 0.6f, 0f); s("Blur", "Vertical Blur", "blur", 2, 0.6f, 1.5708f)
    s("Blur", "Pixel Motion Blur", "blur", 2, 0.3f, 0.3f)
    s("Blur", "Zoom Blur", "blur", 3, 0.6f); s("Blur", "Hyper Zoom Blur", "blur", 3, 1f)
    s("Blur", "Spin Blur", "blur", 4, 0.6f); s("Blur", "Radial Blur", "blur", 4, 0.4f)
    s("Blur", "Tilt Shift Blur", "blur", 5, 0.8f); s("Blur", "Edge Blur", "blur", 6, 0.7f)
    s("Blur", "Focus Blur", "blur", 6, 0.5f); s("Blur", "Cinematic Defocus", "blur", 6, 1f)
    s("Blur", "RGB Blur", "blur", 10, 0.6f)

    // ---- Glitch
    s("Glitch", "RGB Split", "blur", 7, 0.5f); s("Glitch", "RGB Shift", "blur", 7, 0.8f, 1.5708f)
    s("Glitch", "Color Channel Shift", "blur", 7, 0.6f, 0.785f); s("Glitch", "Chromatic Aberration", "blur", 8, 0.6f)
    s("Glitch", "Pixelate", "blur", 9, 0.5f); s("Glitch", "Mosaic", "blur", 9, 0.3f)
    s("Glitch", "Digital Glitch", "glitch", 20, 0.6f); s("Glitch", "Horizontal Glitch", "glitch", 20, 0.6f, 0f)
    s("Glitch", "Vertical Glitch", "glitch", 20, 0.6f, 1.2f); s("Glitch", "Block Glitch", "glitch", 24, 0.5f)
    s("Glitch", "Digital Tear", "glitch", 21, 0.6f); s("Glitch", "Screen Flicker", "glitch", 22, 0.6f)
    s("Glitch", "Signal Distortion", "glitch", 23, 0.6f); s("Glitch", "Pixel Displacement", "glitch", 23, 0.35f)
    s("Glitch", "Data Corruption", "glitch", 24, 0.9f); s("Glitch", "VHS Glitch", "glitch", 25, 0.7f)
    s("Glitch", "CRT Monitor", "glitch", 26, 0.6f); s("Glitch", "Retro TV", "glitch", 26, 0.95f)
    s("Glitch", "TV Static", "glitch", 27, 0.8f); s("Glitch", "Digital Noise", "glitch", 27, 0.3f)
    s("Glitch", "Scanline Effect", "glitch", 28, 0.6f); s("Glitch", "Digital Wave", "warp", 40, 0.6f, 0f, 0, 1.4f)
    s("Glitch", "Cyberpunk Distortion", "glitch", 20, 0.8f, 0.2f)

    // ---- Glow & light
    s("Glow", "Glow", "light", 80, 0.5f); s("Glow", "Soft Glow", "light", 80, 0.3f); s("Glow", "Deep Glow", "light", 80, 1f, 0f, 2)
    s("Glow", "Neon Glow", "light", 80, 0.8f, 0f, 1); s("Glow", "Outer Glow", "light", 80, 0.6f, 0f, 5)
    s("Glow", "Inner Glow", "light", 80, 0.45f, 0f, 4); s("Glow", "LED Glow", "light", 80, 0.7f, 0f, 6)
    s("Glow", "Energy Glow", "light", 80, 0.8f, 0f, 4); s("Glow", "Electric Glow", "light", 81, 0.7f, 0f, 1)
    s("Glow", "Laser Light", "light", 82, 0.8f, 0f, 3); s("Glow", "Lens Flare", "light", 83, 0.8f)
    s("Glow", "Sun Flare", "light", 83, 1f, -0.8f); s("Glow", "Anamorphic Flare", "light", 84, 0.8f, 0.4f)
    s("Glow", "Light Leak", "light", 85, 0.7f); s("Glow", "Light Rays", "light", 87, 0.6f, 0.8f, 5)
    s("Glow", "God Rays", "light", 87, 0.9f, -0.8f, 5); s("Glow", "Flash Effect", "light", 88, 0.6f)
    s("Glow", "Strobe Light", "light", 89, 0.6f); s("Glow", "Sparkle", "light", 90, 0.7f)
    s("Glow", "Star Glow", "light", 90, 1f); s("Glow", "Light Sweep", "light", 86, 0.7f, 0.6f)
    s("Glow", "Light Burst", "light", 92, 0.7f); s("Glow", "Light Trails", "light", 93, 0.7f, 0f, 1)
    s("Glow", "Prism Light", "light", 91, 0.7f); s("Glow", "Holographic Glow", "light", 94, 0.7f)

    // ---- Warp / distortion
    s("Warp", "Wave Warp", "warp", 40, 0.6f); s("Warp", "Warp", "warp", 40, 0.35f); s("Warp", "Ripple", "warp", 41, 0.6f)
    s("Warp", "Circular Wave", "warp", 41, 0.95f); s("Warp", "Twirl", "warp", 42, 0.5f); s("Warp", "Bulge", "warp", 43, 0.6f)
    s("Warp", "Pinch", "warp", 44, 0.6f); s("Warp", "Spherize", "warp", 45, 0.7f); s("Warp", "Lens Distortion", "warp", 46, 0.5f)
    s("Warp", "Barrel Distortion", "warp", 46, 0.8f); s("Warp", "Pincushion Distortion", "warp", 47, 0.6f)
    s("Warp", "Fisheye", "warp", 48, 0.6f); s("Warp", "Turbulent Displace", "warp", 49, 0.6f)
    s("Warp", "Shockwave", "warp", 50, 0.7f); s("Warp", "Heat Distortion", "warp", 51, 0.6f)
    s("Warp", "Glass Distortion", "warp", 52, 0.6f); s("Warp", "Water Distortion", "warp", 53, 0.6f)
    s("Warp", "Mirror", "warp", 54); s("Warp", "Mirror Vertical", "warp", 55); s("Warp", "Kaleidoscope", "warp", 56, 0.4f)
    s("Warp", "Elastic Warp", "warp", 57, 0.6f); s("Warp", "Stretch", "warp", 57, 0.9f)
    s("Warp", "Liquid Motion", "warp", 58, 0.5f); s("Warp", "Liquify", "warp", 58, 0.9f, 0f, 0, 0.5f)

    // ---- Art / stylise
    s("Art", "Sharpen", "style", 60, 0.5f); s("Art", "Unsharp Mask", "style", 60, 0.3f)
    s("Art", "Detail Enhancement", "style", 77, 0.6f); s("Art", "Dehaze", "style", 77, 1f)
    s("Art", "Denoise", "style", 78, 0.5f); s("Art", "Posterize", "style", 61, 0.6f)
    s("Art", "Cartoon", "style", 62, 0.7f); s("Art", "Comic Book", "style", 62, 1f); s("Art", "Anime Style Edge", "style", 62, 0.5f)
    s("Art", "Sketch", "style", 63, 0.9f); s("Art", "Pencil Drawing", "style", 63, 0.5f)
    s("Art", "Edge Detection", "style", 64, 1f); s("Art", "Outline Effect", "style", 64, 0.5f)
    s("Art", "Neon Outline", "style", 65, 0.9f, 0f, 1); s("Art", "Neon Outline Pink", "style", 65, 0.9f, 0f, 2)
    s("Art", "Color Halftone", "style", 66, 0.6f); s("Art", "Halftone", "style", 67, 0.6f)
    s("Art", "Duotone Blue", "style", 68, 0.9f, 0f, 1); s("Art", "Duotone Sunset", "style", 68, 0.9f, 0f, 4)
    s("Art", "Duotone Violet", "style", 68, 0.9f, 0f, 8); s("Art", "Tritone", "style", 69, 0.9f, 0f, 5)
    s("Art", "Thermal Vision", "style", 70, 1f); s("Art", "Infrared Style", "style", 71, 0.9f)
    s("Art", "Silhouette", "style", 72, 0.8f, 0f, 4); s("Art", "Oil Painting", "style", 73, 0.5f)
    s("Art", "Watercolor", "style", 79, 0.6f); s("Art", "Pixel Art", "style", 74, 0.5f)
    s("Art", "Mosaic Art", "style", 74, 0.25f); s("Art", "X-Ray Style", "style", 75, 0.9f); s("Art", "Invert", "style", 76, 1f)

    // ---- Cinema
    s("Cinema", "Vignette", "grade", 101, 0.5f); s("Cinema", "Cinematic Vignette", "grade", 101, 0.85f)
    s("Cinema", "Film Grain", "grade", 102, 0.5f); s("Cinema", "Heavy Grain", "grade", 102, 1f)
    s("VFX", "Circle Mask", "grade", 104, 0.5f); s("VFX", "Box Mask", "grade", 105, 0.6f)
    s("VFX", "Heart Mask", "grade", 106, 0.6f); s("VFX", "Strip Mask", "grade", 107, 0.5f)
    s("Cinema", "Film Flicker", "grade", 103, 0.6f); s("Cinema", "Film Burn", "light", 85, 1f, 0f, 4)
    ov("Cinema", "Cinematic Black Bars", "bars", 0.6f); ov("Cinema", "Letterbox 2.39", "letterbox", 1f)
    ov("Cinema", "Film Dust", "dust", 0.6f); ov("Cinema", "Film Scratches", "scratches", 0.6f)

    // ---- Camera / shake / motion (MatrixTransformation)
    mo("Smooth Camera Shake"); mo("Impact Shake", 0.7f); mo("Directional Shake", 0.6f, 1f, 0.785f); mo("Random Shake", 0.6f, 1.6f)
    mo("Rotation Shake", 0.5f); mo("Zoom Shake", 0.5f); mo("Horizontal Shake", 0.6f, 1f, 0f); mo("Vertical Shake", 0.6f, 1f, 1.5708f)
    mo("Micro Shake", 0.3f, 1.4f); mo("Handheld Movement", 0.5f, 0.6f); mo("Camera Zoom In", 0.5f); mo("Camera Zoom Out", 0.5f)
    mo("Camera Pan", 0.5f, 0.5f, 0f); mo("Camera Tilt", 0.5f, 0.5f, 1.5708f); mo("Camera Roll", 0.5f, 0.5f); mo("Camera Orbit", 0.5f, 0.6f)
    mo("Camera Dolly", 0.5f, 0.5f); mo("Cinematic Zoom", 0.4f, 0.3f); mo("Hyperzoom", 0.8f, 1f); mo("Lens Breathing", 0.4f, 0.5f)
    mo("Film Gate Weave", 0.3f, 1f); mo("Dolly Zoom", 0.7f, 0.5f); mo("Pendulum Motion", 0.6f, 0.7f); mo("Wave Animation", 0.5f, 1f)
    mo("Loop Spin", 0.5f, 0.5f); mo("Heartbeat Pulse", 0.6f, 1f); mo("Breathing Zoom", 0.5f, 0.6f); mo("Drift", 0.4f, 0.4f, 0.5f)

    // ---- Particles (Canvas overlays)
    ov("Particles", "Dust Particles", "dustp"); ov("Particles", "Snowfall", "snow"); ov("Particles", "Rainfall", "rain")
    ov("Particles", "Fireflies", "fireflies", 0.6f, 1f, 5); ov("Particles", "Floating Sparks", "sparks", 0.6f, 1f, 4)
    ov("Particles", "Magic Particles", "magic", 0.6f, 1f, 8); ov("Particles", "Energy Particles", "energy", 0.6f, 1f, 1)
    ov("Particles", "Star Particles", "stars", 0.6f, 1f, 5); ov("Particles", "Bubble Particles", "bubbles", 0.6f, 1f, 1)
    ov("Particles", "Smoke Particles", "smoke"); ov("Particles", "Fog", "fog"); ov("Particles", "Mist", "mist")
    ov("Particles", "Ash Particles", "ash"); ov("Particles", "Fire Embers", "embers", 0.6f, 1f, 4)
    ov("Particles", "Falling Leaves", "leaves", 0.6f, 1f, 4); ov("Particles", "Petals", "petals", 0.6f, 1f, 9)
    ov("Particles", "Confetti", "confetti"); ov("Particles", "Glitter", "glitter", 0.6f, 1f, 5)
    ov("Particles", "Golden Dust", "gold", 0.6f, 1f, 5); ov("Particles", "Floating Orbs", "orbs", 0.5f, 1f, 1)
    ov("Particles", "Water Droplets", "droplets", 0.6f, 1f, 1); ov("Particles", "Light Particles", "lightp")
    ov("Particles", "Electric Particles", "electricp", 0.6f, 1f, 1); ov("Particles", "Sand Particles", "sand", 0.6f, 1f, 4)
    ov("Particles", "Plasma Particles", "plasma", 0.6f, 1f, 2)

    // ---- VFX
    s("VFX", "Hologram", "glitch", 29, 0.8f); s("VFX", "Portal Twirl", "warp", 42, 0.9f, 0f, 0, 1.2f)
    s("VFX", "Shockwave Ring", "warp", 50, 1f); s("VFX", "Energy Wave", "warp", 41, 0.8f, 0f, 1)
    ov("VFX", "Lightning Visual", "lightning", 0.6f, 1f, 1); ov("VFX", "Electric Arc Visual", "arc", 0.6f, 1f, 1)
    ov("VFX", "Magic Circle", "circle", 0.7f, 1f, 8); ov("VFX", "Energy Beam", "beam", 0.7f, 1f, 1)
}

val FX_BY_NAME: Map<String, FxDef> = FX_LIST.associateBy { it.name }

// ------------------------------------------------------------------ MOTION effects -> Matrix (NDC space)

private fun pingpong(t: Float, period: Float): Float { val x = (t / period) % 2f; return if (x < 1f) x else 2f - x }
private fun h1(a: Float): Float { val v = sin(a * 12.9898f) * 43758.547f; return v - kotlin.math.floor(v) }

fun motionMatrix(name: String, tMs: Long, amt: Float, speed: Float, angle: Float, seed: Int): Matrix {
    val t = tMs / 1000f * speed
    val m = Matrix()
    val a = amt
    val s = seed.toFloat()
    val pi = PI.toFloat()
    val ca = cos(angle); val sa = sin(angle)
    fun nz(k: Float) = sin(t * k + s) + 0.5f * sin(t * k * 2.3f + s * 1.7f)
    when (name) {
        "Smooth Camera Shake" -> { m.postScale(1f + 0.06f * a, 1f + 0.06f * a); m.postTranslate(0.02f * a * nz(7f), 0.02f * a * nz(5.3f)); m.postRotate(0.6f * a * nz(4f)) }
        "Impact Shake" -> {
            val d = exp(-((tMs % 1000L) / 1000f) * 5f)
            m.postScale(1f + 0.07f * a, 1f + 0.07f * a)
            m.postTranslate(0.05f * a * d * sin(t * 90f + s), 0.05f * a * d * sin(t * 77f))
            m.postRotate(1.2f * a * d * sin(t * 60f))
        }
        "Directional Shake" -> { val k = 0.04f * a * sin(t * 40f + s); m.postScale(1f + 0.06f * a, 1f + 0.06f * a); m.postTranslate(k * ca, k * sa) }
        "Random Shake" -> { val q = (t * 24f).toInt().toFloat(); m.postScale(1f + 0.07f * a, 1f + 0.07f * a); m.postTranslate((h1(q + s) - 0.5f) * 0.06f * a, (h1(q + s + 9f) - 0.5f) * 0.06f * a) }
        "Rotation Shake" -> { m.postScale(1f + 0.08f * a, 1f + 0.08f * a); m.postRotate(2.5f * a * sin(t * 18f + s)) }
        "Zoom Shake" -> { val z = 1f + 0.05f * a * (1f + sin(t * 22f + s)); m.postScale(z, z) }
        "Horizontal Shake" -> { m.postScale(1f + 0.06f * a, 1f + 0.06f * a); m.postTranslate(0.04f * a * sin(t * 40f + s), 0f) }
        "Vertical Shake" -> { m.postScale(1f + 0.06f * a, 1f + 0.06f * a); m.postTranslate(0f, 0.04f * a * sin(t * 40f + s)) }
        "Micro Shake" -> { m.postScale(1f + 0.02f * a, 1f + 0.02f * a); m.postTranslate(0.006f * a * nz(31f), 0.006f * a * nz(27f)) }
        "Handheld Movement" -> { m.postScale(1f + 0.08f * a, 1f + 0.08f * a); m.postTranslate(0.02f * a * nz(1.7f), 0.02f * a * nz(1.3f)); m.postRotate(0.8f * a * nz(1.1f)) }
        "Camera Zoom In" -> { val z = 1f + 0.5f * a * pingpong(t, 4f); m.postScale(z, z) }
        "Camera Zoom Out" -> { val z = 1f + 0.5f * a * (1f - pingpong(t, 4f)); m.postScale(z, z) }
        "Camera Pan" -> { m.postScale(1f + 0.25f * a, 1f + 0.25f * a); val k = 0.25f * a * (pingpong(t, 4f) - 0.5f) * 2f; m.postTranslate(k * ca, k * sa) }
        "Camera Tilt" -> { m.postScale(1f + 0.25f * a, 1f + 0.25f * a); val k = 0.25f * a * (pingpong(t, 4f) - 0.5f) * 2f; m.postTranslate(k * ca, k * sa); m.postRotate(2f * a * (pingpong(t, 4f) - 0.5f)) }
        "Camera Roll" -> { m.postScale(1.5f, 1.5f); m.postRotate(t * 36f * a) }
        "Camera Orbit" -> { m.postScale(1f + 0.3f * a, 1f + 0.3f * a); m.postTranslate(0.12f * a * cos(t * 1.5f), 0.12f * a * sin(t * 1.5f)); m.postRotate(2f * a * sin(t * 1.5f)) }
        "Camera Dolly" -> { val z = 1f + 0.3f * a * pingpong(t, 3f); m.postScale(z, z); m.postTranslate(0f, -0.04f * a * pingpong(t, 3f)) }
        "Cinematic Zoom" -> { val z = 1f + 0.18f * a * pingpong(t, 6f); m.postScale(z, z) }
        "Hyperzoom" -> { val p = (t % 1f); val e = 1f - (1f - p) * (1f - p) * (1f - p); val z = 1f + 0.9f * a * e; m.postScale(z, z) }
        "Lens Breathing" -> { val z = 1f + 0.06f * a * sin(t * 2f); m.postScale(z, z) }
        "Film Gate Weave" -> { val q = (t * 24f).toInt().toFloat(); m.postScale(1f + 0.03f * a, 1f + 0.03f * a); m.postTranslate((h1(q + s) - 0.5f) * 0.012f * a, (h1(q + 5f) - 0.5f) * 0.012f * a) }
        "Dolly Zoom" -> { val z = 1f + 0.6f * a * pingpong(t, 3f); m.postScale(z, z); m.postRotate(1.5f * a * (pingpong(t, 3f) - 0.5f)) }
        "Pendulum Motion" -> { m.postScale(1.3f, 1.3f); m.postRotate(12f * a * sin(t * 2f)) }
        "Wave Animation" -> { m.postScale(1.15f, 1.15f); m.postTranslate(0.04f * a * sin(t * 2f), 0.05f * a * sin(t * 3f)); m.postRotate(1.5f * a * sin(t * 2f)) }
        "Loop Spin" -> { m.postScale(1.5f, 1.5f); m.postRotate(t * 90f * a) }
        "Heartbeat Pulse" -> { val ph = ((tMs * speed) % 800f) / 800f; val v = (1f - ph * 3f).coerceAtLeast(0f); val z = 1f + 0.09f * a * v; m.postScale(z, z) }
        "Breathing Zoom" -> { val z = 1.04f + 0.05f * a * sin(2f * pi * t / 2.5f); m.postScale(z, z) }
        "Drift" -> { m.postScale(1.2f, 1.2f); m.postTranslate(0.06f * a * sin(t * 0.6f) * ca + 0.02f * a * t.coerceAtMost(8f) * 0f, 0.06f * a * cos(t * 0.5f) * (if (abs(sa) < 0.01f) 1f else sa)) }
    }
    return m
}
