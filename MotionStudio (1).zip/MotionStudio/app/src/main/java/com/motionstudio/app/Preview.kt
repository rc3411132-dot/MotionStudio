package com.motionstudio.app

import android.graphics.BitmapFactory
import android.view.SurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun PreviewPanel(vm: EditorVM, accent: Color) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0A0B0D))) {
        Box(Modifier.weight(1f).fillMaxWidth().padding(6.dp), contentAlignment = Alignment.Center) {
            Frame(vm)
        }
        Transport(vm, accent)
    }
}

@Composable
private fun Frame(vm: EditorVM) {
    val head = vm.playheadMs
    val v1 = vm.clips.firstOrNull { it.track == TRACK_V1 && head >= it.startMs && head < it.endMs }
    val overlays = vm.clips.filter { (it.track == TRACK_V2 || it.track == TRACK_TEXT) && head >= it.startMs && head < it.endMs }
    val hasVideoOnV1 = vm.clips.any { it.track == TRACK_V1 && it.type == ClipType.VIDEO }

    BoxWithConstraints(Modifier.aspectRatio(vm.aspect).background(Color.Black)) {
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        if (hasVideoOnV1) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                AndroidView(
                    factory = { ctx -> SurfaceView(ctx).also { vm.videoPlayer.player.setVideoSurfaceView(it) } },
                    modifier = Modifier.fillMaxSize().aspectRatio(vm.videoPlayer.videoAspect),
                )
            }
        }
        // anything that is not the live video frame covers the surface with black
        if (v1 == null || v1.type != ClipType.VIDEO) {
            Box(Modifier.fillMaxSize().background(Color.Black))
        }
        if (v1 != null && v1.type == ClipType.IMAGE) {
            val (a, s, r) = overlayAnim(v1, head - v1.startMs)
            val lv = liveClip(v1, head - v1.startMs)
            ImageLayer(v1, Modifier.fillMaxSize().graphicsLayer {
                alpha = a * v1.opacity; scaleX = lv.scale * s; scaleY = lv.scale * s; rotationZ = lv.rotation + r
                translationX = lv.posX * w / 2f; translationY = lv.posY * h / 2f
            }, ContentScale.Fit, previewColorFilter(v1))
        }
        if (v1 != null) {
            val fxOv = overlayItems(v1)
            if (fxOv.isNotEmpty()) {
                Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { cv ->
                        for ((item, def) in fxOv) OverlayFx.draw(cv.nativeCanvas, size.width.toInt(), size.height.toInt(), head - v1.startMs, item, def)
                    }
                }
            }
        }
        overlays.sortedByDescending { it.track }.forEach { c0 ->
            val c = liveClip(c0, head - c0.startMs)
            val (a, s, r) = overlayAnim(c, head - c.startMs)
            val ox = (c.posX * w / 2f).roundToInt()
            val oy = (c.posY * h / 2f).roundToInt()
            if (c.type == ClipType.TEXT) {
                val sp = (c.textSize * h / 1080f) / LocalDensityScale()
                Box(Modifier.fillMaxSize().offset { IntOffset(ox, oy) }, contentAlignment = Alignment.Center) {
                    StyledText(
                        c, revealText(c, head - c.startMs), sp,
                        Modifier.graphicsLayer {
                            alpha = a * c.opacity; scaleX = c.scale * s; scaleY = c.scale * s; rotationZ = c.rotation + r
                        },
                    )
                }
            } else {
                Box(Modifier.fillMaxSize().offset { IntOffset(ox, oy) }, contentAlignment = Alignment.Center) {
                    if (c.sticker.isNotEmpty()) {
                        Canvas(Modifier.fillMaxSize(0.45f).graphicsLayer {
                            alpha = a * c.opacity; scaleX = c.scale * s; scaleY = c.scale * s; rotationZ = c.rotation + r
                        }) { drawIntoCanvas { Stickers.draw(it.nativeCanvas, size.width.toInt(), size.height.toInt(), c.sticker) } }
                    } else ImageLayer(c, Modifier.fillMaxSize(0.45f * 1f).graphicsLayer {
                        alpha = a * c.opacity; scaleX = c.scale * s; scaleY = c.scale * s; rotationZ = c.rotation + r
                    }, ContentScale.Fit)
                }
            }
        }
    }
}

/** Text with the clip's style: Plain, Outline (stroke behind fill), Neon (white core + coloured glow), Gold (gradient). */
@Composable
private fun StyledText(c: Clip, text: String, sp: Float, modifier: Modifier) {
    val dens = androidx.compose.ui.platform.LocalDensity.current.density
    val base = androidx.compose.ui.text.TextStyle(
        fontSize = sp.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = (sp * 1.15f).sp,
    )
    val col = Color(c.textColor)
    Box(modifier, contentAlignment = Alignment.Center) {
        when (c.textStyle) {
            "Outline" -> {
                Text(text, style = base.copy(color = Color.Black, drawStyle = androidx.compose.ui.graphics.drawscope.Stroke(width = sp * dens * 0.2f)))
                Text(text, style = base.copy(color = col))
            }
            "Neon" -> {
                val glow = base.copy(color = Color.White, shadow = androidx.compose.ui.graphics.Shadow(col, androidx.compose.ui.geometry.Offset.Zero, sp * dens * 0.6f))
                Text(text, style = glow); Text(text, style = glow)
            }
            "Gold" -> Text(text, style = base.copy(brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(Color(0xFFFFE27A), Color(0xFFC9931A), Color(0xFFFFF1B0)))))
            else -> Text(text, style = base.copy(color = col))
        }
    }
}

@Composable
private fun LocalDensityScale(): Float = androidx.compose.ui.platform.LocalDensity.current.density

@Composable
private fun ImageLayer(c: Clip, modifier: Modifier, scale: ContentScale, filter: androidx.compose.ui.graphics.ColorFilter? = null) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? by produceState<ImageBitmap?>(null, c.uri) {
        val uri = c.uri ?: return@produceState
        value = withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }?.asImageBitmap()
            } catch (_: Exception) { null }
        }
    }
    bmp?.let { Image(it, null, modifier, contentScale = scale, colorFilter = filter) }
}

@Composable
private fun Transport(vm: EditorVM, accent: Color) {
    Row(
        Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF111317)).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(fmtTime(vm.playheadMs), color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(" / ${fmtTime(vm.totalMs)}", color = MUTED, fontSize = 11.sp)
        Box(Modifier.weight(1f))
        Icon(Icons.Filled.SkipPrevious, "start", tint = TXT, modifier = Modifier.size(26.dp).clickable { vm.seek(0) }.padding(3.dp))
        Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "play", tint = Color.White,
            modifier = Modifier.padding(horizontal = 6.dp).size(28.dp).background(accent, androidx.compose.foundation.shape.CircleShape)
                .clickable { vm.togglePlay() }.padding(3.dp))
        Icon(Icons.Filled.SkipNext, "end", tint = TXT, modifier = Modifier.size(26.dp).clickable { vm.seek(vm.totalMs) }.padding(3.dp))
        Box(Modifier.weight(1f))
        listOf("16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 4f / 5f).forEach { (l, a) ->
            Chip(l, kotlin.math.abs(vm.aspect - a) < 0.01f, accent) { vm.aspect = a }
        }
    }
}
