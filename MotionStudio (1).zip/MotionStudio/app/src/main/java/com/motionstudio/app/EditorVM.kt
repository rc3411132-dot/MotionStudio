@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

data class MediaInfo(val id: Long, val name: String, val uri: Uri, val type: ClipType, val durationMs: Long)

class EditorVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()

    val clips = mutableStateListOf<Clip>()
    val bin = mutableStateListOf<MediaInfo>()
    var selectedId by mutableStateOf<Long?>(null)
    var playheadMs by mutableLongStateOf(0L)
    var playing by mutableStateOf(false)
    var pxPerSec by mutableFloatStateOf(90f)      // timeline zoom (dp per second)
    var aspect by mutableFloatStateOf(16f / 9f)
    var status by mutableStateOf("Ready")
    var exportProgress by mutableFloatStateOf(-1f)  // <0 = idle
    var lastExport by mutableStateOf<String?>(null)

    val prefs = UiPrefs(app)
    val videoPlayer = SlavePlayer(app, true)
    val audioPlayer = SlavePlayer(app, false)

    private var nextId = 1L
    private val undoStack = ArrayDeque<List<Clip>>()
    private val redoStack = ArrayDeque<List<Clip>>()
    private var lastSnapAt = 0L
    private var tickerRunning = false

    val totalMs: Long get() = clips.maxOfOrNull { it.endMs } ?: 0L
    val selected: Clip? get() = clips.firstOrNull { it.id == selectedId }

    // ------------------------------------------------------------ undo / redo
    fun snapshot(force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastSnapAt < 600) { lastSnapAt = now; return }
        lastSnapAt = now
        undoStack.addLast(clips.toList())
        if (undoStack.size > 80) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(clips.toList())
        clips.clear(); clips.addAll(prev); sync()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(clips.toList())
        clips.clear(); clips.addAll(next); sync()
    }

    // ------------------------------------------------------------ media bin
    fun importMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) { uris.mapNotNull { probe(it) } }
            bin.addAll(added)
            status = "${added.size} file(s) imported"
        }
    }

    private fun probe(uri: Uri): MediaInfo? {
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val type = when {
            mime.startsWith("video") -> ClipType.VIDEO
            mime.startsWith("image") -> ClipType.IMAGE
            mime.startsWith("audio") -> ClipType.AUDIO
            else -> return null
        }
        var dur = 5000L
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "media"
        if (type != ClipType.IMAGE) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
            } catch (_: Exception) {
            } finally { r.release() }
        }
        return MediaInfo(nextId++, name, uri, type, dur)
    }

    fun addToTimeline(m: MediaInfo, asOverlay: Boolean = false) {
        snapshot(true)
        val track = when {
            m.type == ClipType.AUDIO -> TRACK_A1
            asOverlay && m.type == ClipType.IMAGE -> TRACK_V2
            else -> TRACK_V1
        }
        val start = clips.filter { it.track == track }.maxOfOrNull { it.endMs } ?: 0L
        val c = Clip(nextId++, m.type, m.name, m.uri, track, start, m.durationMs, sourceMs = m.durationMs,
            scale = if (track == TRACK_V2) 0.8f else 1f)
        clips.add(c)
        selectedId = c.id
        sync()
    }

    fun addText(preset: String = "Your text") {
        snapshot(true)
        val c = Clip(nextId++, ClipType.TEXT, "Text", null, TRACK_TEXT,
            fitStart(TRACK_TEXT, playheadMs, 3000, -1), 3000, text = preset, animIn = "Zoom In", animOut = "Fade")
        clips.add(c)
        selectedId = c.id
    }

    // ------------------------------------------------------------ editing ops
    fun update(id: Long, f: (Clip) -> Clip) {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        snapshot()
        clips[i] = f(clips[i])
        sync()
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        snapshot(true)
        clips.removeAll { it.id == id }
        selectedId = null
        sync()
    }

    fun duplicateSelected() {
        val c = selected ?: return
        snapshot(true)
        val copy = c.copy(id = nextId++, startMs = fitStart(c.track, c.endMs, c.durationMs, -1))
        clips.add(copy)
        selectedId = copy.id
    }

    fun splitAtPlayhead() {
        val c = selected ?: clips.firstOrNull { it.track == TRACK_V1 && playheadMs > it.startMs && playheadMs < it.endMs } ?: return
        if (playheadMs <= c.startMs + 100 || playheadMs >= c.endMs - 100) { status = "Playhead clip ke andar rakho"; return }
        snapshot(true)
        val cut = playheadMs - c.startMs
        val i = clips.indexOfFirst { it.id == c.id }
        clips[i] = c.copy(durationMs = cut)
        val right = c.copy(id = nextId++, startMs = playheadMs, durationMs = c.durationMs - cut,
            inMs = c.inMs + (cut * c.speed).toLong(), animIn = "None")
        clips.add(right)
        clips[i] = clips[i].copy(animOut = "None")
        selectedId = right.id
        sync()
    }

    /** Moves a clip; overlapping clips on the same track get pushed behind the clip they hit. */
    fun moveClip(id: Long, newStart: Long, newTrack: Int) {
        val c = clips.firstOrNull { it.id == id } ?: return
        val ok = c.type in TRACKS[newTrack].accepts
        val track = if (ok) newTrack else c.track
        val i = clips.indexOfFirst { it.id == id }
        clips[i] = c.copy(track = track, startMs = fitStart(track, newStart.coerceAtLeast(0), c.durationMs, id))
        sync()
    }

    // ---- keyframes: value of a property at the playhead (time is relative to the clip start)
    fun setKey(id: Long, prop: String, value: Float) {
        val c = clips.firstOrNull { it.id == id } ?: return
        val t = (playheadMs - c.startMs).coerceIn(0L, c.durationMs)
        val rest = c.keys.filter { !(it.prop == prop && kotlin.math.abs(it.tMs - t) < 60) }
        update(id) { it.copy(keys = (rest + Keyframe(t, prop, value)).sortedBy { k -> k.tMs }) }
    }

    fun removeKey(id: Long, k: Keyframe) = update(id) { it.copy(keys = it.keys - k) }

    fun clearKeys(id: Long, prop: String? = null) = update(id) { it.copy(keys = if (prop == null) emptyList() else it.keys.filter { k -> k.prop != prop }) }

    /** Changes video/audio speed; the clip gets shorter/longer on the timeline (later clips on the track are not moved unless they collide). */
    fun setSpeed(id: Long, s: Float) {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = clips[i]
        if (c.type != ClipType.VIDEO && c.type != ClipType.AUDIO) return
        snapshot(true)
        val span = c.srcSpanMs
        val nd = (span / s).toLong().coerceAtLeast(200)
        clips[i] = c.copy(speed = s, durationMs = nd, startMs = fitStart(c.track, c.startMs, nd, id))
        sync()
        status = "Speed ${s}x"
    }

    fun trimClip(id: Long, newStart: Long, newDur: Long, newIn: Long) {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        clips[i] = clips[i].copy(startMs = newStart, durationMs = newDur.coerceAtLeast(200), inMs = newIn.coerceAtLeast(0))
        sync()
    }

    private fun fitStart(track: Int, start: Long, dur: Long, exceptId: Long): Long {
        var s = start.coerceAtLeast(0)
        val others = clips.filter { it.track == track && it.id != exceptId }.sortedBy { it.startMs }
        repeat(others.size + 1) {
            val hit = others.firstOrNull { s < it.endMs && s + dur > it.startMs } ?: return s
            s = hit.endMs
        }
        return s
    }

    // ------------------------------------------------------------ playback
    fun seek(ms: Long) {
        playheadMs = ms.coerceIn(0, totalMs.coerceAtLeast(1))
        sync()
    }

    fun togglePlay() {
        if (playing) { playing = false; sync(); return }
        if (playheadMs >= totalMs) playheadMs = 0
        playing = true
        sync()
        if (!tickerRunning) {
            tickerRunning = true
            viewModelScope.launch {
                var last = SystemClock.uptimeMillis()
                while (playing) {
                    delay(33)
                    val now = SystemClock.uptimeMillis()
                    playheadMs += now - last
                    last = now
                    if (playheadMs >= totalMs) { playing = false; playheadMs = totalMs }
                    sync()
                }
                tickerRunning = false
            }
        }
    }

    fun sync() {
        val v = clips.firstOrNull { it.track == TRACK_V1 && it.type == ClipType.VIDEO && playheadMs >= it.startMs && playheadMs < it.endMs }
        val a = clips.firstOrNull { it.track == TRACK_A1 && playheadMs >= it.startMs && playheadMs < it.endMs }
        videoPlayer.sync(v, playheadMs, playing)
        audioPlayer.sync(a, playheadMs, playing)
    }

    // ------------------------------------------------------------ AI: auto enhance (on-device, histogram based)
    fun autoEnhance(id: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        if (c.type != ClipType.VIDEO && c.type != ClipType.IMAGE) { status = "Auto Enhance sirf video/photo par"; return }
        status = "Auto Enhance chal raha hai..."
        viewModelScope.launch {
            val adj = withContext(Dispatchers.Default) { analyse(c) }
            if (adj == null) { status = "Frame read nahi hua"; return@launch }
            update(id) { it.copy(adjust = adj) }
            status = "Auto Enhance applied"
        }
    }

    private fun analyse(c: Clip): Adjust? {
        val uri = c.uri ?: return null
        val raw: Bitmap? = if (c.type == ClipType.VIDEO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                r.getFrameAtTime((c.inMs + c.srcSpanMs / 2) * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (_: Exception) { null } finally { r.release() }
        } else {
            val o = BitmapFactory.Options().apply { inSampleSize = 8 }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        }
        val bmp = raw ?: return null
        val s = Bitmap.createScaledBitmap(bmp, 64, 64, true)
        var sumL = 0.0; var sumL2 = 0.0; var sumS = 0.0
        val n = 64 * 64
        for (y in 0 until 64) for (x in 0 until 64) {
            val p = s.getPixel(x, y)
            val r = (p shr 16 and 0xFF) / 255.0
            val g = (p shr 8 and 0xFF) / 255.0
            val b = (p and 0xFF) / 255.0
            val l = 0.299 * r + 0.587 * g + 0.114 * b
            val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
            sumL += l; sumL2 += l * l
            sumS += if (mx > 0) (mx - mn) / mx else 0.0
        }
        val mean = sumL / n
        val sd = sqrt((sumL2 / n - mean * mean).coerceAtLeast(0.0))
        val sat = sumS / n
        return Adjust(
            brightness = ((0.5 - mean) * 0.6).toFloat().coerceIn(-0.3f, 0.3f),
            contrast = ((0.22 - sd) * 1.5).toFloat().coerceIn(0f, 0.35f),
            saturation = ((0.35 - sat) * 0.8).toFloat().coerceIn(-0.3f, 0.3f),
            warmth = 0f,
        )
    }

    // ------------------------------------------------------------ presets / transitions
    val markers = mutableStateListOf<Long>()   // beat markers (timeline ms)
    var bpm by mutableStateOf(0)
    var aiBusy by mutableStateOf(false)

    private fun animsFor(c: Clip) = if (c.track == TRACK_V1 && c.type == ClipType.VIDEO) VIDEO_ANIMATIONS else ANIMATIONS

    private fun withLook(c: Clip, p: LookPreset): Clip {
        val an = animsFor(c)
        return c.copy(
            filter = p.filter, filterStrength = p.strength, adjust = p.adjust, liveFx = p.live, fx = p.fx,
            animIn = if (p.animIn in an) p.animIn else "None", animOut = if (p.animOut in an) p.animOut else "None",
        )
    }

    fun applyLook(p: LookPreset, all: Boolean) {
        val targets = if (all) clips.filter { it.track == TRACK_V1 }.map { it.id }
        else listOfNotNull(selected?.takeIf { it.type == ClipType.VIDEO || it.type == ClipType.IMAGE }?.id)
        if (targets.isEmpty()) { status = if (all) "V1 par koi clip nahi" else "Pehle video/photo clip select karo"; return }
        snapshot(true)
        for (i in clips.indices) if (clips[i].id in targets) clips[i] = withLook(clips[i], p)
        sync()
        status = "Preset: ${p.name}"
    }

    fun setLiveFx(fx: String) {
        val c = selected
        if (c == null || c.track != TRACK_V1) { status = "V1 track ka video/photo clip select karo"; return }
        update(c.id) { it.copy(liveFx = fx) }
    }

    fun addTextPreset(p: TextPreset) {
        val sel = selected
        snapshot(true)
        if (sel != null && sel.type == ClipType.TEXT) {
            val i = clips.indexOfFirst { it.id == sel.id }
            clips[i] = sel.copy(textColor = p.color, textSize = p.size, posX = p.posX, posY = p.posY, animIn = p.animIn, animOut = p.animOut)
            status = "Text style: ${p.name}"
            return
        }
        val c = Clip(nextId++, ClipType.TEXT, p.name, null, TRACK_TEXT, fitStart(TRACK_TEXT, playheadMs, p.durationMs, -1),
            p.durationMs, text = p.text, textColor = p.color, textSize = p.size, posX = p.posX, posY = p.posY,
            animIn = p.animIn, animOut = p.animOut)
        clips.add(c)
        selectedId = c.id
    }

    /** Outro on the selected V1 clip + intro on the clip after it. */
    fun applyTransition(t: TransitionPreset) {
        val c = selected
        if (c == null || c.track != TRACK_V1) { status = "V1 par clip select karo (transition uske end par lagta hai)"; return }
        val next = clips.filter { it.track == TRACK_V1 && it.startMs >= c.endMs }.minByOrNull { it.startMs }
        snapshot(true)
        val i = clips.indexOfFirst { it.id == c.id }
        clips[i] = c.copy(animOut = t.out, animMs = t.ms)
        if (next != null) {
            val j = clips.indexOfFirst { it.id == next.id }
            clips[j] = next.copy(animIn = t.into, animMs = t.ms)
            status = "Transition: ${t.name}"
        } else status = "Transition sirf outro laga (aage koi clip nahi)"
        sync()
    }

    // ------------------------------------------------------------ AI: frame analysis
    private class Stats(val mean: Double, val sd: Double, val sat: Double, val r: Double, val g: Double, val b: Double)

    private fun frameStats(c: Clip): Stats? {
        val uri = c.uri ?: return null
        val raw: Bitmap? = if (c.type == ClipType.VIDEO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                r.getFrameAtTime((c.inMs + c.srcSpanMs / 2) * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (_: Exception) { null } finally { r.release() }
        } else {
            val o = BitmapFactory.Options().apply { inSampleSize = 8 }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        }
        val bmp = raw ?: return null
        val s = Bitmap.createScaledBitmap(bmp, 64, 64, true)
        var sl = 0.0; var sl2 = 0.0; var ss = 0.0; var sr = 0.0; var sg = 0.0; var sb = 0.0
        val n = 64 * 64
        for (y in 0 until 64) for (x in 0 until 64) {
            val p = s.getPixel(x, y)
            val r = (p shr 16 and 0xFF) / 255.0; val g = (p shr 8 and 0xFF) / 255.0; val b = (p and 0xFF) / 255.0
            val l = 0.299 * r + 0.587 * g + 0.114 * b
            val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
            sl += l; sl2 += l * l; ss += if (mx > 0) (mx - mn) / mx else 0.0
            sr += r; sg += g; sb += b
        }
        val mean = sl / n
        return Stats(mean, sqrt((sl2 / n - mean * mean).coerceAtLeast(0.0)), ss / n, sr / n, sg / n, sb / n)
    }

    private fun adjustFrom(st: Stats) = Adjust(
        brightness = ((0.5 - st.mean) * 0.6).toFloat().coerceIn(-0.3f, 0.3f),
        contrast = ((0.22 - st.sd) * 1.5).toFloat().coerceIn(0f, 0.35f),
        saturation = ((0.35 - st.sat) * 0.8).toFloat().coerceIn(-0.3f, 0.3f),
    )

    /** Picks the filter that suits the clip's colours, then also auto-corrects exposure. */
    fun smartLook(id: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        if (c.type != ClipType.VIDEO && c.type != ClipType.IMAGE) { status = "Smart Look sirf video/photo par"; return }
        aiBusy = true; status = "Smart Look soch raha hai..."
        viewModelScope.launch {
            val st = withContext(Dispatchers.Default) { frameStats(c) }
            aiBusy = false
            if (st == null) { status = "Frame read nahi hua"; return@launch }
            val warm = st.r - st.b
            val name = when {
                warm > 0.08 -> if (st.mean > 0.45) "Golden Hour" else "Teal & Orange"
                warm < -0.08 -> if (st.mean > 0.45) "Arctic" else "Blue Hour"
                st.sat < 0.18 -> "Vivid"
                st.sat > 0.5 -> "Cinematic"
                st.mean < 0.3 -> "HDR Pop"
                else -> "Cinematic"
            }
            update(id) { it.copy(filter = name, filterStrength = 0.85f, adjust = adjustFrom(st)) }
            status = "Smart Look: $name"
        }
    }

    fun enhanceAll() {
        val targets = clips.filter { it.track == TRACK_V1 && (it.type == ClipType.VIDEO || it.type == ClipType.IMAGE) }
        if (targets.isEmpty()) { status = "V1 par koi clip nahi"; return }
        aiBusy = true; status = "Enhance All chal raha hai..."
        viewModelScope.launch {
            snapshot(true)
            var done = 0
            for (t in targets) {
                val st = withContext(Dispatchers.Default) { frameStats(t) } ?: continue
                val i = clips.indexOfFirst { it.id == t.id }
                if (i >= 0) { clips[i] = clips[i].copy(adjust = adjustFrom(st)); done++ }
            }
            sync()
            aiBusy = false
            status = "Enhance All: $done clip(s)"
        }
    }

    // ------------------------------------------------------------ AI: audio (silence cut, beats)
    private fun audioTarget(): Clip? {
        val s = selected
        if (s != null && (s.type == ClipType.AUDIO || s.type == ClipType.VIDEO)) return s
        return clips.firstOrNull { it.track == TRACK_A1 } ?: clips.firstOrNull { it.track == TRACK_V1 && it.type == ClipType.VIDEO }
    }

    fun cutSilence() {
        val c = audioTarget()
        if (c == null || c.uri == null) { status = "Video ya audio clip select karo"; return }
        if (c.speed != 1f) { status = "Pehle clip ki speed 1x karo, phir Silence cut"; return }
        if (aiBusy) return
        aiBusy = true; status = "Silence dhoondh raha hai..."
        viewModelScope.launch {
            val env = withContext(Dispatchers.Default) { AudioAnalysis.envelope(ctx, c.uri, c.inMs, c.durationMs) }
            if (env == null) { aiBusy = false; status = "Is clip me audio nahi mila"; return@launch }
            val sil = AudioAnalysis.silentRanges(env)
            if (sil.isEmpty()) { aiBusy = false; status = "Koi lamba silence nahi mila"; return@launch }
            // keep = complement of silent ranges
            val keeps = ArrayList<Pair<Long, Long>>()
            var cur = 0L
            for ((s, e) in sil) { if (s - cur >= 200) keeps.add(cur to s); cur = e }
            if (c.durationMs - cur >= 200) keeps.add(cur to c.durationMs)
            if (keeps.isEmpty()) { aiBusy = false; status = "Sab silence hai"; return@launch }
            val total = keeps.sumOf { it.second - it.first }
            val removed = c.durationMs - total
            snapshot(true)
            for (i in clips.indices) if (clips[i].track == c.track && clips[i].startMs >= c.endMs)
                clips[i] = clips[i].copy(startMs = clips[i].startMs - removed)
            clips.removeAll { it.id == c.id }
            var pos = c.startMs
            var firstId: Long? = null
            keeps.forEachIndexed { k, (s, e) ->
                val piece = c.copy(
                    id = nextId++, startMs = pos, durationMs = e - s, inMs = c.inMs + s,
                    animIn = if (k == 0) c.animIn else "None", animOut = if (k == keeps.lastIndex) c.animOut else "None",
                )
                if (firstId == null) firstId = piece.id
                clips.add(piece); pos += e - s
            }
            selectedId = firstId
            sync()
            aiBusy = false
            status = "Silence cut: ${sil.size} pause hata diye (${removed / 1000.0}s)"
        }
    }

    fun detectBeats() {
        val c = audioTarget()
        if (c == null || c.uri == null) { status = "Pehle music (A1) add karo ya clip select karo"; return }
        if (aiBusy) return
        aiBusy = true; status = "Beats dhoondh raha hai..."
        viewModelScope.launch {
            val env = withContext(Dispatchers.Default) { AudioAnalysis.envelope(ctx, c.uri, c.inMs, c.durationMs) }
            val res = env?.let { withContext(Dispatchers.Default) { AudioAnalysis.beats(it) } }
            aiBusy = false
            if (res == null) { status = "Clear beat nahi mila"; return@launch }
            markers.clear()
            markers.addAll(res.second.map { c.startMs + it })
            bpm = res.first
            status = "~${res.first} BPM, ${markers.size} beat markers"
        }
    }

    fun clearMarkers() { markers.clear(); bpm = 0 }

    /** Re-times V1 photos so every cut lands on a beat marker (every N-th beat). Videos keep their length. */
    fun beatSync(every: Int) {
        if (markers.isEmpty()) { status = "Pehle Detect Beats chalao"; return }
        val m = markers.filterIndexed { i, _ -> i % every == 0 }.sorted()
        val v1 = clips.filter { it.track == TRACK_V1 }.sortedBy { it.startMs }
        if (v1.none { it.type == ClipType.IMAGE }) { status = "V1 par photos nahi hain"; return }
        snapshot(true)
        var t = 0L
        for (c in v1) {
            val dur = if (c.type == ClipType.IMAGE) {
                val nb = m.firstOrNull { it >= t + 700 }
                if (nb != null) nb - t else c.durationMs
            } else c.durationMs
            val i = clips.indexOfFirst { it.id == c.id }
            clips[i] = c.copy(startMs = t, durationMs = dur, sourceMs = maxOf(c.sourceMs, dur))
            t += dur
        }
        sync()
        status = "Beat Sync done (har ${every} beat par cut)"
    }

    // ------------------------------------------------------------ AI: Magic Edit (auto-assemble from the media bin)
    fun magicEdit(style: MagicStyle) {
        val items = bin.filter { it.type == ClipType.VIDEO || it.type == ClipType.IMAGE }
        if (items.isEmpty()) { status = "Magic Edit ke liye pehle video/photo import karo"; return }
        snapshot(true)
        clips.clear(); markers.clear(); bpm = 0
        var t = 0L
        items.forEachIndexed { i, m ->
            val dur = if (m.type == ClipType.IMAGE) style.photoMs else minOf(m.durationMs, 6000L)
            val base = Clip(nextId++, m.type, m.name, m.uri, TRACK_V1, t, dur, sourceMs = m.durationMs)
            var c = withLook(base, style.look)
            c = c.copy(
                animIn = if (i == 0) c.animIn else style.transition.into,
                animOut = if (i == items.lastIndex) "None" else style.transition.out,
                animMs = style.transition.ms,
            )
            clips.add(c); t += dur
        }
        val tp = style.title
        clips.add(Clip(nextId++, ClipType.TEXT, tp.name, null, TRACK_TEXT, 200, 2500, text = tp.text, textColor = tp.color,
            textSize = tp.size, posX = tp.posX, posY = tp.posY, animIn = tp.animIn, animOut = tp.animOut))
        val music = bin.firstOrNull { it.type == ClipType.AUDIO }
        if (music != null) {
            clips.add(Clip(nextId++, ClipType.AUDIO, music.name, music.uri, TRACK_A1, 0, minOf(music.durationMs, t),
                sourceMs = music.durationMs))
        }
        selectedId = null
        seek(0)
        status = "Magic Edit: ${style.name} timeline ban gayi (Undo se wapas)"
        if (music != null) {
            aiBusy = true
            viewModelScope.launch {
                val a = clips.first { it.track == TRACK_A1 }
                val env = withContext(Dispatchers.Default) { AudioAnalysis.envelope(ctx, music.uri, 0, a.durationMs) }
                val res = env?.let { withContext(Dispatchers.Default) { AudioAnalysis.beats(it) } }
                aiBusy = false
                if (res != null) {
                    markers.addAll(res.second); bpm = res.first
                    beatSync(if (style.photoMs < 2000) 1 else 2)
                    status = "Magic Edit + Beat Sync (~${res.first} BPM)"
                }
            }
        }
    }

    // ------------------------------------------------------------ effect stack
    var fxClipboard by mutableStateOf<List<FxItem>>(emptyList())

    private fun fxTarget(): Clip? = selected?.takeIf { it.track == TRACK_V1 }

    fun toggleFx(d: FxDef) {
        val c = fxTarget()
        if (c == null) { status = "V1 track ka video/photo clip select karo"; return }
        if (c.fx.any { it.name == d.name }) update(c.id) { cl -> cl.copy(fx = cl.fx.filter { it.name != d.name }) }
        else update(c.id) { cl -> cl.copy(fx = cl.fx + FxItem(d.name, d.amt, d.speed, d.angle, 1, -1)) }
    }

    fun updateFx(id: Long, idx: Int, f: (FxItem) -> FxItem) =
        update(id) { c -> c.copy(fx = c.fx.mapIndexed { i, x -> if (i == idx) f(x) else x }) }

    fun removeFx(id: Long, idx: Int) = update(id) { c -> c.copy(fx = c.fx.filterIndexed { i, _ -> i != idx }) }

    fun clearFx(id: Long) = update(id) { it.copy(fx = emptyList()) }

    fun copyFx() {
        val c = fxTarget()
        fxClipboard = c?.fx ?: emptyList()
        status = "Effects copy: ${fxClipboard.size}"
    }

    fun pasteFx(all: Boolean) {
        if (fxClipboard.isEmpty()) { status = "Pehle Copy karo"; return }
        val ids = if (all) clips.filter { it.track == TRACK_V1 }.map { it.id } else listOfNotNull(fxTarget()?.id)
        if (ids.isEmpty()) { status = "V1 clip select karo"; return }
        snapshot(true)
        for (i in clips.indices) if (clips[i].id in ids) clips[i] = clips[i].copy(fx = fxClipboard)
        sync()
        status = "Effects paste: ${ids.size} clip(s)"
    }

    fun addSticker(name: String) {
        snapshot(true)
        val d = 3000L
        val c = Clip(nextId++, ClipType.IMAGE, name, null, TRACK_V2, fitStart(TRACK_V2, playheadMs, d, -1), d,
            scale = 0.8f, sticker = name, animIn = "Pop", animOut = "Fade")
        clips.add(c)
        selectedId = c.id
    }

    // ------------------------------------------------------------ export
    fun export(outW: Int, outH: Int) {
        if (exportProgress >= 0f) return
        playing = false; sync()
        val comp: Composition? = try { Exporter.build(ctx, clips.toList(), outW, outH) } catch (e: Exception) {
            status = "Export setup error: ${e.message}"; null
        }
        if (comp == null) { if (status.startsWith("Export setup").not()) status = "V1 track par kuch nahi hai"; return }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.cacheDir
        val file = File(dir, "MotionStudio_${System.currentTimeMillis()}.mp4")
        val tf = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    exportProgress = -1f
                    viewModelScope.launch(Dispatchers.IO) {
                        val shown = saveToGallery(file)
                        withContext(Dispatchers.Main) { lastExport = shown; status = "Export done: $shown" }
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    exportProgress = -1f
                    status = "Export failed: ${exportException.errorCodeName}"
                }
            })
            .build()
        exportProgress = 0f
        status = "Exporting..."
        tf.start(comp, file.absolutePath)
        val handler = Handler(Looper.getMainLooper())
        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                if (exportProgress < 0f) return
                if (tf.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) exportProgress = holder.progress / 100f
                handler.postDelayed(this, 300)
            }
        }
        handler.postDelayed(poll, 300)
    }

    private fun saveToGallery(file: File): String {
        if (Build.VERSION.SDK_INT < 29) return file.absolutePath
        return try {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MotionStudio")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
            ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            "Movies/MotionStudio/${file.name}"
        } catch (e: Exception) { file.absolutePath }
    }

    override fun onCleared() {
        videoPlayer.release(); audioPlayer.release()
    }
}
