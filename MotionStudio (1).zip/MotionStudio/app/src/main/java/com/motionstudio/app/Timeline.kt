package com.motionstudio.app

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val ROW_H = 34.dp
private val RULER_H = 18.dp

private fun clipColor(t: ClipType) = when (t) {
    ClipType.VIDEO -> Color(0xFF3B6FD8)
    ClipType.IMAGE -> Color(0xFF2FA37A)
    ClipType.AUDIO -> Color(0xFFD08A2E)
    ClipType.TEXT -> Color(0xFFB04BD1)
}

@Composable
fun TimelinePanel(vm: EditorVM, accent: Color) {
    val dens = LocalDensity.current.density
    val scroll = rememberScrollState()
    var viewW by remember { mutableIntStateOf(0) }
    val ppms = vm.pxPerSec / 1000f // dp per ms
    val contentDp = ((vm.totalMs + 8000) * ppms).coerceAtLeast(500f)

    // keep playhead visible while playing (snapshotFlow: does not recompose the whole timeline every frame)
    LaunchedEffect(Unit) {
        snapshotFlow { vm.playheadMs }.collect { head ->
            if (vm.playing && viewW > 0) {
                val x = (head * vm.pxPerSec / 1000f * dens).toInt()
                if (x > scroll.value + viewW - 60 || x < scroll.value) scroll.scrollTo((x - 60).coerceAtLeast(0))
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(32.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TopBtn("Split", false, accent) { vm.splitAtPlayhead() }
            TopBtn("Duplicate", false, accent) { vm.duplicateSelected() }
            TopBtn("Delete", false, accent) { vm.deleteSelected() }
            Box(Modifier.weight(1f))
            TopBtn("Zoom −", false, accent) { vm.pxPerSec = (vm.pxPerSec / 1.3f).coerceAtLeast(20f) }
            TopBtn("Zoom +", false, accent) { vm.pxPerSec = (vm.pxPerSec * 1.3f).coerceAtMost(400f) }
        }
        Row(Modifier.weight(1f).fillMaxWidth()) {
            Column(Modifier.width(34.dp)) {
                Box(Modifier.height(RULER_H))
                TRACKS.forEach { t ->
                    Box(Modifier.height(ROW_H).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(t.name, color = MUTED, fontSize = 10.sp)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight().onSizeChanged { viewW = it.width }.horizontalScroll(scroll)) {
                Box(Modifier.width(contentDp.dp).fillMaxHeight()) {
                    Ruler(vm, ppms, dens, accent)
                    TRACKS.forEachIndexed { i, _ ->
                        Box(
                            Modifier.offset(y = RULER_H + ROW_H * i).fillMaxWidth().height(ROW_H - 1.dp)
                                .background(if (i % 2 == 0) Color(0xFF181B21) else Color(0xFF14161B))
                        )
                    }
                    vm.markers.forEach { m ->
                        Box(Modifier.offset(x = (m * ppms).dp).width(1.dp).fillMaxHeight().background(Color(0x77FFD400)))
                    }
                    vm.clips.toList().forEach { c -> ClipBox(vm, c, ppms, dens, accent) }
                    // playhead (position read in the layout phase only)
                    Box(
                        Modifier.offset { IntOffset((vm.playheadMs * ppms * dens).toInt(), 0) }
                            .width(2.dp).fillMaxHeight().background(Color(0xFFFF4D4D))
                    )
                }
            }
        }
    }
}

@Composable
private fun Ruler(vm: EditorVM, ppms: Float, dens: Float, accent: Color) {
    val stepSec = when {
        vm.pxPerSec < 35 -> 10
        vm.pxPerSec < 70 -> 5
        vm.pxPerSec < 160 -> 2
        else -> 1
    }
    Box(
        Modifier.fillMaxWidth().height(RULER_H).background(PANEL2)
            .pointerInput(ppms) { detectTapGestures { o -> vm.seek((o.x / dens / ppms).toLong()) } }
            .pointerInput(ppms) { detectDragGestures { ch, _ -> ch.consume(); vm.seek((ch.position.x / dens / ppms).toLong()) } }
    ) {
        val maxSec = (vm.totalMs / 1000 + 10).toInt()
        for (s in 0..maxSec step stepSec) {
            Text("%d:%02d".format(s / 60, s % 60), color = MUTED, fontSize = 8.sp,
                modifier = Modifier.offset(x = (s * 1000 * ppms).dp + 2.dp, y = 3.dp))
            Box(Modifier.offset(x = (s * 1000 * ppms).dp).width(1.dp).height(6.dp).background(LINE))
        }
    }
}

@Composable
private fun ClipBox(vm: EditorVM, c: Clip, ppms: Float, dens: Float, accent: Color) {
    val sel = vm.selectedId == c.id
    val id = c.id
    Box(
        Modifier
            .offset(x = (c.startMs * ppms).dp, y = RULER_H + ROW_H * c.track + 1.dp)
            .width((c.durationMs * ppms).dp.coerceAtLeast(10.dp))
            .height(ROW_H - 3.dp)
            .background(clipColor(c.type), RoundedCornerShape(5.dp))
            .border(if (sel) 2.dp else 0.dp, if (sel) Color.White else Color.Transparent, RoundedCornerShape(5.dp))
            .clickable { vm.selectedId = id }
            .pointerInput(id, ppms) {
                var s0 = 0L; var t0 = 0; var tot = Offset.Zero
                detectDragGestures(
                    onDragStart = {
                        vm.selectedId = id
                        vm.snapshot(true)
                        val cur = vm.clips.firstOrNull { it.id == id }
                        s0 = cur?.startMs ?: 0L; t0 = cur?.track ?: 0; tot = Offset.Zero
                    },
                ) { ch, drag ->
                    ch.consume()
                    tot += drag
                    val ns = s0 + (tot.x / dens / ppms).toLong()
                    val nt = (t0 + (tot.y / dens / ROW_H.value).roundToInt()).coerceIn(0, TRACKS.lastIndex)
                    vm.moveClip(id, ns, nt)
                }
            }
    ) {
        Text(
            if (c.type == ClipType.TEXT) c.text else c.name, color = Color.White, fontSize = 9.sp, maxLines = 1,
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp, end = 12.dp),
        )
        if (sel) {
            Handle(vm, c, left = true, ppms, dens, Modifier.align(Alignment.CenterStart))
            Handle(vm, c, left = false, ppms, dens, Modifier.align(Alignment.CenterEnd))
        }
    }
}

@Composable
private fun Handle(vm: EditorVM, c: Clip, left: Boolean, ppms: Float, dens: Float, modifier: Modifier) {
    val id = c.id
    Box(
        modifier.width(10.dp).fillMaxHeight().background(Color(0x99FFFFFF), RoundedCornerShape(4.dp))
            .pointerInput(id, left, ppms) {
                var s0 = 0L; var d0 = 0L; var i0 = 0L; var tot = 0f
                detectDragGestures(
                    onDragStart = {
                        vm.snapshot(true)
                        val cur = vm.clips.firstOrNull { it.id == id }
                        s0 = cur?.startMs ?: 0L; d0 = cur?.durationMs ?: 0L; i0 = cur?.inMs ?: 0L; tot = 0f
                    },
                ) { ch, drag ->
                    ch.consume()
                    tot += drag.x
                    val cur = vm.clips.firstOrNull { it.id == id } ?: return@detectDragGestures
                    val media = cur.type == ClipType.VIDEO || cur.type == ClipType.AUDIO
                    var dx = (tot / dens / ppms).toLong()
                    if (left) {
                        dx = dx.coerceAtLeast(-minOf(s0, if (media) (i0 / cur.speed).toLong() else Long.MAX_VALUE)).coerceAtMost(d0 - 200)
                        vm.trimClip(id, s0 + dx, d0 - dx, if (media) i0 + (dx * cur.speed).toLong() else i0)
                    } else {
                        var nd = (d0 + dx).coerceAtLeast(200)
                        if (media) nd = nd.coerceAtMost(((cur.sourceMs - cur.inMs) / cur.speed).toLong())
                        vm.trimClip(id, s0, nd, cur.inMs)
                    }
                }
            }
    )
}
