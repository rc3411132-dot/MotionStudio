@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.motionstudio.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------------------ LEFT: media / filters / animations / text / AI

@Composable
fun LeftPanel(vm: EditorVM, accent: Color, onImport: () -> Unit) {
    var tab by remember { mutableIntStateOf(vm.prefs.workspace.coerceIn(0, LEFT_TABS.lastIndex)) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(4.dp)) {
            LEFT_TABS.forEachIndexed { i, t -> Chip(t, tab == i, accent) { tab = i; vm.prefs.workspace = i } }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(8.dp)) {
            when (tab) {
                0 -> MediaTab(vm, accent, onImport)
                1 -> FiltersTab(vm, accent)
                2 -> EffectsTab(vm, accent)
                3 -> AnimTab(vm, accent)
                4 -> PresetsTab(vm, accent)
                5 -> TextTab(vm, accent)
                6 -> StickersTab(vm, accent)
                else -> AiTab(vm, accent)
            }
        }
    }
}

@Composable
private fun NeedsClip(vm: EditorVM, msg: String, content: @Composable (Clip) -> Unit) {
    val c = vm.selected
    if (c == null || c.type == ClipType.AUDIO || c.type == ClipType.TEXT) {
        Text(msg, color = MUTED, fontSize = 11.sp)
    } else content(c)
}

@Composable
private fun MediaTab(vm: EditorVM, accent: Color, onImport: () -> Unit) {
    Chip("+ Import video / photo / audio", true, accent, Modifier.fillMaxWidth()) { onImport() }
    if (vm.bin.isEmpty()) Text("Pehle media import karo.", color = MUTED, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    vm.bin.forEach { m ->
        Column(Modifier.fillMaxWidth().padding(top = 6.dp).background(PANEL2, RoundedCornerShape(8.dp)).padding(8.dp)) {
            Text(m.name, color = TXT, fontSize = 11.sp, maxLines = 1)
            Text("${m.type.name.lowercase()} · ${fmtTime(m.durationMs)}", color = MUTED, fontSize = 9.sp)
            Row(Modifier.padding(top = 4.dp)) {
                Chip("+ Timeline", false, accent) { vm.addToTimeline(m) }
                if (m.type == ClipType.IMAGE) Chip("+ Overlay", false, accent) { vm.addToTimeline(m, asOverlay = true) }
            }
        }
    }
}

@Composable
private fun FiltersTab(vm: EditorVM, accent: Color) {
    NeedsClip(vm, "Timeline par video ya photo select karo, phir filter chuno.") { c ->
        Text("Filters (${c.name})", color = MUTED, fontSize = 10.sp)
        FlowRow { FILTERS.keys.forEach { f -> Chip(f, c.filter == f, accent) { vm.update(c.id) { it.copy(filter = f) } } } }
        LabeledSlider("Filter strength", c.filterStrength, 0f..1f, accent) { v -> vm.update(c.id) { it.copy(filterStrength = v) } }
    }
}

@Composable
private fun AnimTab(vm: EditorVM, accent: Color) {
    var mode by remember { mutableStateOf("in") }
    val c = vm.selected
    if (c == null || c.type == ClipType.AUDIO) { Text("Clip select karo.", color = MUTED, fontSize = 11.sp); return }
    val list = if (c.track == TRACK_V1 && c.type == ClipType.VIDEO) VIDEO_ANIMATIONS else ANIMATIONS
    Row {
        Chip("Intro", mode == "in", accent) { mode = "in" }
        Chip("Outro", mode == "out", accent) { mode = "out" }
    }
    FlowRow {
        list.forEach { a ->
            val on = if (mode == "in") c.animIn == a else c.animOut == a
            Chip(a, on, accent) { vm.update(c.id) { if (mode == "in") it.copy(animIn = a) else it.copy(animOut = a) } }
        }
    }
    LabeledSlider("Animation length", c.animMs.toFloat(), 200f..2000f, accent, { "${it.toInt()} ms" }) { v ->
        vm.update(c.id) { it.copy(animMs = v.toLong()) }
    }
    SectionTitle("Easing")
    FlowRow { EASINGS.forEach { e -> Chip(e, c.easing == e, accent) { vm.update(c.id) { it.copy(easing = e) } } } }
    SectionTitle("Transitions (V1 clip ke end par)")
    FlowRow { TRANSITIONS.forEach { tr -> Chip(tr.name, false, accent) { vm.applyTransition(tr) } } }
}

@Composable
private fun EffectsTab(vm: EditorVM, accent: Color) {
    var cat by remember { mutableStateOf(FX_CATEGORIES[0]) }
    val c = vm.selected
    val ok = c != null && c.track == TRACK_V1
    if (!ok) Text("V1 track ka video/photo clip select karo, phir effect chuno.", color = MUTED, fontSize = 11.sp)
    FlowRow { FX_CATEGORIES.forEach { k -> Chip(k, cat == k, accent) { cat = k } } }
    Text("${FX_LIST.count { it.cat == cat }} effects - tap = on/off, stack me kai effects ek saath chalte hain.",
        color = MUTED, fontSize = 9.sp, modifier = Modifier.padding(vertical = 4.dp))
    FlowRow {
        FX_LIST.filter { it.cat == cat }.forEach { d ->
            Chip(d.name, c?.fx?.any { it.name == d.name } == true, accent) { vm.toggleFx(d) }
        }
    }
    if (c != null && ok) {
        SectionTitle("Is clip ke effects (${c.fx.size})")
        c.fx.forEachIndexed { i, item -> FxRow(vm, c.id, i, item, accent) }
        FlowRow(Modifier.padding(top = 6.dp)) {
            Chip("Copy", false, accent) { vm.copyFx() }
            Chip("Paste", false, accent) { vm.pasteFx(false) }
            Chip("Paste sab V1", false, accent) { vm.pasteFx(true) }
            Chip("Clear", false, accent) { vm.clearFx(c.id) }
        }
        Text("Photo clips par GPU effects export me dikhte hain; preview me sirf particles/bars/colour dikhte hain.",
            color = MUTED, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp))
        Text("Flash / strobe / glitch halke rakhe hain (photosensitive viewers ke liye).", color = MUTED, fontSize = 9.sp)
    }
}

@Composable
private fun FxRow(vm: EditorVM, id: Long, idx: Int, item: FxItem, accent: Color) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp).background(PANEL2, RoundedCornerShape(8.dp)).padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(item.name, color = TXT, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f))
            Chip("X", false, accent) { vm.removeFx(id, idx) }
        }
        LabeledSlider("Intensity", item.amount, 0f..1f, accent) { v -> vm.updateFx(id, idx) { it.copy(amount = v) } }
        LabeledSlider("Speed", item.speed, 0.2f..3f, accent) { v -> vm.updateFx(id, idx) { it.copy(speed = v) } }
        LabeledSlider("Angle", item.angle, -3.14f..3.14f, accent, { "${(it * 57.3f).toInt()}°" }) { v -> vm.updateFx(id, idx) { it.copy(angle = v) } }
        LabeledSlider("Seed", item.seed.toFloat(), 1f..50f, accent, { "${it.toInt()}" }) { v -> vm.updateFx(id, idx) { it.copy(seed = v.toInt()) } }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip("Auto", item.color < 0, accent) { vm.updateFx(id, idx) { it.copy(color = -1) } }
            TINTS.forEachIndexed { i, col ->
                Box(Modifier.padding(end = 4.dp).size(18.dp).clip(CircleShape).background(Color(0xFF000000 or col.toLong()))
                    .border(if (item.color == i) 2.dp else 1.dp, if (item.color == i) Color.White else LINE, CircleShape)
                    .clickable { vm.updateFx(id, idx) { it.copy(color = i) } })
            }
        }
    }
}

@Composable
private fun PresetsTab(vm: EditorVM, accent: Color) {
    Text("Look presets: filter + colour + live effect + intro/outro ek tap me.", color = MUTED, fontSize = 10.sp)
    var all by remember { mutableStateOf(false) }
    Row {
        Chip("Selected clip", !all, accent) { all = false }
        Chip("Sab V1 clips", all, accent) { all = true }
    }
    FlowRow { LOOK_PRESETS.forEach { p -> Chip(p.name, false, accent) { vm.applyLook(p, all) } } }
}

@Composable
private fun TextTab(vm: EditorVM, accent: Color) {
    val sel = vm.selected?.type == ClipType.TEXT
    Text(
        if (sel) "Text select hai: preset tap karoge to uska style badlega." else "Preset tap karo: playhead par text add hoga (T1).",
        color = MUTED, fontSize = 10.sp,
    )
    FlowRow { TEXT_PRESETS.forEach { p -> Chip(p.name, false, accent) { vm.addTextPreset(p) } } }
    Text("Text ka content, size, colour, position right panel me edit karo.", color = MUTED, fontSize = 10.sp,
        modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun StickersTab(vm: EditorVM, accent: Color) {
    var cat by remember { mutableStateOf(STICKER_CATS[0]) }
    Text("Tap karo: sticker playhead par V2 track me add hoga. Position / size / rotation right panel se.",
        color = MUTED, fontSize = 10.sp)
    FlowRow { STICKER_CATS.forEach { k -> Chip(k, cat == k, accent) { cat = k } } }
    FlowRow(Modifier.padding(top = 4.dp)) {
        STICKERS.filter { it.cat == cat }.forEach { s ->
            Box(
                Modifier.padding(3.dp).size(56.dp).background(Color(0xFF2B2F3A), RoundedCornerShape(8.dp))
                    .border(1.dp, LINE, RoundedCornerShape(8.dp)).clickable { vm.addSticker(s.name) }.padding(5.dp)
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { Stickers.draw(it.nativeCanvas, size.width.toInt(), size.height.toInt(), s.name) }
                }
            }
        }
    }
    Text("${STICKERS.count { it.cat == cat }} stickers - ${STICKERS.size} total. Apne PNG ke liye Media tab me photo import karke '+ Overlay' dabao.",
        color = MUTED, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun AiTab(vm: EditorVM, accent: Color) {
    val full = Modifier.fillMaxWidth()
    if (vm.aiBusy) Text("AI kaam kar raha hai...", color = accent, fontSize = 11.sp)
    SectionTitle("Video")
    Chip("Auto Enhance (selected)", false, accent, full) { vm.selectedId?.let { vm.autoEnhance(it) } ?: run { vm.status = "Pehle clip select karo" } }
    Chip("Enhance All (V1)", false, accent, full) { vm.enhanceAll() }
    Chip("Smart Look (best filter chuno)", false, accent, full) { vm.selectedId?.let { vm.smartLook(it) } ?: run { vm.status = "Pehle clip select karo" } }
    SectionTitle("Audio")
    Chip("Cut Silence (jump-cut)", false, accent, full) { vm.cutSilence() }
    Chip("Detect Beats${if (vm.bpm > 0) " (~${vm.bpm} BPM)" else ""}", false, accent, full) { vm.detectBeats() }
    Row {
        Text("Beat Sync:", color = MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp, end = 4.dp))
        listOf(1, 2, 4).forEach { n -> Chip("${n}", false, accent) { vm.beatSync(n) } }
        Chip("Clear", false, accent) { vm.clearMarkers() }
    }
    SectionTitle("Magic Edit (media bin se auto timeline)")
    FlowRow { MAGIC_STYLES.forEach { s -> Chip(s.name, false, accent) { vm.magicEdit(s) } } }
    Text(
        "Sab AI features phone ke andar chalte hain, internet nahi chahiye. Silence/beat/filter detection " +
            "andaaze se hota hai, isliye result ek baar check kar lo (Undo hai). Captions aur background remove abhi nahi.",
        color = MUTED, fontSize = 9.sp, modifier = Modifier.padding(top = 8.dp),
    )
}

// ------------------------------------------------------------------------ RIGHT: properties of the selected clip

@Composable
fun ControlsPanel(vm: EditorVM, accent: Color) {
    val c = vm.selected
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(8.dp)) {
        Text("PROPERTIES", color = MUTED, fontSize = 9.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        if (c == null) {
            Text("Timeline par clip select karo.", color = MUTED, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            return@Column
        }
        Text(c.name, color = TXT, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
        val visual = c.type == ClipType.VIDEO || c.type == ClipType.IMAGE
        val up = { f: (Clip) -> Clip -> vm.update(c.id, f) }

        if (c.type == ClipType.TEXT) {
            SectionTitle("Text")
            BasicTextField(
                value = c.text, onValueChange = { v -> up { it.copy(text = v) } },
                textStyle = TextStyle(color = TXT, fontSize = 13.sp), cursorBrush = SolidColor(accent),
                modifier = Modifier.fillMaxWidth().background(PANEL2, RoundedCornerShape(6.dp)).padding(8.dp),
            )
            LabeledSlider("Size", c.textSize, 20f..200f, accent, { "${it.toInt()}" }) { v -> up { it.copy(textSize = v) } }
            Text("Text style", color = MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            Row { TEXT_STYLES.forEach { st -> Chip(st, c.textStyle == st, accent) { up { it.copy(textStyle = st) } } } }
            Text("Text animation", color = MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            Row { TEXT_ANIMS.forEach { a -> Chip(a, c.textAnim == a, accent) { up { it.copy(textAnim = a) } } } }
            Row(Modifier.padding(top = 4.dp)) {
                TEXT_COLORS.forEach { col ->
                    Box(Modifier.padding(end = 5.dp).size(22.dp).clip(CircleShape).background(Color(col))
                        .border(if (c.textColor == col) 2.dp else 1.dp, if (c.textColor == col) accent else LINE, CircleShape)
                        .clickable { up { it.copy(textColor = col) } })
                }
            }
        }
        if (c.track != TRACK_V1) {
            SectionTitle("Position")
            LabeledSlider("X", c.posX, -1f..1f, accent) { v -> up { it.copy(posX = v) } }
            LabeledSlider("Y", c.posY, -1f..1f, accent) { v -> up { it.copy(posY = v) } }
        }
        if (c.type != ClipType.AUDIO) {
            SectionTitle("Transform")
            LabeledSlider("Scale", c.scale, 0.2f..3f, accent) { v -> up { it.copy(scale = v) } }
            LabeledSlider("Rotation", c.rotation, -180f..180f, accent, { "${it.toInt()}°" }) { v -> up { it.copy(rotation = v) } }
            if (c.track != TRACK_V1) LabeledSlider("Opacity", c.opacity, 0f..1f, accent) { v -> up { it.copy(opacity = v) } }
        }
        if (visual) {
            SectionTitle("Color")
            LabeledSlider("Brightness", c.adjust.brightness, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(brightness = v)) } }
            LabeledSlider("Contrast", c.adjust.contrast, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(contrast = v)) } }
            LabeledSlider("Saturation", c.adjust.saturation, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(saturation = v)) } }
            LabeledSlider("Warmth", c.adjust.warmth, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(warmth = v)) } }
            Text("Colour sliders sirf V1 track par export/preview me apply hote hain.", color = MUTED, fontSize = 9.sp)
            SectionTitle("Pro color")
            LabeledSlider("Exposure", c.adjust.exposure, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(exposure = v)) } }
            LabeledSlider("Temperature", c.adjust.temperature, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(temperature = v)) } }
            LabeledSlider("Tint", c.adjust.tint, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(tint = v)) } }
            LabeledSlider("Highlights", c.adjust.highlights, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(highlights = v)) } }
            LabeledSlider("Shadows", c.adjust.shadows, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(shadows = v)) } }
            LabeledSlider("Vibrance", c.adjust.vibrance, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(vibrance = v)) } }
            LabeledSlider("Hue shift", c.adjust.hue, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(hue = v)) } }
            LabeledSlider("Fade", c.adjust.fade, -1f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(fade = v)) } }
            LabeledSlider("Sharpen", c.adjust.sharpen, 0f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(sharpen = v)) } }
            LabeledSlider("Vignette", c.adjust.vignette, 0f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(vignette = v)) } }
            LabeledSlider("Film grain", c.adjust.grain, 0f..1f, accent) { v -> up { it.copy(adjust = it.adjust.copy(grain = v)) } }
        }
        if (c.type != ClipType.AUDIO) KeyframeSection(vm, c, accent)
        if (c.type == ClipType.VIDEO || c.type == ClipType.AUDIO) {
            SectionTitle("Audio")
            LabeledSlider("Volume", c.volume, 0f..1f, accent) { v -> up { it.copy(volume = v) } }
            SectionTitle("Speed  (${c.speed}x)")
            FlowRow { listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f).forEach { s -> Chip("${s}x", c.speed == s, accent) { vm.setSpeed(c.id, s) } } }
        }
    }
}


/** Keyframes: move the playhead, drag a slider -> a key is stored at that time; values are eased between keys. */
@Composable
private fun KeyframeSection(vm: EditorVM, c: Clip, accent: Color) {
    val t = (vm.playheadMs - c.startMs).coerceIn(0L, c.durationMs)
    val live = liveClip(c, t)
    val isV1 = c.track == TRACK_V1
    SectionTitle("Keyframes  (playhead ${fmtTime(t)})")
    Text("Playhead ko hilao, phir slider khiicho: us time par key ban jaati hai.", color = MUTED, fontSize = 9.sp)
    val props = KF_PROPS.filter { p -> !(isV1 && (p == "opacity" || p == "rotation")) }
    for (p in props) {
        val (range, label) = when (p) {
            "scale" -> 0.1f..3f to "Scale"
            "rotation" -> -180f..180f to "Rotation"
            "posX" -> -1f..1f to "Position X"
            "posY" -> -1f..1f to "Position Y"
            else -> 0f..1f to "Opacity"
        }
        val v = when (p) { "scale" -> live.scale; "rotation" -> live.rotation; "posX" -> live.posX; "posY" -> live.posY; else -> live.opacity }
        val has = c.keys.any { it.prop == p }
        LabeledSlider((if (has) "\u25C6 " else "\u25C7 ") + label, v, range, accent) { nv -> vm.setKey(c.id, p, nv) }
    }
    if (c.keys.isNotEmpty()) {
        FlowRow {
            c.keys.forEach { k -> Chip("${k.prop} ${fmtTime(k.tMs)} \u2715", false, accent) { vm.removeKey(c.id, k) } }
            Chip("Clear all keys", false, accent) { vm.clearKeys(c.id) }
        }
    }
}
