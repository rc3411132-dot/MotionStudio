@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

private const val VERT = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

/**
 * One GPU pass. group = shader file (blur, glitch, warp, style, light, grade), mode = effect inside that file.
 * Shaders live in assets/shaders/ and were compile-tested (GLSL ES 1.00).
 */
class FxShaderEffect(
    val group: String,
    val mode: Float,
    val amt: Float,
    val speed: Float = 1f,
    val angle: Float = 0f,
    val seed: Float = 1f,
    val tint: FloatArray = floatArrayOf(1f, 1f, 1f),
    val tint2: FloatArray = floatArrayOf(0.1f, 0f, 0.4f),
    val g1: FloatArray = floatArrayOf(0f, 0f, 0f, 0f),
    val g2: FloatArray = floatArrayOf(0f, 0f, 0f, 0f),
    val timeBaseMs: Long = 0L,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        FxProgram(context, this, useHdr)
}

private class FxProgram(ctx: Context, private val e: FxShaderEffect, useHdr: Boolean) : BaseGlShaderProgram(useHdr, 1) {
    private val gl: GlProgram = try {
        val header = ctx.assets.open("shaders/fx_header.glsl").bufferedReader().use { it.readText() }
        val body = ctx.assets.open("shaders/fx_${e.group}.glsl").bufferedReader().use { it.readText() }
        GlProgram(VERT, header + "\n" + body).also {
            it.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE)
        }
    } catch (ex: Exception) {
        throw VideoFrameProcessingException(ex)
    }
    private var w = 1f
    private var h = 1f

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        w = inputWidth.toFloat(); h = inputHeight.toFloat()
        return Size(inputWidth, inputHeight)
    }

    private inline fun safe(block: () -> Unit) { try { block() } catch (_: Exception) { } } // uniform optimised out in this group

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            gl.use()
            gl.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            val t = ((presentationTimeUs / 1000L - e.timeBaseMs).coerceAtLeast(0)) / 1000f * e.speed
            safe { gl.setFloatUniform("uMode", e.mode) }
            safe { gl.setFloatUniform("uAmt", e.amt) }
            safe { gl.setFloatUniform("uTime", t) }
            safe { gl.setFloatUniform("uAngle", e.angle) }
            safe { gl.setFloatUniform("uSeed", e.seed) }
            safe { gl.setFloatsUniform("uRes", floatArrayOf(w, h)) }
            safe { gl.setFloatsUniform("uTint", e.tint) }
            safe { gl.setFloatsUniform("uTint2", e.tint2) }
            safe { gl.setFloatsUniform("uG1", e.g1) }
            safe { gl.setFloatsUniform("uG2", e.g2) }
            gl.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (ex: Exception) {
            throw VideoFrameProcessingException(ex, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { gl.delete() } catch (_: Exception) { }
    }
}
