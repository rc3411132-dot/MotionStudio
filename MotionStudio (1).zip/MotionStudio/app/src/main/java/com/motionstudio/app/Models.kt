@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.net.Uri

enum class ClipType { VIDEO, IMAGE, AUDIO, TEXT }

/** Timeline rows, top to bottom. Index = Clip.track */
data class TrackDef(val name: String, val accepts: Set<ClipType>)

val TRACKS = listOf(
    TrackDef("T1", setOf(ClipType.TEXT)),
    TrackDef("V2", setOf(ClipType.IMAGE)),
    TrackDef("V1", setOf(ClipType.VIDEO, ClipType.IMAGE)),
    TrackDef("A1", setOf(ClipType.AUDIO)),
)
const val TRACK_TEXT = 0
const val TRACK_V2 = 1
const val TRACK_V1 = 2
const val TRACK_A1 = 3

data class Adjust(
    val brightness: Float = 0f, // -1..1
    val contrast: Float = 0f,   // -1..1
    val saturation: Float = 0f, // -1..1
    val warmth: Float = 0f,     // -1..1
    // pro colour (all -1..1, vignette/grain/sharpen 0..1)
    val exposure: Float = 0f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val vibrance: Float = 0f,
    val hue: Float = 0f,
    val fade: Float = 0f,
    val sharpen: Float = 0f,
    val vignette: Float = 0f,
    val grain: Float = 0f,
) {
    val hasGrade get() = exposure != 0f || temperature != 0f || tint != 0f || highlights != 0f ||
        shadows != 0f || vibrance != 0f || hue != 0f || fade != 0f
}

/** One effect in a clip's stack. name = key in FX_BY_NAME. */
data class FxItem(
    val name: String,
    val amount: Float = 0.6f,   // intensity 0..1
    val speed: Float = 1f,      // 0.2..3
    val angle: Float = 0f,      // radians, direction
    val seed: Int = 1,          // random seed
    val color: Int = -1,        // index in TINTS, -1 = effect default
)

/** One keyframe: value of a property (scale, rotation, posX, posY, opacity) tMs after the clip started. */
data class Keyframe(val tMs: Long, val prop: String, val value: Float)

data class Clip(
    val id: Long,
    val type: ClipType,
    val name: String,
    val uri: Uri? = null,
    val track: Int,
    val startMs: Long,
    val durationMs: Long,
    val inMs: Long = 0,
    val sourceMs: Long = durationMs,
    val filter: String = "None",
    val filterStrength: Float = 1f,
    val liveFx: String = "None",
    val fx: List<FxItem> = emptyList(),
    val easing: String = "Ease Out",
    val textStyle: String = "Plain",   // Plain, Outline, Neon, Gold
    val textAnim: String = "None",   // text reveal animation (Typewriter, Word by Word)
    val sticker: String = "",      // built-in sticker key (V2 image clip without a file)
    val adjust: Adjust = Adjust(),
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val posX: Float = 0f,   // -1..1 of preview width (text / V2 overlay)
    val posY: Float = 0f,   // -1..1 of preview height
    val opacity: Float = 1f,
    val animIn: String = "None",
    val animOut: String = "None",
    val animMs: Long = 600,
    val volume: Float = 1f,
    val keys: List<Keyframe> = emptyList(),
    val speed: Float = 1f,   // playback speed of video/audio (0.25..4); durationMs is the length on the timeline
    val text: String = "Your text",
    val textColor: Long = 0xFFFFFFFF,
    val textSize: Float = 56f,
) {
    val endMs get() = startMs + durationMs
    /** How much of the source file this clip uses (timeline length x speed). */
    val srcSpanMs: Long get() = (durationMs * speed).toLong()
}

