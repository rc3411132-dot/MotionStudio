package com.motionstudio.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max

/** Everything the user can customise. Persisted in SharedPreferences. */
class UiPrefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
    var accentIdx by mutableIntStateOf(sp.getInt("accent", 0))
    var leftW by mutableFloatStateOf(sp.getFloat("leftW", 230f))
    var rightW by mutableFloatStateOf(sp.getFloat("rightW", 250f))
    var timelineH by mutableFloatStateOf(sp.getFloat("timelineH", 190f))
    var showLeft by mutableStateOf(sp.getBoolean("showLeft", true))
    var showRight by mutableStateOf(sp.getBoolean("showRight", true))
    var mouseOn by mutableStateOf(sp.getBoolean("mouseOn", true))
    var sens by mutableFloatStateOf(sp.getFloat("sens", 1.8f))
    var padScale by mutableFloatStateOf(sp.getFloat("padScale", 1f))
    var padLeft by mutableStateOf(sp.getBoolean("padLeft", false))
    var cursorScale by mutableFloatStateOf(sp.getFloat("cursorScale", 1f))
    var workspace by mutableIntStateOf(sp.getInt("workspace", 0))

    fun save() = sp.edit()
        .putInt("accent", accentIdx).putFloat("leftW", leftW).putFloat("rightW", rightW)
        .putFloat("timelineH", timelineH).putBoolean("showLeft", showLeft).putBoolean("showRight", showRight)
        .putBoolean("mouseOn", mouseOn).putFloat("sens", sens).putFloat("padScale", padScale)
        .putBoolean("padLeft", padLeft).putFloat("cursorScale", cursorScale).putInt("workspace", workspace)
        .apply()
}

class MouseController {
    var cursor by mutableStateOf(Offset(-1f, -1f))
    var dragLocked by mutableStateOf(false)
    /** bounds of the button strip: touches there are NOT trackpad touches */
    var padRect by mutableStateOf<Rect?>(null)
}

/**
 * Virtual mouse. The whole screen is the trackpad: touches are swallowed here and turned into cursor moves;
 * clicks are injected into the activity's window at the cursor position, so every control in the app
 * (buttons, sliders, timeline clips, drag & drop) can be driven by the cursor.
 */
class MouseInput(
    private val mouse: MouseController,
    private val prefs: UiPrefs,
    private val decor: () -> View,
    private val dispatchTouch: (MotionEvent) -> Boolean,
) {
    private val h = Handler(Looper.getMainLooper())
    private var active = false
    private var lastX = 0f
    private var lastY = 0f
    private var total = 0f
    private var maxPtr = 1
    private var downT = 0L
    private var injDown = 0L

    /** true = event consumed by the trackpad */
    fun intercept(ev: MotionEvent): Boolean {
        if (!prefs.mouseOn) return false
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            // the whole screen is the trackpad, except the small button strip and the on-screen keyboard
            val r = mouse.padRect
            active = !(r != null && r.contains(Offset(ev.x, ev.y))) && !onKeyboard(ev.y)
            if (active) {
                total = 0f; maxPtr = 1; downT = ev.eventTime
                avg(ev, -1)
            }
        }
        if (!active) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> { maxPtr = max(maxPtr, ev.pointerCount); avg(ev, -1) }
            MotionEvent.ACTION_POINTER_UP -> avg(ev, ev.actionIndex)
            MotionEvent.ACTION_MOVE -> {
                val ox = lastX; val oy = lastY
                avg(ev, -1)
                val dx = lastX - ox; val dy = lastY - oy
                total += abs(dx) + abs(dy)
                if (ev.pointerCount >= 2) scroll(dx, dy) else moveCursor(dx, dy)
            }
            MotionEvent.ACTION_UP -> {
                if (total < 14f && ev.eventTime - downT < 260) { if (maxPtr >= 2) rightClick() else leftClick() }
                active = false
            }
            MotionEvent.ACTION_CANCEL -> active = false
        }
        return true
    }

    private fun onKeyboard(y: Float): Boolean {
        val d = decor()
        val ins = androidx.core.view.ViewCompat.getRootWindowInsets(d) ?: return false
        val ime = androidx.core.view.WindowInsetsCompat.Type.ime()
        if (!ins.isVisible(ime)) return false
        return y > d.height - ins.getInsets(ime).bottom
    }

    private fun avg(ev: MotionEvent, skip: Int) {
        var sx = 0f; var sy = 0f; var n = 0
        for (i in 0 until ev.pointerCount) if (i != skip) { sx += ev.getX(i); sy += ev.getY(i); n++ }
        if (n > 0) { lastX = sx / n; lastY = sy / n }
    }

    private fun moveCursor(dx: Float, dy: Float) {
        val d = decor()
        val c = mouse.cursor
        val nx = (c.x + dx * prefs.sens).coerceIn(0f, d.width.toFloat() - 1)
        val ny = (c.y + dy * prefs.sens).coerceIn(0f, d.height.toFloat() - 1)
        mouse.cursor = Offset(nx, ny)
        if (mouse.dragLocked) inject(MotionEvent.ACTION_MOVE, nx, ny)
    }

    private fun inject(action: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) injDown = now
        val e = MotionEvent.obtain(injDown, now, action, x, y, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        dispatchTouch(e)
        e.recycle()
    }

    private fun scroll(dx: Float, dy: Float) {
        val c = mouse.cursor
        val props = arrayOf(MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            x = c.x; y = c.y
            setAxisValue(MotionEvent.AXIS_VSCROLL, dy / 18f)
            setAxisValue(MotionEvent.AXIS_HSCROLL, -dx / 18f)
        })
        val now = SystemClock.uptimeMillis()
        val e = MotionEvent.obtain(now, now, MotionEvent.ACTION_SCROLL, 1, props, coords, 0, 0, 1f, 1f, 0, 0,
            InputDevice.SOURCE_MOUSE, 0)
        decor().dispatchGenericMotionEvent(e)
        e.recycle()
    }

    fun leftClick() {
        val c = mouse.cursor
        if (mouse.dragLocked) return
        inject(MotionEvent.ACTION_DOWN, c.x, c.y)
        h.postDelayed({ inject(MotionEvent.ACTION_UP, c.x, c.y) }, 35)
    }

    /** Right click = long press at the cursor (opens context menus). */
    fun rightClick() {
        val c = mouse.cursor
        if (mouse.dragLocked) return
        inject(MotionEvent.ACTION_DOWN, c.x, c.y)
        h.postDelayed({ inject(MotionEvent.ACTION_UP, c.x, c.y) }, 650)
    }

    fun toggleDrag() {
        val c = mouse.cursor
        if (!mouse.dragLocked) {
            mouse.dragLocked = true
            h.post { inject(MotionEvent.ACTION_DOWN, c.x, c.y) }
        } else {
            mouse.dragLocked = false
            h.post { inject(MotionEvent.ACTION_UP, mouse.cursor.x, mouse.cursor.y) }
        }
    }
}

// ---------------------------------------------------------------------------------- composables

@Composable
fun MouseOverlay(mouse: MouseController, prefs: UiPrefs, input: MouseInput, accent: Color) {
    if (!prefs.mouseOn) return
    val dens = LocalDensity.current.density
    Box(Modifier.fillMaxSize().onSizeChanged {
        if (mouse.cursor.x < 0f) mouse.cursor = Offset(it.width / 2f, it.height / 2f)
    }) {
        // small button strip (the screen itself is the trackpad)
        Column(
            Modifier
                .align(if (prefs.padLeft) Alignment.BottomStart else Alignment.BottomEnd)
                .padding(10.dp)
        ) {
            Row(Modifier.alpha(0.85f).onGloballyPositioned { mouse.padRect = it.boundsInWindow() }) {
                PadBtn("LEFT", false, accent) { input.leftClick() }
                PadBtn("RIGHT", false, accent) { input.rightClick() }
                PadBtn(if (mouse.dragLocked) "DRAG ●" else "DRAG", mouse.dragLocked, accent) { input.toggleDrag() }
                PadBtn("HIDE", false, accent) { prefs.mouseOn = false; prefs.save() }
            }
        }
        // cursor
        val size = 1.5f * prefs.cursorScale * dens
        Canvas(Modifier.fillMaxSize()) {
            val c = mouse.cursor
            if (c.x >= 0f) {
                val path = Path().apply {
                    moveTo(0f, 0f); lineTo(0f, 17f * size); lineTo(4.4f * size, 13.4f * size)
                    lineTo(7.4f * size, 20.5f * size); lineTo(10.2f * size, 19.2f * size)
                    lineTo(7.2f * size, 12.4f * size); lineTo(12.6f * size, 12.4f * size); close()
                }
                translate(c.x, c.y) {
                    drawPath(path, Color.White)
                    drawPath(path, Color.Black, style = Stroke(width = 1.6f * dens))
                }
                if (mouse.dragLocked) drawCircle(accent, 14f * dens, c, style = Stroke(2.5f * dens))
            }
        }
    }
}

@Composable
private fun PadBtn(label: String, on: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(end = 4.dp)
            .background(if (on) accent else Color(0xFF262932), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp),
    ) { Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
}
