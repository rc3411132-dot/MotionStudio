package com.motionstudio.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** On-device audio analysis (no network, no models): loudness envelope -> silence ranges and beats. */
object AudioAnalysis {
    const val WIN_MS = 25

    /** RMS (0..1) per WIN_MS window for [fromMs, fromMs + durMs) of the file's first audio track. Null if no audio. */
    fun envelope(ctx: Context, uri: Uri, fromMs: Long, durMs: Long): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            ex.seekTo(fromMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)

            val nWin = (durMs / WIN_MS).toInt().coerceAtLeast(1)
            val sum = DoubleArray(nWin)
            val cnt = IntArray(nWin)
            val info = MediaCodec.BufferInfo()
            val endUs = (fromMs + durMs) * 1000
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard++ < 2_000_000) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime > endUs) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                when {
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    }
                    oi >= 0 -> {
                        if (info.size > 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val frames = sb.remaining() / ch
                            val startMs = info.presentationTimeUs / 1000.0 - fromMs
                            var f = 0
                            while (f < frames) {
                                val w = ((startMs + f * 1000.0 / rate) / WIN_MS).toInt()
                                if (w in 0 until nWin) {
                                    val v = sb.get(f * ch) / 32768.0
                                    sum[w] += v * v
                                    cnt[w]++
                                }
                                f += 4
                            }
                        }
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0 || info.presentationTimeUs > endUs) outDone = true
                        codec.releaseOutputBuffer(oi, false)
                    }
                }
            }
            if (cnt.all { it == 0 }) return null
            return FloatArray(nWin) { if (cnt[it] == 0) 0f else sqrt(sum[it] / cnt[it]).toFloat() }
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    /** Silent stretches as (startMs, endMs) relative to the analysed range. Edges are padded so speech is not clipped. */
    fun silentRanges(env: FloatArray, minSilenceMs: Int = 500, padMs: Int = 120): List<Pair<Long, Long>> {
        val sorted = env.sortedArray()
        val p95 = sorted[(sorted.size * 0.95f).toInt().coerceIn(0, sorted.lastIndex)]
        if (p95 < 0.003f) return emptyList() // whole thing is silent / too quiet to judge
        val thr = max(0.006f, p95 * 0.12f)
        val out = ArrayList<Pair<Long, Long>>()
        var i = 0
        while (i < env.size) {
            if (env[i] < thr) {
                var j = i
                while (j < env.size && env[j] < thr) j++
                val s = i.toLong() * WIN_MS + padMs
                val e = j.toLong() * WIN_MS - padMs
                if (e - s >= minSilenceMs - 2 * padMs && e > s) out.add(s to e)
                i = j
            } else i++
        }
        return out
    }

    /** Approximate tempo (BPM) and beat times in ms relative to the analysed range. */
    fun beats(env: FloatArray): Pair<Int, List<Long>>? {
        if (env.size < 160) return null
        val n = env.size
        val flux = FloatArray(n)
        for (i in 1 until n) flux[i] = max(0f, env[i] - env[i - 1])
        val mean = flux.average().toFloat()
        if (mean < 1e-5f) return null
        var bestScore = -1f
        var bestP = 0f
        var bestPhase = 0
        val minP = 60000f / 180f / WIN_MS
        val maxP = 60000f / 70f / WIN_MS
        var p = minP
        while (p <= maxP) {
            val phases = p.toInt().coerceAtLeast(1)
            for (ph in 0 until phases) {
                var s = 0f
                var c = 0
                var pos = ph.toFloat()
                while (pos < n - 1) {
                    val k = pos.roundToInt()
                    s += max(flux[k], max(flux[(k - 1).coerceAtLeast(0)], flux[(k + 1).coerceAtMost(n - 1)])) * 0.9f
                    c++
                    pos += p
                }
                if (c > 4) {
                    val score = s / c
                    if (score > bestScore) { bestScore = score; bestP = p; bestPhase = ph }
                }
            }
            p += 0.25f
        }
        if (bestP <= 0f || bestScore < mean * 1.2f) return null
        val bpm = (60000f / (bestP * WIN_MS)).roundToInt()
        val list = ArrayList<Long>()
        var pos = bestPhase.toFloat()
        while (pos < n) { list.add((pos * WIN_MS).toLong()); pos += bestP }
        return bpm to list
    }
}
