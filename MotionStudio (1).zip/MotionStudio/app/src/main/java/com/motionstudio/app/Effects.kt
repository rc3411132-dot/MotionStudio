@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.graphics.Matrix
import androidx.compose.ui.graphics.ColorFilter
import androidx.media3.common.Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

// ------------------------------------------------------------------ colour looks (filters)

/** sat in -100..100 (HSL), contrast/bright in -1..1, r/g/b = channel scales, mat = optional 3x3 colour mix (row-major) */
data class Look(
    val sat: Float = 0f,
    val contrast: Float = 0f,
    val bright: Float = 0f,
    val r: Float = 1f,
    val g: Float = 1f,
    val b: Float = 1f,
    val gray: Boolean = false,
    val mat: List<Float>? = null,
)

private val SEPIA = listOf(0.393f, 0.769f, 0.189f, 0.349f, 0.686f, 0.168f, 0.272f, 0.534f, 0.131f)
private val CYBER = listOf(1.0f, 0f, 0.15f, 0f, 0.85f, 0.10f, 0.10f, 0f, 1.15f)
private val MATRIX = listOf(0.03f, 0.06f, 0.01f, 0.30f, 0.60f, 0.10f, 0.03f, 0.06f, 0.01f)
private val SUNSET = listOf(1.10f, 0.10f, 0f, 0f, 0.90f, 0.05f, 0f, 0.05f, 0.80f)
private val ROSE = listOf(1.05f, 0.05f, 0.05f, 0.02f, 0.92f, 0.02f, 0.05f, 0.02f, 1.02f)
private val FOREST = listOf(0.90f, 0.10f, 0f, 0f, 1.08f, 0f, 0f, 0.08f, 0.90f)

val FILTERS: Map<String, Look> = linkedMapOf(
    "None" to Look(),
    "Vivid" to Look(sat = 45f, contrast = 0.12f),
    "HDR Pop" to Look(sat = 30f, contrast = 0.28f, bright = 0.02f),
    "Punch" to Look(sat = 25f, contrast = 0.35f),
    "Cinematic" to Look(sat = -10f, contrast = 0.22f, bright = -0.04f, r = 1.06f, b = 0.94f),
    "Teal & Orange" to Look(sat = 20f, contrast = 0.15f, r = 1.10f, g = 0.98f, b = 0.92f),
    "Warm" to Look(sat = 10f, r = 1.10f, b = 0.86f),
    "Golden Hour" to Look(sat = 22f, contrast = 0.08f, bright = 0.03f, r = 1.14f, g = 1.04f, b = 0.78f),
    "Sunset" to Look(sat = 18f, contrast = 0.1f, mat = SUNSET),
    "Cool" to Look(sat = 5f, r = 0.90f, b = 1.12f),
    "Blue Hour" to Look(sat = 12f, contrast = 0.12f, bright = -0.05f, r = 0.85f, g = 0.95f, b = 1.2f),
    "Arctic" to Look(sat = -15f, bright = 0.06f, r = 0.92f, g = 1.02f, b = 1.15f),
    "Vintage" to Look(sat = -30f, contrast = -0.05f, r = 1.08f, b = 0.82f),
    "Sepia" to Look(mat = SEPIA, contrast = 0.05f),
    "Retro VHS" to Look(sat = 25f, contrast = -0.08f, bright = 0.05f, r = 1.06f, g = 0.96f, b = 1.08f),
    "Film Fade" to Look(sat = -25f, contrast = -0.12f, bright = 0.08f, r = 1.04f, b = 0.96f),
    "Fade" to Look(sat = -35f, contrast = -0.15f, bright = 0.06f),
    "Pastel" to Look(sat = -18f, contrast = -0.18f, bright = 0.12f, r = 1.03f, b = 1.05f),
    "Dreamy" to Look(sat = -8f, contrast = -0.12f, bright = 0.1f, r = 1.04f, b = 1.06f),
    "Soft Skin" to Look(sat = -5f, contrast = -0.08f, bright = 0.07f, r = 1.05f, g = 1.01f, b = 0.97f),
    "Rose" to Look(sat = 10f, mat = ROSE),
    "Forest" to Look(sat = 15f, contrast = 0.1f, mat = FOREST),
    "Moody" to Look(sat = -20f, contrast = 0.3f, bright = -0.1f, b = 1.05f),
    "Neon" to Look(sat = 80f, contrast = 0.25f, g = 0.95f, b = 1.15f),
    "Cyberpunk" to Look(sat = 40f, contrast = 0.2f, mat = CYBER),
    "Matrix" to Look(contrast = 0.2f, mat = MATRIX),
    "Anime" to Look(sat = 60f, contrast = 0.18f, bright = 0.05f),
    "B&W" to Look(gray = true, contrast = 0.1f),
    "Noir" to Look(gray = true, contrast = 0.4f, bright = -0.08f),
    "Golden B&W" to Look(gray = true, contrast = 0.15f, r = 1.15f, b = 0.8f),
    "Moody Dark" to Look(sat = -25f, contrast = 0.35f, bright = -0.12f, b = 1.05f),
    "Vintage Film" to Look(sat = -22f, contrast = 0.05f, bright = 0.03f, r = 1.06f, b = 0.86f),
    "Film Emulation" to Look(sat = -8f, contrast = 0.18f, r = 1.04f, b = 0.95f),
    "Hollywood" to Look(sat = 8f, contrast = 0.25f, bright = -0.02f, r = 1.07f, b = 0.9f),
    "Warm Cinema" to Look(sat = 5f, contrast = 0.15f, r = 1.1f, g = 1.02f, b = 0.88f),
    "Cold Cinema" to Look(sat = 3f, contrast = 0.15f, r = 0.9f, b = 1.12f),
    "Matte Look" to Look(sat = -15f, contrast = -0.2f, bright = 0.08f),
    "Faded Film" to Look(sat = -30f, contrast = -0.18f, bright = 0.1f, r = 1.03f),
    "Cinematic Fade" to Look(sat = -12f, contrast = -0.1f, bright = 0.06f, b = 1.02f),
    "Technicolor" to Look(sat = 55f, contrast = 0.2f, r = 1.05f, g = 0.98f),
    "Bleach Bypass" to Look(sat = -45f, contrast = 0.45f),
    "Cross Processing" to Look(sat = 30f, contrast = 0.25f, r = 1.12f, b = 0.85f),
    "High Contrast" to Look(contrast = 0.45f),
    "Low Contrast" to Look(contrast = -0.3f),
    "HDR Look" to Look(sat = 35f, contrast = 0.3f, bright = 0.03f),
    "Cyberpunk Color" to Look(sat = 35f, contrast = 0.22f, mat = CYBER),
    "Monochrome" to Look(gray = true),
    "Vibrant Pop" to Look(sat = 70f, contrast = 0.1f),
)

private fun mix3(a: List<Float>?, k: Float): FloatArray {
    val id = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    val m = a ?: return id
    val s = FloatArray(9) { id[it] * (1f - k) + m[it] * k }
    // row-major 3x3 -> column-major 4x4
    return floatArrayOf(s[0], s[3], s[6], 0f, s[1], s[4], s[7], 0f, s[2], s[5], s[8], 0f, 0f, 0f, 0f, 1f)
}

/** Colour filter for the Compose preview of photos, so photos look like the exported video. */
fun previewColorFilter(c: Clip): ColorFilter? {
    val look = FILTERS[c.filter] ?: Look()
    val k = c.filterStrength.coerceIn(0f, 1f)
    val a = c.adjust
    val m = android.graphics.ColorMatrix()
    var any = false
    fun cat(x: android.graphics.ColorMatrix) { m.postConcat(x); any = true }
    if (look.gray) cat(android.graphics.ColorMatrix().apply { setSaturation(0f) })
    if (look.mat != null) {
        val s = mix3(look.mat, k) // column-major 4x4
        cat(android.graphics.ColorMatrix(floatArrayOf(
            s[0], s[4], s[8], 0f, 0f,
            s[1], s[5], s[9], 0f, 0f,
            s[2], s[6], s[10], 0f, 0f,
            0f, 0f, 0f, 1f, 0f)))
    }
    val r = 1f + (look.r - 1f) * k + a.warmth * 0.15f
    val g = 1f + (look.g - 1f) * k
    val b = 1f + (look.b - 1f) * k - a.warmth * 0.15f
    if (abs(r - 1f) + abs(g - 1f) + abs(b - 1f) > 0.002f)
        cat(android.graphics.ColorMatrix(floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
    val sat = (look.sat * k + a.saturation * 100f).coerceIn(-100f, 100f)
    if (abs(sat) > 0.5f) cat(android.graphics.ColorMatrix().apply { setSaturation(1f + sat / 100f) })
    val con = (look.contrast * k + a.contrast).coerceIn(-1f, 1f)
    val bri = (look.bright * k + a.brightness).coerceIn(-1f, 1f)
    if (abs(con) > 0.001f || abs(bri) > 0.001f) {
        val cc = 1f + con
        val off = 128f * (1f - cc) + bri * 255f
        cat(android.graphics.ColorMatrix(floatArrayOf(cc, 0f, 0f, 0f, off, 0f, cc, 0f, 0f, off, 0f, 0f, cc, 0f, off, 0f, 0f, 0f, 1f, 0f)))
    }
    return if (any) ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m.array)) else null
}

// ------------------------------------------------------------------ live (continuous) effects

val LIVE_FX = listOf("None", "Heartbeat", "Zoom Pulse", "Shake Cam", "Wobble", "Flash", "RGB Glitch", "Hue Cycle")
private val LIVE_MATRIX_FX = setOf("Heartbeat", "Zoom Pulse", "Shake Cam", "Wobble")

private fun pulse(tMs: Long, periodMs: Long): Float {
    val ph = (tMs % periodMs) / periodMs.toFloat()
    return (1f - ph * 3f).coerceAtLeast(0f)
}

private fun liveMatrix(fx: String, tMs: Long): Matrix {
    val t = tMs / 1000f
    val m = Matrix()
    when (fx) {
        "Heartbeat" -> { val s = 1f + 0.07f * pulse(tMs, 800); m.postScale(s, s) }
        "Zoom Pulse" -> { val s = 1.04f + 0.04f * sin(2f * PI.toFloat() * t / 2.5f); m.postScale(s, s) }
        "Shake Cam" -> {
            m.postScale(1.05f, 1.05f)
            m.postTranslate(0.012f * sin(t * 37f), 0.012f * sin(t * 29f + 1f))
            m.postRotate(0.4f * sin(t * 23f))
        }
        "Wobble" -> { m.postScale(1.06f, 1.06f); m.postRotate(2.5f * sin(2f * PI.toFloat() * t / 1.5f)) }
    }
    return m
}

private fun liveRgb(fx: String, tMs: Long): FloatArray {
    val id = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    when (fx) {
        "Flash" -> { val g = 1f + 0.5f * pulse(tMs, 600); return floatArrayOf(g, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 1f) }
        "RGB Glitch" -> {
            val burst = (tMs % 1600) < 160
            if (burst) return mix3(listOf(1f, 0f, 0.35f, 0f, 0.7f, 0f, 0.35f, 0f, 1f), 1f)
        }
        "Hue Cycle" -> {
            val th = (tMs / 1000f) * 0.8f
            val c = cos(th); val s = sin(th)
            val h = listOf(
                0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f,
                0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f,
                0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f,
            )
            return mix3(h, 1f)
        }
    }
    return id
}

// ------------------------------------------------------------------ animations (intro / outro / transitions)

val ANIMATIONS = listOf(
    "None", "Zoom In", "Zoom Out", "Pop", "Elastic", "Spin", "Spiral", "Swing", "Squash", "Stretch",
    "Slide Left", "Slide Right", "Slide Up", "Slide Down", "Drop", "Bounce", "Shake", "Fade",
    "Fade Black", "Fade White", "Flash",
)
val EASINGS = listOf("Ease Out", "Ease In", "Ease In-Out", "Linear", "Overshoot", "Spring", "Bounce")
private val FADE_ANIMS = setOf("Fade Black", "Fade White", "Flash")
private val NON_MATRIX_ANIMS = setOf("None", "Fade", "Fade Black", "Fade White", "Flash")
val VIDEO_ANIMATIONS = ANIMATIONS - "Fade" // fade needs alpha, which video frames here don't support

val TEXT_COLORS = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFFF3B30, 0xFFFFC400, 0xFF34C759, 0xFF00C2FF, 0xFF7C5CFF, 0xFFFF4DA6,
)

private fun bounceOut(x: Float): Float = when {
    x < 1f / 2.75f -> 7.5625f * x * x
    x < 2f / 2.75f -> { val y = x - 1.5f / 2.75f; 7.5625f * y * y + 0.75f }
    x < 2.5f / 2.75f -> { val y = x - 2.25f / 2.75f; 7.5625f * y * y + 0.9375f }
    else -> { val y = x - 2.625f / 2.75f; 7.5625f * y * y + 0.984375f }
}

fun ease(p: Float, mode: String = "Ease Out"): Float {
    val x = p.coerceIn(0f, 1f)
    return when (mode) {
        "Linear" -> x
        "Ease In" -> x * x * x
        "Ease In-Out" -> if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
        "Overshoot" -> { val c1 = 1.70158f; val c3 = c1 + 1f; 1f + c3 * (x - 1f).pow(3) + c1 * (x - 1f).pow(2) }
        "Spring" -> if (x == 0f || x == 1f) x else 2f.pow(-10f * x) * sin((x * 10f - 0.75f) * (2f * PI.toFloat() / 3f)) + 1f
        "Bounce" -> bounceOut(x)
        else -> 1f - (1f - x) * (1f - x) * (1f - x)
    }
}

// ------------------------------------------------------------------ keyframes

val KF_PROPS = listOf("scale", "rotation", "posX", "posY", "opacity")

/** Value of [prop] at tMs: eased between neighbouring keys, held before the first and after the last key. */
fun kfValue(c: Clip, prop: String, tMs: Long, base: Float): Float {
    val ks = c.keys.filter { it.prop == prop }.sortedBy { it.tMs }
    if (ks.isEmpty()) return base
    if (tMs <= ks.first().tMs) return ks.first().value
    if (tMs >= ks.last().tMs) return ks.last().value
    val b = ks.indexOfFirst { it.tMs > tMs }
    val k0 = ks[b - 1]; val k1 = ks[b]
    val p = (tMs - k0.tMs).toFloat() / (k1.tMs - k0.tMs).coerceAtLeast(1)
    return k0.value + (k1.value - k0.value) * ease(p, "Ease In-Out")
}

/** The clip with its keyframed properties replaced by their value at tMs (unchanged when it has no keys). */
fun liveClip(c: Clip, tMs: Long): Clip = if (c.keys.isEmpty()) c else c.copy(
    scale = kfValue(c, "scale", tMs, c.scale), rotation = kfValue(c, "rotation", tMs, c.rotation),
    posX = kfValue(c, "posX", tMs, c.posX), posY = kfValue(c, "posY", tMs, c.posY), opacity = kfValue(c, "opacity", tMs, c.opacity),
)

/** t = ms since the clip started playing */
fun animationMatrix(c: Clip, tMs: Long): Matrix {
    val m = Matrix()
    val dur = c.animMs.coerceAtLeast(1)
    if (c.animIn != "None" && tMs < dur) applyAnim(m, c.animIn, ease(tMs / dur.toFloat(), c.easing), true)
    val left = c.durationMs - tMs
    if (c.animOut != "None" && left < dur) applyAnim(m, c.animOut, ease(left.coerceAtLeast(0) / dur.toFloat(), c.easing), false)
    return m
}

/** p goes 0 (hidden state) .. 1 (normal state) */
private fun applyAnim(m: Matrix, name: String, p: Float, entering: Boolean) {
    val pi = PI.toFloat()
    when (name) {
        "Zoom In" -> { val s = 0.3f + 0.7f * p; m.postScale(s, s) }
        "Zoom Out" -> { val s = 1f + 1.2f * (1f - p); m.postScale(s, s) }
        "Pop" -> { val s = if (p < 0.7f) p / 0.7f * 1.15f else 1.15f - (p - 0.7f) / 0.3f * 0.15f; m.postScale(s.coerceAtLeast(0.01f), s.coerceAtLeast(0.01f)) }
        "Elastic" -> { val s = (1f - (1f - p) * cos(p * 3f * pi)).coerceAtLeast(0.01f); m.postScale(s, s) }
        "Spin" -> { m.postRotate(360f * (1f - p) * (if (entering) 1f else -1f)); val s = 0.4f + 0.6f * p; m.postScale(s, s) }
        "Spiral" -> { m.postRotate(540f * (1f - p) * (if (entering) 1f else -1f)); val s = 0.1f + 0.9f * p; m.postScale(s, s) }
        "Swing" -> { m.postRotate(35f * (1f - p) * cos(p * 4f * pi)); val s = 0.6f + 0.4f * p; m.postScale(s, s) }
        "Squash" -> m.postScale(0.2f + 0.8f * p, 1f + 0.3f * (1f - p))
        "Stretch" -> m.postScale(1f, 0.1f + 0.9f * p)
        "Slide Left" -> m.postTranslate(-2f * (1f - p), 0f)
        "Slide Right" -> m.postTranslate(2f * (1f - p), 0f)
        "Slide Up" -> m.postTranslate(0f, 2f * (1f - p))
        "Slide Down" -> m.postTranslate(0f, -2f * (1f - p))
        "Drop" -> m.postTranslate(0f, -2f * (1f - p) * (1f - p) - 0.06f * sin(p * pi * 3f) * (1f - p))
        "Bounce" -> { val s = 1f + 0.25f * sin(p * pi); m.postScale(s, s); m.postTranslate(0f, -0.4f * (1f - p)) }
        "Shake" -> m.postTranslate(0.05f * sin(p * 40f) * (1f - p), 0f)
    }
}

/** Alpha / scale / rotation for the Compose overlays (text, photos, V1 photos) at clip-relative time. */
fun overlayAnim(c: Clip, tMs: Long): Triple<Float, Float, Float> {
    var alpha = 1f; var sc = 1f; var rot = 0f
    val dur = c.animMs.coerceAtLeast(1)
    val pi = PI.toFloat()
    fun one(name: String, p: Float, entering: Boolean) {
        when (name) {
            "Fade", "Fade Black", "Fade White", "Flash" -> alpha *= p
            "Zoom In" -> sc *= 0.3f + 0.7f * p
            "Zoom Out" -> sc *= 1f + 1.2f * (1f - p)
            "Pop" -> sc *= (if (p < 0.7f) p / 0.7f * 1.15f else 1.15f - (p - 0.7f) / 0.3f * 0.15f).coerceAtLeast(0.01f)
            "Elastic" -> sc *= (1f - (1f - p) * cos(p * 3f * pi)).coerceAtLeast(0.01f)
            "Spin" -> { rot += 360f * (1f - p) * (if (entering) 1f else -1f); sc *= 0.4f + 0.6f * p; alpha *= p }
            "Spiral" -> { rot += 540f * (1f - p) * (if (entering) 1f else -1f); sc *= 0.1f + 0.9f * p; alpha *= p }
            "Swing" -> { rot += 35f * (1f - p) * cos(p * 4f * pi); sc *= 0.6f + 0.4f * p }
            "Bounce" -> sc *= 1f + 0.25f * sin(p * pi)
            "Squash", "Stretch", "Slide Left", "Slide Right", "Slide Up", "Slide Down", "Drop", "Shake" -> alpha *= p
        }
    }
    if (c.animIn != "None" && tMs < dur) one(c.animIn, ease(tMs / dur.toFloat(), c.easing), true)
    val left = c.durationMs - tMs
    if (c.animOut != "None" && left < dur) one(c.animOut, ease(left.coerceAtLeast(0) / dur.toFloat(), c.easing), false)
    return Triple(alpha.coerceIn(0f, 1f), sc, rot)
}

// ------------------------------------------------------------------ Media3 effect chain (preview + export)

/**
 * Build the Media3 effect chain for one clip.
 * timeBaseMs: the player's frame timestamps include the clip's inMs; the exporter's do not. Pass inMs for preview.
 */
fun buildEffects(c: Clip, timeBaseMs: Long = 0L): List<Effect> {
    val out = ArrayList<Effect>()
    val look = FILTERS[c.filter] ?: Look()
    val k = c.filterStrength.coerceIn(0f, 1f)
    val a = c.adjust

    if (look.gray) out.add(RgbFilter.createGrayscaleFilter())
    look.mat?.let { m -> val arr = mix3(m, k); out.add(RgbMatrix { _, _ -> arr }) }

    val r = 1f + (look.r - 1f) * k + a.warmth * 0.15f
    val g = 1f + (look.g - 1f) * k
    val b = 1f + (look.b - 1f) * k - a.warmth * 0.15f
    if (abs(r - 1f) > 0.001f || abs(g - 1f) > 0.001f || abs(b - 1f) > 0.001f) {
        out.add(RgbAdjustment.Builder().setRedScale(r).setGreenScale(g).setBlueScale(b).build())
    }
    val sat = (look.sat * k + a.saturation * 100f).coerceIn(-100f, 100f)
    if (abs(sat) > 0.5f) out.add(HslAdjustment.Builder().adjustSaturation(sat).build())
    val con = (look.contrast * k + a.contrast).coerceIn(-1f, 1f)
    if (abs(con) > 0.001f) out.add(Contrast(con))
    val bri = (look.bright * k + a.brightness).coerceIn(-1f, 1f)
    if (abs(bri) > 0.001f) out.add(Brightness(bri))

    // pro grade, sharpen, vignette, grain (GPU passes)
    if (a.hasGrade) {
        out.add(FxShaderEffect("grade", 100f, 1f, g1 = floatArrayOf(a.exposure, a.temperature, a.tint, a.highlights),
            g2 = floatArrayOf(a.shadows, a.vibrance, a.hue, a.fade)))
    }
    if (a.sharpen > 0.01f) out.add(FxShaderEffect("style", 60f, a.sharpen))

    // effect stack: GPU shaders now, camera motions collected for the matrix pass below
    val motions = ArrayList<FxItem>()
    for (item in c.fx) {
        val d = FX_BY_NAME[item.name] ?: continue
        when (d.kind) {
            FxKind.SHADER -> {
                val tint = tintRgb(if (item.color >= 0) item.color else d.tint)
                out.add(FxShaderEffect(d.group, d.mode, item.amount, item.speed, item.angle, item.seed.toFloat(),
                    tint, floatArrayOf(tint[0] * 0.18f, tint[1] * 0.18f, tint[2] * 0.18f), timeBaseMs = timeBaseMs))
            }
            FxKind.MOTION -> motions.add(item)
            FxKind.OVERLAY -> {} // drawn by the overlay layer (preview + export)
        }
    }
    if (a.vignette > 0.01f) out.add(FxShaderEffect("grade", 101f, a.vignette))
    if (a.grain > 0.01f) out.add(FxShaderEffect("grade", 102f, a.grain, timeBaseMs = timeBaseMs))

    val fx = c.liveFx
    if (fx == "Flash" || fx == "RGB Glitch" || fx == "Hue Cycle") {
        out.add(RgbMatrix { us, _ -> liveRgb(fx, (us / 1000L - timeBaseMs).coerceAtLeast(0)) })
    }
    if (c.animIn in FADE_ANIMS || c.animOut in FADE_ANIMS) {
        out.add(RgbMatrix { us, _ -> fadeRgb(c, (us / 1000L - timeBaseMs).coerceAtLeast(0)) })
    }

    // V1 keyframes: zoom (scale) and position are animated in the matrix below, so the static scale is not applied
    val hasKf = c.track == TRACK_V1 && c.keys.any { it.prop == "scale" || it.prop == "posX" || it.prop == "posY" }
    if ((!hasKf && abs(c.scale - 1f) > 0.001f) || abs(c.rotation) > 0.01f) {
        val sc0 = if (hasKf) 1f else c.scale
        out.add(ScaleAndRotateTransformation.Builder().setScale(sc0, sc0).setRotationDegrees(c.rotation).build())
    }
    val hasAnim = c.animIn !in NON_MATRIX_ANIMS || c.animOut !in NON_MATRIX_ANIMS
    val hasLiveM = fx in LIVE_MATRIX_FX
    if (hasAnim || hasLiveM || motions.isNotEmpty() || hasKf) {
        out.add(MatrixTransformation { us ->
            val t = (us / 1000L - timeBaseMs).coerceAtLeast(0)
            val m = if (hasAnim) animationMatrix(c, t) else Matrix()
            if (hasKf) {
                val s = kfValue(c, "scale", t, c.scale)
                m.postScale(s, s)
                m.postTranslate(kfValue(c, "posX", t, c.posX), -kfValue(c, "posY", t, c.posY))
            }
            if (hasLiveM) m.postConcat(liveMatrix(fx, t))
            for (mi in motions) m.postConcat(motionMatrix(mi.name, t, mi.amount, mi.speed, mi.angle, mi.seed))
            m
        })
    }
    return out
}

/** Fade through black / white / flash at clip start (in) and end (out): scale + offset of RGB. */
private fun fadeRgb(c: Clip, tMs: Long): FloatArray {
    var mul = 1f
    var add = 0f
    val dur = c.animMs.coerceAtLeast(1)
    fun one(name: String, p: Float) {
        when (name) {
            "Fade Black" -> mul *= p
            "Fade White" -> { mul *= p; add += (1f - p) }
            "Flash" -> add += (1f - p) * 0.85f
        }
    }
    if (c.animIn in FADE_ANIMS && tMs < dur) one(c.animIn, ease(tMs / dur.toFloat(), c.easing).coerceIn(0f, 1f))
    val left = c.durationMs - tMs
    if (c.animOut in FADE_ANIMS && left < dur) one(c.animOut, ease(left.coerceAtLeast(0) / dur.toFloat(), c.easing).coerceIn(0f, 1f))
    return floatArrayOf(mul, 0f, 0f, 0f, 0f, mul, 0f, 0f, 0f, 0f, mul, 0f, add, add, add, 1f)
}

/** Only the fields that change the effect chain. Used to avoid rebuilding GL effects on every move / trim. */
fun fxKey(c: Clip): List<Any> = listOf(
    c.filter, c.filterStrength, c.liveFx, c.fx, c.easing, c.adjust, c.scale, c.rotation, c.keys, c.animIn, c.animOut, c.animMs, c.durationMs, c.inMs,
)

val TEXT_STYLES = listOf("Plain", "Outline", "Neon", "Gold")
val TEXT_ANIMS = listOf("None", "Typewriter", "Word by Word")
val REVEAL_ANIMS = setOf("Typewriter", "Word by Word")

/** The part of a text clip that is visible tMs after the clip started. */
fun revealText(c: Clip, tMs: Long): String {
    val s = c.text
    if (c.textAnim !in REVEAL_ANIMS || s.isEmpty()) return s
    if (c.textAnim == "Typewriter") {
        val n = s.length
        val total = minOf(n * 60L, (c.durationMs * 0.8).toLong()).coerceAtLeast(1)
        return s.substring(0, (tMs * n / total).toInt().coerceIn(0, n))
    }
    val words = s.split(" ")
    val total = minOf(words.size * 300L, (c.durationMs * 0.8).toLong()).coerceAtLeast(1)
    val k = (tMs * words.size / total).toInt().coerceIn(0, words.size)
    return words.take(k).joinToString(" ")
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000; val f = (ms % 1000) / 33
    return "%02d:%02d:%02d".format(s / 60, s % 60, f)
}
