package com.motionstudio.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

val BG = Color(0xFF0E0F12)
val PANEL = Color(0xFF16181D)
val PANEL2 = Color(0xFF1D2027)
val LINE = Color(0xFF2A2D36)
val TXT = Color(0xFFE6E8EE)
val MUTED = Color(0xFF8A8F9C)
val ACCENTS = listOf(0xFF7C5CFF, 0xFF00C2FF, 0xFFFF4DA6, 0xFF34C759, 0xFFFFC400, 0xFFFF6A3D).map { Color(it) }

val LEFT_TABS = listOf("Media", "Filters", "Effects", "Anim", "Presets", "Text", "Stickers", "AI")

@Composable
fun EditorApp(vm: EditorVM, mouse: MouseController, input: MouseInput) {
    val p = vm.prefs
    val accent = ACCENTS[p.accentIdx.coerceIn(0, ACCENTS.lastIndex)]
    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = BG, surface = PANEL, onSurface = TXT)) {
        var showSettings by remember { mutableStateOf(false) }
        var showExport by remember { mutableStateOf(false) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importMedia(it) }

        Box(Modifier.fillMaxSize().background(BG)) {
            Column(Modifier.fillMaxSize()) {
                TopBar(vm, accent, onImport = { picker.launch(arrayOf("video/*", "image/*", "audio/*")) },
                    onSettings = { showSettings = true }, onExport = { showExport = true })
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    if (p.showLeft) {
                        Box(Modifier.width(p.leftW.dp).fillMaxHeight().background(PANEL)) {
                            LeftPanel(vm, accent, onImport = { picker.launch(arrayOf("video/*", "image/*", "audio/*")) })
                        }
                        DragHandle(vertical = true) { d -> p.leftW = (p.leftW + d).coerceIn(150f, 420f) }
                    }
                    Box(Modifier.weight(1f).fillMaxHeight()) { PreviewPanel(vm, accent) }
                    if (p.showRight) {
                        DragHandle(vertical = true) { d -> p.rightW = (p.rightW - d).coerceIn(180f, 420f) }
                        Box(Modifier.width(p.rightW.dp).fillMaxHeight().background(PANEL)) { ControlsPanel(vm, accent) }
                    }
                }
                DragHandle(vertical = false) { d -> p.timelineH = (p.timelineH - d).coerceIn(120f, 360f) }
                Box(Modifier.height(p.timelineH.dp).fillMaxWidth().background(PANEL)) { TimelinePanel(vm, accent) }
            }
            if (showSettings) SettingsDialog(vm) { showSettings = false; vm.prefs.save() }
            if (showExport || vm.exportProgress >= 0f) ExportDialog(vm) { showExport = false }
            MouseOverlay(mouse, p, input, accent)
            if (!p.mouseOn) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(12.dp)
                        .background(PANEL2.copy(alpha = 0.9f), CircleShape)
                        .border(1.dp, accent, CircleShape)
                        .clickable { p.mouseOn = true; p.save() }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                ) { Text("🖱 Mouse", color = TXT, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun TopBar(vm: EditorVM, accent: Color, onImport: () -> Unit, onSettings: () -> Unit, onExport: () -> Unit) {
    val p = vm.prefs
    Row(
        Modifier.fillMaxWidth().height(38.dp).background(PANEL).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Motion Studio", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Box(Modifier.width(12.dp))
        TopBtn("Import", false, accent) { onImport() }
        TopBtn("Undo", false, accent) { vm.undo() }
        TopBtn("Redo", false, accent) { vm.redo() }
        Box(Modifier.width(10.dp))
        TopBtn("Left panel", p.showLeft, accent) { p.showLeft = !p.showLeft; p.save() }
        TopBtn("Right panel", p.showRight, accent) { p.showRight = !p.showRight; p.save() }
        TopBtn("Mouse", p.mouseOn, accent) { p.mouseOn = !p.mouseOn; p.save() }
        TopBtn("Customize", false, accent) { onSettings() }
        Box(Modifier.weight(1f))
        Text(vm.status, color = MUTED, fontSize = 10.sp, maxLines = 1, modifier = Modifier.width(220.dp))
        Box(
            Modifier.background(accent, RoundedCornerShape(7.dp)).clickable { onExport() }
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) { Text("Export", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
    }
}

@Composable
fun TopBtn(label: String, on: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier.padding(end = 4.dp)
            .background(if (on) accent.copy(alpha = 0.28f) else Color.Transparent, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 6.dp)
    ) { Text(label, color = if (on) TXT else MUTED, fontSize = 11.sp) }
}

/** Thin splitter between panels; drag to resize. delta is reported in dp. */
@Composable
fun DragHandle(vertical: Boolean, onDelta: (Float) -> Unit) {
    val dens = LocalDensity.current.density
    val m = if (vertical) Modifier.width(6.dp).fillMaxHeight() else Modifier.height(6.dp).fillMaxWidth()
    Box(
        m.background(LINE).pointerInput(vertical) {
            detectDragGestures { change, drag ->
                change.consume()
                onDelta((if (vertical) drag.x else drag.y) / dens)
            }
        }
    )
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, accent: Color, fmt: (Float) -> String = { "%.2f".format(it) }, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = MUTED, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text(fmt(value), color = TXT, fontSize = 10.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            modifier = Modifier.height(22.dp),
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = LINE),
        )
    }
}

@Composable
fun Chip(label: String, on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.padding(2.dp)
            .background(if (on) accent else PANEL2, RoundedCornerShape(7.dp))
            .border(1.dp, if (on) accent else LINE, RoundedCornerShape(7.dp))
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (on) Color.White else TXT, fontSize = 11.sp, maxLines = 1) }
}

@Composable
fun SectionTitle(t: String) {
    Text(t.uppercase(), color = MUTED, fontSize = 9.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp, bottom = 3.dp))
}

// ------------------------------------------------------------------------ dialogs
// Dialogs are drawn inside the main window (not as separate Dialog windows) so the virtual mouse can click them.

@Composable
fun Modal(title: String, onClose: () -> Unit, actions: @Composable () -> Unit, content: @Composable () -> Unit) {
    val none = remember { MutableInteractionSource() }
    Box(
        Modifier.fillMaxSize().background(Color(0xB0000000)).clickable(interactionSource = none, indication = null) { onClose() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier.width(430.dp).heightIn(max = 320.dp)
                .background(PANEL2, RoundedCornerShape(14.dp)).border(1.dp, LINE, RoundedCornerShape(14.dp))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(16.dp)
        ) {
            Text(title, color = TXT, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(top = 6.dp)) { content() }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) { actions() }
        }
    }
}

@Composable
private fun SettingsDialog(vm: EditorVM, onClose: () -> Unit) {
    val p = vm.prefs
    val accent = ACCENTS[p.accentIdx]
    Modal("Customize", onClose, actions = {
        TextButton(onClick = {
            p.leftW = 230f; p.rightW = 250f; p.timelineH = 190f; p.showLeft = true; p.showRight = true
            p.sens = 1.8f; p.padScale = 1f; p.cursorScale = 1f; p.padLeft = false; p.accentIdx = 0
        }) { Text("Reset layout") }
        TextButton(onClick = onClose) { Text("Done") }
    }) {
        SectionTitle("Accent colour")
        Row { ACCENTS.forEachIndexed { i, c ->
            Box(Modifier.padding(end = 8.dp).size(26.dp).clip(CircleShape).background(c)
                .border(if (i == p.accentIdx) 2.dp else 0.dp, Color.White, CircleShape)
                .clickable { p.accentIdx = i })
        } }
        SectionTitle("Virtual mouse")
        LabeledSlider("Cursor speed", p.sens, 0.6f..4f, accent) { p.sens = it }
        LabeledSlider("Cursor size", p.cursorScale, 0.6f..2.2f, accent) { p.cursorScale = it }
        Text("Poori screen trackpad hai: kahin bhi ungli ghumao, cursor apni jagah se usi disha mein chalega.", color = MUTED, fontSize = 10.sp)
        Row {
            Chip("Buttons: right", !p.padLeft, accent) { p.padLeft = false }
            Chip("Buttons: left", p.padLeft, accent) { p.padLeft = true }
            Chip("Mouse ${if (p.mouseOn) "ON" else "OFF"}", p.mouseOn, accent) { p.mouseOn = !p.mouseOn }
        }
        SectionTitle("Panels")
        Text("Panels ke beech ki patli patti drag karke size badlo. Top bar se panels hide/show karo.",
            color = MUTED, fontSize = 11.sp)
    }
}

@Composable
private fun ExportDialog(vm: EditorVM, onClose: () -> Unit) {
    val accent = ACCENTS[vm.prefs.accentIdx]
    var res by remember { mutableStateOf(1080) }
    val busy = vm.exportProgress >= 0f
    Modal("Export video", { if (!busy) onClose() }, actions = {
        if (!busy) {
            TextButton(onClick = onClose) { Text("Close") }
            TextButton(onClick = { val (w, h) = outputSize(vm.aspect, res); vm.export(w, h) }) { Text("Start export") }
        }
    }) {
        if (busy) {
            Text("Exporting… ${(vm.exportProgress * 100).roundToInt()}%", color = TXT, fontSize = 12.sp)
            LinearProgressIndicator(progress = { vm.exportProgress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = accent)
        } else {
            Text("Resolution (short side)", color = MUTED, fontSize = 11.sp)
            Row { listOf(720, 1080).forEach { r -> Chip("${r}p", res == r, accent) { res = r } } }
            Text("Aspect ${"%.2f".format(vm.aspect)}  ·  H.264 + AAC .mp4", color = MUTED, fontSize = 11.sp,
                modifier = Modifier.padding(top = 6.dp))
            vm.lastExport?.let { Text("Last export: $it", color = MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp)) }
            Text(vm.status, color = TXT, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

fun outputSize(aspect: Float, shortSide: Int): Pair<Int, Int> {
    fun even(v: Float) = (v / 2f).roundToInt() * 2
    return if (aspect >= 1f) Pair(even(shortSide * aspect), shortSide) else Pair(shortSide, even(shortSide / aspect))
}
