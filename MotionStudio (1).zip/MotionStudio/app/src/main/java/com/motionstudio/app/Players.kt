@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.motionstudio.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs

/**
 * One ExoPlayer that follows the timeline playhead. The VM owns two of them:
 * one for the V1 video track (with the clip's effects) and one for A1 audio.
 * The playhead is the master clock; this class only keeps the player in step with it.
 */
class SlavePlayer(ctx: Context, private val isVideo: Boolean) {
    val player: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private var curId: Long? = null
    private var lastKey: List<Any>? = null
    private var lastSpeed = 1f
    var videoAspect by mutableFloatStateOf(16f / 9f)

    init {
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.height > 0 && videoSize.width > 0) {
                    videoAspect = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                }
            }
        })
    }

    fun sync(clip: Clip?, headMs: Long, playing: Boolean) {
        if (clip == null || clip.uri == null) {
            if (player.playWhenReady) player.playWhenReady = false
            curId = null
            lastKey = null
            return
        }
        val rel = ((headMs - clip.startMs) * clip.speed).toLong().plus(clip.inMs).coerceAtLeast(0)
        if (lastSpeed != clip.speed) { player.setPlaybackSpeed(clip.speed); lastSpeed = clip.speed }
        if (curId != clip.id) {
            if (isVideo) { player.setVideoEffects(buildEffects(clip, clip.inMs)); lastKey = fxKey(clip) }
            player.setMediaItem(MediaItem.fromUri(clip.uri))
            player.prepare()
            player.seekTo(rel)
            curId = clip.id
        } else {
            if (isVideo) {
                val key = fxKey(clip)
                if (key != lastKey) { player.setVideoEffects(buildEffects(clip, clip.inMs)); lastKey = key }
            }
            val diff = abs(player.currentPosition - rel)
            if ((!playing && diff > 40) || diff > 350) player.seekTo(rel)
        }
        player.volume = clip.volume
        player.playWhenReady = playing
    }

    fun release() = player.release()
}
