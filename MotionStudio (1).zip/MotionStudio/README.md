# Motion Studio (starter project)

PC-style video editor for Android (Kotlin + Jetpack Compose + Media3). Landscape UI: media / filters / animations / text / AI panel on the left, preview in the middle, properties on the right, multi-track timeline at the bottom. Virtual mouse (trackpad + cursor) drives the whole UI.

## APK kaise banaye
**Option A - Android Studio:** folder open karo -> Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`

**Option B - GitHub (free, PC ki zarurat nahi):**
1. github.com par naya repo banao, is zip ke andar ki saari files upload karo (`.github` folder ke saath).
2. Actions tab > "Build APK" > Run workflow.
3. Run khatam hone par Artifacts se `MotionStudio-debug-apk` download karo, zip kholo, APK install karo.

## Kya hai (v0.3)
- Tracks: T1 (text), V2 (photo overlay), V1 (video/photo), A1 (audio)
- Cut/split, duplicate, delete, trim handles, drag/move, undo/redo, zoom
- **30 filters** + brightness/contrast/saturation/warmth + filter strength
- **7 live effects**: Heartbeat, Zoom Pulse, Shake Cam, Wobble, Flash, RGB Glitch, Hue Cycle
- **17 animations** (intro/outro): zoom, pop, elastic, spin, spiral, swing, squash, stretch, slides, drop, bounce, shake, fade
- **10 transitions** (outro + intro jodi), **16 look presets**, **10 text presets**
- **AI (on-device, internet nahi chahiye):** Auto Enhance, Enhance All, Smart Look, Cut Silence, Detect Beats (BPM + markers), Beat Sync, Magic Edit (media bin se auto timeline + music beat par cut)
- Export MP4 (H.264/AAC) 720p/1080p, aspect 16:9, 9:16, 1:1, 4:5 -> Movies/MotionStudio
- Virtual mouse: trackpad, left/right click, drag-lock, 2-finger scroll, speed/size settings; resizable/hideable panels, accent colours
- **Effects library (stackable, har effect ke Intensity / Speed / Angle / Seed / Colour sliders):** ~170 effects: Blur, Glitch, Glow, Warp, Art, Cinema, Camera, Particles, VFX. GPU shaders assets/shaders me hain (WebGL me compile-test kiye gaye).
- Pro Color sliders: Exposure, Temperature, Tint, Highlights, Shadows, Vibrance, Hue, Fade, Sharpen, Vignette, Grain. 49 colour looks.
- **43 stickers** (arrows, badges, subscribe/like buttons, bubbles, frames, 16 emoji; code se bani, PNG nahi chahiye) + apni PNG Media tab se '+ Overlay'. 35 text presets.
- 21 transitions, 36 look/trending presets, 7 easing curves, effects Copy / Paste.
- Performance: timeline/preview per-frame recomposition kam, effects sirf zarurat par rebuild, 30fps playhead tick

## Note
`_not_compiled_other_fx/` me 4 purani/anjaan Kotlin files (.txt) rakhi hain jo `FxDef` ka naam clash kar rahi thi; build me shamil nahi hain.

## Abhi nahi hai (honest list)
After Effects jaisa keyframe/graph editor, masks, chroma-key, blend modes, speed ramp, cloud AI (auto captions, background remove), audio volume in export.
Live effects / filters sirf V1 clips par; V2/text par sirf position/scale/animation.
Ye code compile karke test nahi kiya gaya (build tools download blocked the), isliye pehle build me chhoti compile errors aa sakti hain - error text kisi AI ko paste karke fix karwa lo. AI detection (silence, beats, smart look) andaaze se hota hai.

## v0.4 changes (not yet compiled - first build may show small errors, send them back)
- Text animations: Typewriter, Word by Word
- Clip speed 0.25x-4x (video/audio), clip volume now applied in export
- Keyframes: scale, rotation, position X/Y, opacity (V1 supports scale + position)
- Virtual mouse: whole screen is the trackpad (no pad box); small LEFT/RIGHT/DRAG/HIDE strip
- VFX: Circle / Box / Heart / Strip masks
- Text styles: Plain, Outline, Neon, Gold (preview + export)
